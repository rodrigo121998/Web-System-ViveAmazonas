<html lang="en">
	<?php
	 session_start(); //inicio de sesión
			if (!isset($_SESSION["usuario"])){
				session_destroy();
				echo "<br><br> <font color='red'>Intento de acceso sin autorización!!!</font>";
				header("Location:../intranet.html");
				exit;
			}
			 else {
				 include("../inc/menuarriba.php");
			 /*$id_us= $_SESSION['id_us'];
			 $correo_us= $_SESSION['correo_us'];*/
				include("../inc/menu.php");
	 ?>
			<h1 class="h3 mb-2 text-gray-800">Creación de Evaluador</h1>
			<p class="mb-4">En esta página se puede crear los Evaluadores.</p>
			<script src="http://code.jquery.com/jquery-latest.min.js" type="text/javascript"></script>
			<link rel="stylesheet" href="../css/estilos.css"/>
			<script src="script.js"></script>
			<script>
				function alerta()
				{
					return confirm("¿Esta seguro que desea crear este Evaluador?");
				}
			</script>
			<div class="card shadow mb-4">
				<div class="card-header py-3">
				  <h6 class="m-0 font-weight-bold text-primary">Creación de Evaluadores</h6>
				</div>
				<div class="card-body">
					<div class="table-responsive">
			<form action='CUS003.php'>
			<input type='submit' value="Regresar a relación de Evaluadores" class='d-none d-sm-inline-block btn btn-sm btn-primary shadow-sm'>
			</form><br>
            <form class="user" onSubmit='return alerta();' action='CrearCUS003.php' method="POST" enctype='multipart/form-data'>
            Unidad del Evaluador: <select class="form-control" name='unidad'><br><br>
              	<option value="" >Elige una opción...</option>
                <option value="CTE">CTE</option>
                <option value="CTI">CTI</option>
                <option value="DIGE">DIGE</option>
                <option value="DE">DE</option>
                <option value="DONANTE">DONANTE</option>
        			</select><br><br>
            Cargo del Evaluador: <input class="form-control" name='cargo' type="text"> <br><br>
			Nombres y apellidos del Evaluador: <select class="form-control" name='usuario'>
			<option value="">Elige una opción</option>
				<?php
				$sentencia2="Select a.id_usuario,concat(b.nombres,' ',b.apellidos) from usuariosxperfil a, usuarios b where a.cod_perfil=4 and a.id_usuario=b.id;";
				$resultado2 = mysqli_query($enlace,$sentencia2);
				$contar= mysqli_num_rows($resultado2);
				if ($contar==0){
				   echo  "<option value=5>No hay usuario evaluador</option>";
				}
				else {
					for ($i=1; $i <= $contar; $i++){
					$registro = mysqli_fetch_row($resultado2);
					echo "<option value=$registro[0]>$registro[1]</option>";

				}
				}
				?>
			</select><br><br>
            Curriculum Vitae: <input type= "file" class="form-control-file" name= "cv" accept= "application/msword,application/pdf"> <br><br>
            <input type='submit' value='Guardar' name='Guardar' class='d-none d-sm-inline-block btn btn-sm btn-primary shadow-sm'>
            </form>
					</div>
				</div>
			</div>
	  <?php
			include("../inc/menubajo.php");
			 }
	  ?>
</html>
