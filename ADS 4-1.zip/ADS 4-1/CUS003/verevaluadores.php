<html lang="en">
	<?php
	 session_start(); //inicio de sesión
			if (!isset($_SESSION["usuario"])){
				session_destroy();
				echo "<br><br> <font color='red'>Intento de acceso sin autorización!!!</font>";
				header("Location:../intranet.html");
				exit;
			}
			 else {
				 include("../inc/menuarriba.php");
			 /*$id_us= $_SESSION['id_us'];
			 $correo_us= $_SESSION['correo_us'];*/
				include("../inc/menu.php");
	 ?>
			<h1 class="h3 mb-2 text-gray-800">Ver datos de Evaluadores</h1>
			<p class="mb-4">En esta página se puede consultar los evaluadores.</p>
			<div class="card shadow mb-4">
				<div class="card-header py-3">
				  <h6 class="m-0 font-weight-bold text-primary">Consulta de Evaluadores</h6>
				</div>
				<div class="card-body">
					<div class="table-responsive">
			<?php

            $cod=$_GET["cod"];
            $sentencia="SELECT * FROM evaluadores where codigo_evaluador='$cod';";

            $resultado=mysqli_query($enlace,$sentencia);
            $fila=mysqli_fetch_row($resultado);

            echo"<form class='user' action='CUS003.php' method='POST'>";
            echo" Código Evaluador: <input class='form-control' name='cod' type='text' value='$fila[0]' readonly> <br><br>";
            echo" Unidad del evaluador: <input class='form-control' name='unidad' type='text' value='$fila[1]' readonly> <br><br>";
            echo" Cargo: <input class='form-control' name='cargo' type='text' value='$fila[2]' readonly> <br><br>";
						$sentenciauno="Select a.id_usuario, b.nombres, b.apellidos from usuariosxperfil a, usuarios b where (a.cod_perfil=4) and (a.id_usuario=b.id)
						and (b.id=$fila[3]);";
						$resultadouno = mysqli_query($enlace,$sentenciauno);
						$registrocero = mysqli_fetch_row($resultadouno);
            echo" Nombres: <input class='form-control' name='nombres' type='text' value='$registrocero[1]'readonly> <br><br>";
            echo" Apellidos: <input class='form-control' name='apellidos' type='text' value='$registrocero[2]'readonly> <br><br>";
            $sentenciados="SELECT b.id_concurso, c.nombre_concurso
            FROM evaluadores a left join evaluadoresxconcurso b ON a.codigo_evaluador=b.id_evaluador left join concurso c ON b.id_concurso=c.codigo_concurso
            where a.codigo_evaluador='$cod';";
            $resultadodos = mysqli_query($enlace,$sentenciados);
            $registrodos = mysqli_fetch_row($resultadodos);
            echo" Código concurso a evaluar: <input class='form-control' name='codconcurso' type='text' value='$registrodos[0]' readonly> <br><br>";
            echo" Nombre concurso a evaluar: <input class='form-control' name='nombreconcurso' type='text' value='$registrodos[1]' readonly> <br><br>";
            echo"Curriculum Vitae: ";
            if ($fila[4]<>NULL){
                echo"<a href='descargarcv.php?cod=$cod' class='d-none d-sm-inline-block btn btn-sm btn-primary shadow-sm'>CV</a><br><br>";
                } else{
                  echo "No hay archivo subido<br><br>";
                      }
            echo "<input type='submit' value='Terminado' name='Terminado' class='d-none d-sm-inline-block btn btn-sm btn-primary shadow-sm'>";

            echo" </form>";
            ?>
					</div>
				</div>
			</div>
	  <?php
			include("../inc/menubajo.php");
			 }
	  ?>
</html>
