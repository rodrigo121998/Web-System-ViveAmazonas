<html lang="en">
	<?php
	 session_start(); //inicio de sesión
			if (!isset($_SESSION["usuario"])){
				session_destroy();
				echo "<br><br> <font color='red'>Intento de acceso sin autorización!!!</font>";
				header("Location:../intranet.html");
				exit;
			}
			 else {
				 include("../inc/menuarriba.php");
			 /*$id_us= $_SESSION['id_us'];
			 $correo_us= $_SESSION['correo_us'];*/
				include("../inc/menu.php");
	 ?>
			<h1 class="h3 mb-2 text-gray-800">Modificación de datos de Evaluador</h1>
			<p class="mb-4">En esta página se puede modificar los evaluadores.</p>
			<div class="card shadow mb-4">
				<div class="card-header py-3">
				  <h6 class="m-0 font-weight-bold text-primary">Modificación de Evaluadores</h6>
				</div>
				<div class="card-body">
					<div class="table-responsive">
			<form action='CUS003.php'>
			<input type='submit' value="Regresar a relación de Evaluadores" class='d-none d-sm-inline-block btn btn-sm btn-primary shadow-sm' >
			</form><br>
			<?php

            $cod=$_GET["cod"];
            $sentencia3="SELECT * FROM evaluadores where codigo_evaluador='$cod';";
            $resultado3=mysqli_query($enlace,$sentencia3);
            $fila=mysqli_fetch_row($resultado3);
			echo "<script src='http://code.jquery.com/jquery-latest.min.js' type='text/javascript'></script>";
			echo "<link rel='stylesheet' href='css/estilos.css'/>";
			echo "<script src='script.js'></script>";
			echo "<script>";
			echo "function alerta(){";
			echo	"return confirm('¿Está seguro que desea modificar este Evaluador?');}";
			echo "</script>";
            echo"<form class='user' onSubmit='return alerta();' action='editarevaluador.php?cod=$cod' method='POST'>";
            echo" Unidad del Evaluador: <select class='form-control' name='unidad'>";
            if ($fila[1]=='CTE'){
              echo"<option value='$fila[1]'>$fila[1]</option>";
              echo"<option value='CTI' >CTI</option>";
              echo"<option value='DIGE' >DIGE</option>";
              echo"<option value='DE' >DE</option>";
              echo"<option value='DONANTE' >DONANTE</option>";
              echo "</select><br><br>";
            }
            elseif ($fila[1]=='CTI'){
              echo"<option value='$fila[1]'>$fila[1]</option>";
              echo"<option value='CTE'>CTE</option>";
              echo"<option value='DIGE'>DIGE</option>";
              echo"<option value='DE'>DE</option>";
              echo"<option value='DONANTE'>DONANTE</option>";
              echo"</select><br><br>";
            }
            elseif ($fila[1]=='DIGE'){
              echo"<option value='$fila[1]'>$fila[1]</option>";
              echo"<option value='CTE' >CTE</option>";
              echo"<option value='CTI' >CTI</option>";
              echo"<option value='DE' >DE</option>";
              echo"<option value='DONANTE' >DONANTE</option>";
              echo"</select><br><br>";
            }
            elseif ($fila[1]=='DE'){
              echo"<option value='$fila[1]'>$fila[1]</option>";
              echo"<option value='CTE' >CTE</option>";
              echo"<option value='CTI' >CTI</option>";
              echo"<option value='DIGE' >DIGE</option>";
              echo"<option value='DONANTE' >DONANTE</option>";
              echo"</select><br><br>";
            }
            elseif ($fila[1]=='DONANTE'){
              echo"<option value='$fila[1]'>$fila[1]</option>";
              echo"<option value='CTE' >CTE</option>";
              echo"<option value='CTI' >CTI</option>";
              echo"<option value='DIGE' >DIGE</option>";
              echo"<option value='DE' >DE</option>";
              echo"</select><br><br>";
            }
            else {
              echo"<option value='$fila[1]'>$fila[1]</option>";
              echo"<option value='CTE' >CTE</option>";
              echo"<option value='CTI' >CTI</option>";
              echo"<option value='DIGE' >DIGE</option>";
              echo"<option value='DE' >DE</option>";
              echo"<option value='DONANTE' >DONANTE</option>";
              echo"</select><br><br>";
            }
            echo" Cargo: <input class='form-control' name='cargo' type='text' value='$fila[2]'> <br><br>";
			echo" Nombres y apellidos del Evaluador: <select class='form-control' name='usuario'>";
				$sentenciauno="Select a.id_usuario,concat(b.nombres,' ',b.apellidos) from usuariosxperfil a, usuarios b where (a.cod_perfil=4) and (a.id_usuario=b.id)
				and (b.id=$fila[3]);";
				$resultadouno = mysqli_query($enlace,$sentenciauno);
				$registrocero = mysqli_fetch_row($resultadouno);
				echo  "<option value='$registrocero[0]'>$registrocero[1]</option>";
				$sentencia2="Select a.id_usuario,concat(b.nombres,' ',b.apellidos) from usuariosxperfil a, usuarios b where (a.cod_perfil=4) and (a.id_usuario=b.id)
				and (b.id<>$fila[3]);";
				$resultado2 = mysqli_query($enlace,$sentencia2);
				$contar= mysqli_num_rows($resultado2);
				if ($contar==0){
				   echo  "<option value=5>No hay otro usuario evaluador</option>";
				}
				else {
					for ($i=1; $i <= $contar; $i++){
					$registro = mysqli_fetch_row($resultado2);
					echo "<option value='$registro[0]'>$registro[1]</option>";

				}
				}
			echo "</select><br><br>";
            echo" Curriculum Vitae: ";
              if ($fila[4]<>NULL){
                echo"<a href='descargarcv.php?cod=$cod' class='d-none d-sm-inline-block btn btn-sm btn-primary shadow-sm'>CV</a><br><br>";
                echo"<a href='subircv.php?cod=$cod' class='d-none d-sm-inline-block btn btn-sm btn-primary shadow-sm'>Cambiar CV</a><br><br>";
                } else{
                  echo "No hay archivo subido<br><br>";
                  echo"<a href='subircv.php?cod=$cod' class='d-none d-sm-inline-block btn btn-sm btn-primary shadow-sm'>Agregar CV</a><br><br>";
                      }

            echo "<input type='submit' value='Guardar' name='Guardar' class='d-none d-sm-inline-block btn btn-sm btn-primary shadow-sm'>";
            echo" </form>";
            ?>
					</div>
				</div>
			</div>
	  <?php
			include("../inc/menubajo.php");
			 }
	  ?>
</html>
