<?php
$cod=$_GET["cod"];
$enlace = mysqli_connect("localhost","root","","base_va");
$sentencia="Select tipo_cv,cv from evaluadores where codigo_evaluador=$cod;";
$resultado = mysqli_query($enlace,$sentencia);
$fila=mysqli_fetch_row($resultado);
header("Content-type: $fila[0]");
echo $fila[1];
?>
