<?php
	$cod = unserialize($_GET['cod']);
	$enlace = mysqli_connect("localhost","root","","base_va");
	if ($cod==""){
		
		$sentencia2="SELECT a.codigo_evaluador, a.Unidad, a.cargo_evaluador, d.nombres, d.apellidos, b.id_concurso, c.nombre_concurso
            FROM evaluadores a left join evaluadoresxconcurso b ON a.codigo_evaluador=b.id_evaluador left join concurso c ON b.id_concurso=c.codigo_concurso left join usuarios d ON a.usuario=d.id
            where a.estado='A';";
        $resultado2 = mysqli_query($enlace,$sentencia2);
		$numFilas = mysqli_num_rows($resultado2);
		
		if ($numFilas == 0) {
			echo "No hay empresas proponentes <br>";
		}
		else {
			echo "<br><br>";
			//Inicio de exportación en Excel
			header('Content-type: application/vnd.ms-excel');
			header("Content-Disposition: attachment; filename=Reporteeva.xls"); //Indica el nombre del archivo resultante
			header("Pragma: no-cache");
			header("Expires: 0");
			echo "<table align='center'>";
			echo "<thead>";
			echo "	<tr>";
           echo "		<td>Codigo Evaluador</td>";
           echo "		<td>Unidad</td>";
           echo "		<td>Cargo Evaluador</td>";
           echo "		<td>Nombres</td>";
           echo "		<td>Apellidos</td>";
           echo "		<td>Código concurso a evaluar</td>";
           echo "		<td>Nombre concurso a evaluar</td>";						
			echo "	</tr>";
			echo "</thead>";
			echo "<tbody>";
							
			/*Estoy definiendo una iteración*/
			for ($i=1; $i <= $numFilas; $i++){
				/*Esta función permite obtener un registro (fila) del resultado de un query*/
				$registro = mysqli_fetch_row($resultado2);
				echo "	<tr>";
				echo "		<td style='visibility:collapse;'>",$registro[0],"</td>";
				echo "		<td>",$registro[1],"</td>";
				 echo "		<td>",$registro[2],"</td>";
				 echo "		<td>",$registro[3],"</td>";
				 echo "		<td>",$registro[4],"</td>";
				 echo "		<td>",$registro[5],"</td>";
				 echo "		<td>",$registro[6],"</td>";
				echo "	</tr>";					
			}
			echo "</tbody>";
			echo "</table>";
		}
	}
	else {
			echo "<br><br>";
			header('Content-type: application/vnd.ms-excel');
			header("Content-Disposition: attachment; filename=Reporteeva.xls"); //Indica el nombre del archivo resultante
			header("Pragma: no-cache");
			header("Expires: 0");
			echo "<table align='center'>";
			echo "<thead>";
			echo "	<tr>";
           echo "		<td>Codigo Evaluador</td>";
           echo "		<td>Unidad</td>";
           echo "		<td>Cargo Evaluador</td>";
           echo "		<td>Nombres</td>";
           echo "		<td>Apellidos</td>";
           echo "		<td>Código concurso a evaluar</td>";
           echo "		<td>Nombre concurso a evaluar</td>";					
			echo "	</tr>";
			echo "</thead>";
			echo "<tbody>";
								
			/*Estoy definiendo una iteración*/
			foreach ($cod as $codigo){
				/*Esta función permite obtener un registro (fila) del resultado de un query*/
				$sentencia2="SELECT a.codigo_evaluador, a.Unidad, a.cargo_evaluador, d.nombres, d.apellidos, b.id_concurso, c.nombre_concurso
	            FROM evaluadores a left join evaluadoresxconcurso b ON a.codigo_evaluador=b.id_evaluador 
				left join concurso c ON b.id_concurso=c.codigo_concurso left join usuarios d ON a.usuario=d.id
				where a.codigo_evaluador='$codigo' and a.estado='A';";
				$resultado2 = mysqli_query($enlace,$sentencia2);
				$registro = mysqli_fetch_row($resultado2);
				echo "	<tr>";
				echo "		<td style='visibility:collapse;'>",$registro[0],"</td>";
				echo "		<td>",$registro[1],"</td>";
				 echo "		<td>",$registro[2],"</td>";
				 echo "		<td>",$registro[3],"</td>";
				 echo "		<td>",$registro[4],"</td>";
				 echo "		<td>",$registro[5],"</td>";
				 echo "		<td>",$registro[6],"</td>";
				echo "	</tr>";					
			}
			echo "</tbody>";
			echo "</table>";
		
	}
?>