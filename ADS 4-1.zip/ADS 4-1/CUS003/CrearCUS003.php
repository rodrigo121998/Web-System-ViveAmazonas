<html>
<head> </head>
<body>
<?php
	session_start(); //inicio de sesión
	if (!isset($_SESSION["usuario"])){
		session_destroy();
		echo "<br><br> <font color='red'>Intento de acceso sin autorización!!!</font>";
		header("Location:../intranet.html");
		exit;
	}
	$unidad = $_POST["unidad"];
	$cargo = $_POST["cargo"];
	$usuario = $_POST["usuario"];
  $nombre_cv=$_FILES['cv']['name'];
	$tipo_cv=$_FILES['cv']['type'];
  $tamano_cv=$_FILES['cv']['size'];
	$carpeta_destino=$_SERVER['DOCUMENT_ROOT'].'/ADS 4/upload/';
	move_uploaded_file($_FILES['cv']['tmp_name'],$carpeta_destino.$nombre_cv);
	$cv_objetivo=fopen($carpeta_destino.$nombre_cv,'r');
	$contenido_cv=fread($cv_objetivo,$tamano_cv);
	$contenido_cv=addslashes($contenido_cv);
	fclose($cv_objetivo);
	$enlace=mysqli_connect("localhost","root","","base_va");
	$sentencia="INSERT INTO evaluadores (Unidad,cargo_evaluador,usuario,cv,estado,tipo_cv)
	VALUES ('$unidad','$cargo','$usuario','$contenido_cv','A','$tipo_cv');";
	$resultado = mysqli_query($enlace,$sentencia);
	header("Location:CUS003.php");
 ?>
</body>
</html>
