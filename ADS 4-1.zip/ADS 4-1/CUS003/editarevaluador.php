<html>
	<head>
	</head>

	<body>
		<?php
		session_start(); //inicio de sesión
					if (!isset($_SESSION["usuario"])){
						session_destroy();
						echo "<br><br> <font color='red'>Intento de acceso sin autorización!!!</font>";
						header("Location:../intranet.html");
						exit;
					}
			$cod=$_GET["cod"];
			$unidad = $_POST["unidad"];
			$cargo = $_POST["cargo"];
			$usuario = $_POST["usuario"];
			$enlace = mysqli_connect("localhost","root","","base_va");
			$sentencia="UPDATE evaluadores set Unidad = '$unidad',
			cargo_evaluador= '$cargo',usuario = '$usuario'
			where codigo_evaluador='$cod';";
			$resultado = mysqli_query($enlace,$sentencia);
			header("Location:CUS003.php");
		?>
	</body>
</html>
