<html lang="en">
	<?php
	 session_start(); //inicio de sesión
			if (!isset($_SESSION["usuario"])){
				session_destroy();
				echo "<br><br> <font color='red'>Intento de acceso sin autorización!!!</font>";
				header("Location:../intranet.html");
				exit;
			}
			 else {
				 include("../inc/menuarriba.php");
			 /*$id_us= $_SESSION['id_us'];
			 $correo_us= $_SESSION['correo_us'];*/
				include("../inc/menu.php");
	 ?>
			<h1 class="h3 mb-2 text-gray-800">Creación de Empresa proponente</h1>
			<p class="mb-4">En esta página se puede crear las Empresas Proponentes.</p>
			<script src="http://code.jquery.com/jquery-latest.min.js" type="text/javascript"></script>
			<link rel="stylesheet" href="css/estilos.css"/>
			<script src="script.js"></script>
			<script>
				function alerta()
				{
					return confirm("¿Esta seguro que desea crear esta Empresa Proponente?");
				}
			</script>
			<div class="card shadow mb-4">
				<div class="card-header py-3">
				  <h6 class="m-0 font-weight-bold text-primary">Creación de Empresas Proponentes</h6>
				</div>
				<div class="card-body">
					<div class="table-responsive">
			<form action='CUS002proponentes.php'>
			<input type='submit' value="Regresar a relación de Empresas Proponentes" class='d-none d-sm-inline-block btn btn-sm btn-primary shadow-sm'>
			</form><br>
            <form class="user"  onSubmit='return alerta();' action='CrearCUS002.php' method="POST">
            Nombre Empresa: <input class="form-control" placeholder='Nombre de la Empresa Proponente' name="nombreempresa" type="text"> <br><br>
            RUC: <input class="form-control" name="ruc" type="text"> <br><br>
            Grupo: <input class="form-control" name="grupo" type="text"> <br><br>
            Usuario Responsable: <select class="form-control" name="usuarioresp">
			<option value="">Elige una opción</option>
				<?php
				$sentencia2="Select a.id_usuario,concat(b.nombres,' ',b.apellidos) from usuariosxperfil a, usuarios b where a.cod_perfil=2 and a.id_usuario=b.id;";
				$resultado2 = mysqli_query($enlace,$sentencia2);
				$contar= mysqli_num_rows($resultado2);
				if ($contar==0){
				   echo  "<option value=5>No hay usuario representante</option>";
				}
				else {
					for ($i=1; $i <= $contar; $i++){
					$registro = mysqli_fetch_row($resultado2);
					echo "<option value=$registro[0]>$registro[1]</option>";
					
				}
				}
				?>
			</select><br><br>
            Página web: <input class="form-control" name="paginaweb" type="url"> <br><br>
            Experiencia: <input class="form-control" name="experiencia" type="text"> <br><br>
            Teléfono de contacto: <input class="form-control" name="telefono" type="tel"> <br><br>
            Dirección: <input class="form-control" name="direccion" type="text"> <br><br>
            Correo Empresa: <input class="form-control" name="correoemp" type="email"> <br><br>
            CEO: <input class="form-control" name="ceo" type="text"> <br><br>
            Representante legal: <input class="form-control" name="representantelegal" type="text"><br><br>
            <input type='submit' value='Guardar' name='Guardar' class='d-none d-sm-inline-block btn btn-sm btn-primary shadow-sm'>

            </form>
					</div>
				</div>
			</div>
	  <?php
			include("../inc/menubajo.php");
			 }
	  ?>
</html>