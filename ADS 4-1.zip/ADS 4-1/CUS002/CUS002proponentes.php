<html lang="en">
	<?php
	 session_start(); //inicio de sesión
						if (!isset($_SESSION["usuario"])){
							session_destroy();
							echo "<br><br> <font color='red'>Intento de acceso sin autorización!!!</font>";
							header("Location:../intranet.html");
							exit;
						}
			 else {
			include("../inc/menuarriba.php");
			 /*$id_us= $_SESSION['id_us'];
			 $correo_us= $_SESSION['correo_us'];*/
			include("../inc/menu.php");
	 ?>
	<div>
		<h1 class="h3 mb-0 text-gray-800">Relación de Empresas proponentes</h1><br>
		<p class="mb-4">En esta página se puede administrar las Empresas Proponentes.</p>
			<script src="http://code.jquery.com/jquery-latest.min.js" type="text/javascript"></script>
			<link rel="stylesheet" href="../css/estilos.css"/>
			<script src="script.js"></script>
			<script>
				function alerta()
				{
					return confirm("¿Esta seguro que desea eliminar esta Empresa Proponente?");
				}
			</script>
			<div class="card shadow mb-4">
				<div class="card-header py-3">
				  <h6 class="m-0 font-weight-bold text-primary">Tabla de Empresas Proponentes</h6>
				</div>
				<div class="card-body">
					<div class="table-responsive">
			<form class="d-none d-sm-inline-block form-inline mr-auto ml-md-3 my-2 my-md-0 mw-100 navbar-search" action='CUS002proponentes.php' method='POST' enctype='multipart/form-data'>
				<div class="input-group">
					<input type='text' class="form-control bg-light border-0 small" name='empresa' placeholder='Buscando Empresa Proponente...'> 
					<input type='submit' class="btn btn-primary" name='buscar' value="Buscar Empresa Proponente" >
					<?php
					?>
				</div>
			</form>
			<br><br>
			<?php
			if (!isset($_POST["buscar"])){
			
            $sentencia2="SELECT a.Codigo_Empresa, a.Nombre_Empresa, a.RUC, a.Grupo,b.usuario, a.Pagina_web
			FROM empresas_proponentes a,usuarios b where a.Estado='A' and a.ID_Representante=b.id;";
            $resultado2 = mysqli_query($enlace,$sentencia2);
            $contar= mysqli_num_rows($resultado2);
			echo"<form action='crearproponente.php' method='POST'>";
           if ($contar==0){
           echo  "No hay empresas proponentes <br>";
           }
           else {

           echo "<form action='' method= 'POST'>";
           echo "<table class='table table-bordered' id='dataTable' width='100%' cellspacing='0'>";
           echo "<thead>";
		   echo "	<tr>";
           echo "		<td>Codigo Empresa</td>";
           echo "		<td>Nombre Empresa</td>";
           echo "		<td>RUC</td>";
           echo "		<td>Grupo</td>";
           echo "		<td>Usuario Responsable</td>";
           echo "		<td>Página web</td>";
           echo "		<td>Opciones</td>";
           echo "	</tr>";
			echo "</thead>";
		   echo "<tbody>";
           for ($i=1; $i <= $contar; $i++){
             $registro = mysqli_fetch_row($resultado2);


             echo "	<tr>";
             echo "		<td>",$registro[0],"</td>";
             echo "		<td>",$registro[1],"</td>";
             echo "		<td>",$registro[2],"</td>";
             echo "		<td>",$registro[3],"</td>";
             echo "		<td>",$registro[4],"</td>";
             echo "		<td>",$registro[5],"</td>";
             echo "		<td><a href='modificarproponentes.php?cod=$registro[0]' class='d-none d-sm-inline-block btn btn-sm btn-primary shadow-sm'>Modificar</a>
			 <a href='verproponentes.php?cod=$registro[0]' class='d-none d-sm-inline-block btn btn-sm btn-primary shadow-sm'>Consultar</a>
			 <a onclick='return alerta();' href='eliminarproponentes.php?cod=$registro[0]' class='d-none d-sm-inline-block btn btn-sm btn-primary shadow-sm'>Eliminar</a></td> ";
             echo "	</tr>";

           }
		   echo "</tbody>";
           echo "</table>";

           }

             ?>
			 <div class="d-sm-flex align-items-center justify-content-between mb-4">
			 <input type='submit' class="btn btn-primary" value="Crear proponente" >
			 <?php
			 echo"<a href='exportar.php?cod=''' class='d-none d-sm-inline-block btn btn-sm btn-primary shadow-sm'><i class='fas fa-download fa-sm text-white-50'></i> Exportar Reporte</a>";
			 ?>
			 </div>
		</form>
	  <?php
			}
			else	{
			$empresa = $_POST['empresa'];
			echo"<form action='CUS002proponentes.php' enctype='multipart/form-data'>";
			if ($empresa==''){
				echo"No ha seleccionado ninguna empresa";
			}
			else {
            $sentencia2= "SELECT a.Codigo_Empresa, a.Nombre_Empresa, a.RUC, a.Grupo,b.usuario, a.Pagina_web
			FROM empresas_proponentes a,usuarios b where a.Nombre_Empresa like '%$empresa%' and a.Estado='A' and a.ID_Representante=b.id;";
			$resultado2 = mysqli_query($enlace,$sentencia2);
            $contar= mysqli_num_rows($resultado2);
           if ($contar==0){
           echo  "No hay empresa con ese nombre <br>";
           }
           else {

            echo "<form action='' method= 'POST'>";
           echo "<table class='table table-bordered' id='dataTable' width='100%' cellspacing='0'>";
           echo "<thead>";
		   echo "	<tr>";
           echo "		<td>Codigo Empresa</td>";
           echo "		<td>Nombre Empresa</td>";
           echo "		<td>RUC</td>";
           echo "		<td>Grupo</td>";
           echo "		<td>Usuario Responsable</td>";
           echo "		<td>Página web</td>";
           echo "		<td>Opciones</td>";
           echo "	</tr>";
		   echo "</thead>";
		   echo "<tbody>";
			$cod=array();
           for ($i=1; $i <= $contar; $i++){
             $registro = mysqli_fetch_row($resultado2);


             echo "	<tr>";
             echo "		<td>",$registro[0],"</td>";
			 array_push($cod,$registro[0]);
             echo "		<td>",$registro[1],"</td>";
             echo "		<td>",$registro[2],"</td>";
             echo "		<td>",$registro[3],"</td>";
             echo "		<td>",$registro[4],"</td>";
             echo "		<td>",$registro[5],"</td>";
             echo "		<td><a href='modificarproponentes.php?cod=$registro[0]' class='d-none d-sm-inline-block btn btn-sm btn-primary shadow-sm'>Modificar</a>
			 <a href='verproponentes.php?cod=$registro[0]' class='d-none d-sm-inline-block btn btn-sm btn-primary shadow-sm'>Consultar</a>
			 <a onclick='return alerta();' href='eliminarproponentes.php?cod=$registro[0]' class='d-none d-sm-inline-block btn btn-sm btn-primary shadow-sm'>Eliminar</a></td> ";
             echo "	</tr>";

           }
		   echo "</tbody>";
           echo "</table>";

           }
			}
			
			echo" <br><br>";
			$cod = serialize($cod);
			$cod = urlencode($cod);
			echo"<div class='d-sm-flex align-items-center justify-content-between mb-4'>";
			echo"<input type='submit' class='btn btn-primary' value='Regresar a relación de Empresas Proponentes'>";
			echo"<a href='exportar.php?cod=$cod' class='d-none d-sm-inline-block btn btn-sm btn-primary shadow-sm'><i class='fas fa-download fa-sm text-white-50'></i> Exportar Reporte</a>";
			echo"</div>";
			echo"</form>";
			}
				echo"</div>";
			echo"</div>";
		echo"</div>";
		include("../inc/menubajo.php");
			 }
	  ?>
</html>
