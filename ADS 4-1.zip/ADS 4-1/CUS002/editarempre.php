<html>
	<head>
	</head>

	<body>
		<?php
		session_start(); //inicio de sesión
					if (!isset($_SESSION["usuario"])){
						session_destroy();
						echo "<br><br> <font color='red'>Intento de acceso sin autorización!!!</font>";
						header("Location:../intranet.html");
						exit;
					}
			$cod=$_GET["cod"];
			$nombreempresa = $_POST["nombreempresa"];
			$ruc = $_POST["ruc"];
			$grupo = $_POST["grupo"];
			$usuarioresp = $_POST["usuarioresp"];
			$paginaweb = $_POST["paginaweb"];
			$experiencia = $_POST["experiencia"];
			$telefono = $_POST["telefono"];
			$direccion = $_POST["direccion"];
			$correoemp = $_POST["correoemp"];
			$ceo = $_POST["ceo"];
			$representantelegal = $_POST["representantelegal"];
			$enlace = mysqli_connect("localhost","root","","base_va");
			$sentencia="update empresas_proponentes set Nombre_Empresa = '$nombreempresa',
			RUC= '$ruc',Grupo = '$grupo',ID_Representante = '$usuarioresp',Pagina_web = '$paginaweb',
			Experiencia = '$experiencia',Telefono_contacto = '$telefono',Direccion = '$direccion',
			Correo_Empresa='$correoemp',CEO='$ceo',Representante_legal='$representantelegal'
			where Codigo_Empresa='$cod';";
			$resultado = mysqli_query($enlace,$sentencia);
			header("Location:CUS002proponentes.php");
		?>
	</body>
</html>