<html>
	<?php
	 session_start(); //inicio de sesión
			if (!isset($_SESSION["usuario"])){
				session_destroy();
				echo "<br><br> <font color='red'>Intento de acceso sin autorización!!!</font>";
				header("Location:../intranet.html");
				exit;
			}
			 else {
				include("../inc/menuarriba.php");
			 /*$id_us= $_SESSION['id_us'];
			 $correo_us= $_SESSION['correo_us'];*/
				include("../inc/menu.php");
	 ?>
			<h1 class="h3 mb-2 text-gray-800">Ver datos de Empresa Proponente</h1>
			<p class="mb-4">En esta página se puede consultar las Empresas Proponentes.</p>
			<div class="card shadow mb-4">
				<div class="card-header py-3">
				  <h6 class="m-0 font-weight-bold text-primary">Consulta de Empresas Proponentes</h6>
				</div>
				<div class="card-body">
					<div class="table-responsive">
			<?php

            $cod=$_GET["cod"];
            $sentencia="SELECT * FROM empresas_proponentes where Codigo_Empresa='$cod';";

            $resultado=mysqli_query($enlace,$sentencia);
            $fila=mysqli_fetch_row($resultado);

            echo"<form class='user' action='CUS002proponentes.php' method='POST'>";
            echo" Nombre Empresa: <input class='form-control' name='nombreempresa' type='text' value='$fila[1]' readonly> <br><br>";
            echo" RUC: <input name='ruc' class='form-control' type='text' value='$fila[2]' readonly> <br><br>";
            echo" Grupo: <input name='grupo' class='form-control' type='text' value='$fila[3]' readonly> <br><br>";
				$sentenciauno="Select a.id_usuario,concat(b.nombres,' ',b.apellidos) from usuariosxperfil a, usuarios b where (a.cod_perfil=2) and (a.id_usuario=b.id)
				and (b.id=$fila[4]);";
				$resultadouno = mysqli_query($enlace,$sentenciauno);
				$registrocero = mysqli_fetch_row($resultadouno);
            echo" Usuario Responsable: <input class='form-control' name='usuarioresp' type='text' value='$registrocero[1]' readonly> <br><br>";
            echo" Página web: <input class='form-control' name='paginaweb' type='text' value='$fila[5]' readonly> <br><br>";
            echo" Experiencia: <input class='form-control' name='experiencia' type='text' value='$fila[6]' readonly> <br><br>";
            echo" Teléfono de contacto: <input class='form-control' name='telefono' type='text' value='$fila[7]' readonly> <br><br>";
            echo" Dirección: <input class='form-control' name='direccion' type='text' value='$fila[8]' readonly> <br><br>";
            echo" Correo Empresa: <input class='form-control' name='correoemp' type='text' value='$fila[9]' readonly> <br><br>";
            echo" CEO: <input class='form-control' name='ceo' type='text' value='$fila[10]' readonly> <br><br>";
            echo" Representante legal: <input class='form-control' name='representantelegal' type='text' value='$fila[11]' readonly> <br><br>";

            echo "<input type='submit' value='Terminado' name='Terminado' class='d-none d-sm-inline-block btn btn-sm btn-primary shadow-sm'>";

            echo" </form>";
            ?>
					</div>
				</div>
			</div>
	  <?php
			include("../inc/menubajo.php");
			 }
	  ?>
</html>
