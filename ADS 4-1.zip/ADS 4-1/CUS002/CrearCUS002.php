<html>
<head> </head>
<body>
<?php
	session_start(); //inicio de sesión
	if (!isset($_SESSION["usuario"])){
		session_destroy();
		echo "<br><br> <font color='red'>Intento de acceso sin autorización!!!</font>";
		header("Location:../intranet.html");
		exit;
	}
	$nombreempresa = $_POST["nombreempresa"];
	$ruc = $_POST["ruc"];
	$grupo = $_POST["grupo"];
	$usuarioresp = $_POST["usuarioresp"];
	$paginaweb = $_POST["paginaweb"];
	$experiencia = $_POST["experiencia"];
	$telefono = $_POST["telefono"];
	$direccion = $_POST["direccion"];
	$correoemp = $_POST["correoemp"];
	$ceo = $_POST["ceo"];
	$representantelegal = $_POST["representantelegal"];
	$enlace=mysqli_connect("localhost","root","","base_va");
	$sentencia="INSERT INTO empresas_proponentes(Nombre_Empresa,RUC,Grupo,ID_Representante,Pagina_web,Experiencia,
	Telefono_contacto,Direccion,Correo_Empresa,CEO,Representante_legal)
	VALUES ('$nombreempresa','$ruc','$grupo',$usuarioresp,'$paginaweb','$experiencia',
	'$telefono','$direccion','$correoemp','$ceo','$representantelegal');";
	$resultado = mysqli_query($enlace,$sentencia);
	header("Location:CUS002proponentes.php");

 ?>
</body>
</html>