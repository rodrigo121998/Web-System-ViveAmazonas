<html>
	<?php
	 session_start(); //inicio de sesión
			if (!isset($_SESSION["usuario"])){
				session_destroy();
				echo "<br><br> <font color='red'>Intento de acceso sin autorización!!!</font>";
				header("Location:../intranet.html");
				exit;
			}
			 else {
				 include("../inc/menuarriba.php");
			 /*$id_us= $_SESSION['id_us'];
			 $correo_us= $_SESSION['correo_us'];*/
				include("../inc/menu.php");
	 ?>
			<div>
			<h1 class="h3 mb-2 text-gray-800">Modificación de datos de Empresa Proponente</h1>
			<p class="mb-4">En esta página se puede modificar las Empresas Proponentes.</p>
			<div class="card shadow mb-4">
				<div class="card-header py-3">
				  <h6 class="m-0 font-weight-bold text-primary">Modificación de Concursos</h6>
				</div>
				<div class="card-body">
					<div class="table-responsive">
			<form action='CUS002proponentes.php'>
			<input type='submit' value="Regresar a relación de Empresas Proponentes" class='d-none d-sm-inline-block btn btn-sm btn-primary shadow-sm'>
			</form><br>
			<?php

            $cod=$_GET["cod"];
            $sentencia3="SELECT * FROM empresas_proponentes where Codigo_Empresa='$cod';";

            $resultado3=mysqli_query($enlace,$sentencia3);
            $fila=mysqli_fetch_row($resultado3);
			echo "<script src='http://code.jquery.com/jquery-latest.min.js' type='text/javascript'></script>";
			echo "<link rel='stylesheet' href='css/estilos.css'/>";
			echo "<script src='script.js'></script>";
			echo "<script>";
			echo "function alerta(){";
			echo	"return confirm('¿Está seguro que desea modificar esta Empresa Proponente?');}";
			echo "</script>";
            echo"<form class='user' onSubmit='return alerta();' action='editarempre.php?cod=$cod' method='POST'>";
            echo" Nombre Empresa: <input class='form-control' name='nombreempresa' type='text' value='$fila[1]'> <br><br>";
            echo" RUC: <input class='form-control' name='ruc' type='text' value='$fila[2]'> <br><br>";
            echo" Grupo: <input class='form-control' name='grupo' type='text' value='$fila[3]'> <br><br>";
            echo" Usuario Responsable: <select class='form-control' name='usuarioresp'>";
				$sentenciauno="Select a.id_usuario,concat(b.nombres,' ',b.apellidos) from usuariosxperfil a, usuarios b where (a.cod_perfil=2) and (a.id_usuario=b.id)
				and (b.id=$fila[4]);";
				$resultadouno = mysqli_query($enlace,$sentenciauno);
				$registrocero = mysqli_fetch_row($resultadouno);
				echo  "<option value='$registrocero[0]'>$registrocero[1]</option>";
				$sentencia2="Select a.id_usuario,concat(b.nombres,' ',b.apellidos) from usuariosxperfil a, usuarios b where (a.cod_perfil=2) and (a.id_usuario=b.id)
				and (b.id<>$fila[4]);";
				$resultado2 = mysqli_query($enlace,$sentencia2);
				$contar= mysqli_num_rows($resultado2);
				if ($contar==0){
				   echo  "<option value=5>No hay otro usuario representante</option>";
				}
				else {
					for ($i=1; $i <= $contar; $i++){
					$registro = mysqli_fetch_row($resultado2);
					echo "<option value='$registro[0]'>$registro[1]</option>";
					
				}
				}
			echo "</select><br><br>";
            echo" Página web: <input class='form-control' name='paginaweb' type='text' value='$fila[5]'> <br><br>";
            echo" Experiencia: <input class='form-control' name='experiencia' type='text' value='$fila[6]'> <br><br>";
            echo" Teléfono de contacto: <input class='form-control' name='telefono' type='text' value='$fila[7]'> <br><br>";
            echo" Dirección: <input class='form-control' name='direccion' type='text' value='$fila[8]'> <br><br>";
            echo" Correo Empresa: <input class='form-control' name='correoemp' type='text' value='$fila[9]'> <br><br>";
            echo"  CEO: <input class='form-control' name='ceo' type='text' value='$fila[10]'> <br><br>";
            echo" Representante legal: <input class='form-control' name='representantelegal' type='text' value='$fila[11]'> <br><br>";

            echo "<input type='submit' value='Guardar' name='Guardar' class='d-none d-sm-inline-block btn btn-sm btn-primary shadow-sm'>";

            echo" </form>";
            ?>
					</div>
				</div>
			</div>
	  <?php
			include("../inc/menubajo.php");
			 }
	  ?>
</html>
