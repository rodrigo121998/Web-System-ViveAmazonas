<html lang="en">
		<?php

						session_start(); //inicio de sesión
						if (!isset($_SESSION["usuario"])){
							session_destroy();
							echo "<br><br> <font color='red'>Intento de acceso sin autorización!!!</font>";
							header("Location:../intranet.html");
							exit;
						}
			 else {
				 	include("../inc/menuarriba.php");
					$usuario= $_SESSION['usuario'];
			 /*$id_us= $_SESSION['id_us'];
			 $correo_us= $_SESSION['correo_us'];*/
					include("../inc/menu.php");
		 ?>
			<h1 class="h3 mb-2 text-gray-800">Relación de Concursos</h1>
			<p class="mb-4">En esta página se puede visualizar los concursos.</p>
			<script src="http://code.jquery.com/jquery-latest.min.js" type="text/javascript"></script>
			<link rel="stylesheet" href="../css/estilos.css"/>
			<script src="script.js"></script>
			<div class="card shadow mb-4">
				<div class="card-header py-3">
				  <h6 class="m-0 font-weight-bold text-primary">Tabla de Concursos</h6>
				</div>
				<div class="card-body">
					<div class="table-responsive">
			<form class="d-none d-sm-inline-block form-inline mr-auto ml-md-3 my-2 my-md-0 mw-100 navbar-search" action='CUS004.php' method='POST' enctype='multipart/form-data'>
				<div class="input-group">

						<input type='text' class="form-control bg-light border-0 small" name='concurso' placeholder='Buscando Concurso...'>
						<input type='submit' class="btn btn-primary" name='buscar' value="Buscar">
				</div>
			</form>
			<br><br>
			<?php
			if (!isset($_POST["buscar"])){
            $sentencia = "SELECT id FROM usuarios where usuario=$usuario";
			$resultado = mysqli_query($enlace,$sentencia);
			$registro2 = mysqli_fetch_row($resultado);
			
			$sentencia3 = "SELECT codigo_evaluador,Unidad FROM evaluadores  where usuario=$registro2[0]";
			$resultado3= mysqli_query($enlace,$sentencia3);
			$contar3= mysqli_num_rows($resultado3);
			$registro3 = mysqli_fetch_row($resultado3);
			
			
            $sentencia2= "SELECT codigo_concurso,nombre_concurso,fecha_inicio, fecha_fin FROM concurso where (estado='A');";
			$resultado2 = mysqli_query($enlace,$sentencia2);
            $contar= mysqli_num_rows($resultado2);
			
			
			
			

           if ($contar==0){
           echo  "No hay concursos <br>";
           }
           else {

           echo "<form action='' method= 'POST'>";
           echo "<table class='table table-bordered' id='dataTable' width='100%' cellspacing='0'>";
		   echo "<thead>";
           echo "	<tr>";
           echo "		<td>Codigo Concurso</td>";
           echo "		<td>Nombre Concurso</td>";
           echo "		<td>Fecha inicio</td>";
		   echo "		<td>Fecha fin</td>";
           echo "		<td>Opciones</td>";
		   
		   if($registro3[1]=='CTI'||$registro3[1]=='CTE'){
			echo "		<td>Informe técnico</td>";
			 echo "	</tr>";   
		   }
			else{
           echo "	</tr>";
			}

           for ($i=1; $i <= $contar; $i++){
             $registro = mysqli_fetch_row($resultado2);
			$sentencia4 ="SELECT b.Unidad FROM evaluadoresxconcurso a, evaluadores b WHERE b.codigo_evaluador=a.id_evaluador and a.id_concurso='$registro[0]' and b.usuario='$registro2[0]'";
			$resultado4= mysqli_query($enlace,$sentencia4);
			$contar4= mysqli_num_rows($resultado4); 
			$registro4 = mysqli_fetch_row($resultado4);
			$enviar=array($registro[0],$registro3[1]);
			$enviar = serialize($enviar);
			$enviar= urlencode($enviar);
             echo "	<tr>";
             echo "		<td>",$registro[0],"</td>";
             echo "		<td>",$registro[1],"</td>";
             echo "		<td>",$registro[2],"</td>";
			 echo "		<td>",$registro[3],"</td>";
			 
			 if ($contar3==0) {
				 echo "<td><a href='verconcursos.php?cod=$registro[0]' class='d-none d-sm-inline-block btn btn-sm btn-primary shadow-sm'>Consultar</a> <a href='../CUS008/CUS008.php?cod=$registro[0]' class='d-none d-sm-inline-block btn btn-sm btn-primary shadow-sm'>Ver proyectos</a></td> ";
			 }
            elseif($contar3==1) {		
                  if ($contar4==1){
				  echo "<td><a href='verconcursos.php?cod=$registro[0]' class='d-none d-sm-inline-block btn btn-sm btn-primary shadow-sm'>Consultar</a> 
				  <a href='../CUS008/CUS008.php?cod=$registro[0]' class='d-none d-sm-inline-block btn btn-sm btn-primary shadow-sm'>Ver proyectos</a>				  
					<a href='../CUS017/CUS017.php?cod=$registro[0]' class='d-none d-sm-inline-block btn btn-sm btn-primary shadow-sm'>Evaluar Concurso</a></td>";	    
				  if($registro3[1]=='CTI'){
				  $sentencia6="select count(*) from proyectos a, concurso b where b.codigo_concurso='$registro[0]' 
				  and a.Codigo_Concurso=b.codigo_concurso and (a.Estado_Proyecto in('Aprobado por DIGE'));";
				  $resultado6= mysqli_query($enlace,$sentencia6);
				  $registro6 = mysqli_fetch_row($resultado6);
				  if($registro6[0]==0){
					  echo"<td><a href='comunicar.php?cod=$enviar' class='d-none d-sm-inline-block btn btn-sm btn-primary shadow-sm'>Enviar informe</a></td>";
				  }
				  else{
					 echo"<td>No disponible</td>"; 
				  }
				  echo "	</tr>"; 
				  }
				  elseif($registro3[1]=='CTE'){
				  $sentencia6="select count(*) from proyectos a, concurso b where b.codigo_concurso='$registro[0]' 
				  and a.Codigo_Concurso=b.codigo_concurso and (a.Estado_Proyecto in('Aprobado por CTI'));";
				  $resultado6= mysqli_query($enlace,$sentencia6);
				  $registro6 = mysqli_fetch_row($resultado6);
				  if($registro6[0]==0){
					  echo"<td><a href='comunicar.php?cod=$enviar' class='d-none d-sm-inline-block btn btn-sm btn-primary shadow-sm'>Enviar informe</a></td>";
				  }
				  else{
					 echo"<td>No disponible</td>"; 
				  }
				  echo "	</tr>";
				  }
				  else{
           echo "	</tr>";
				  }
			}
			else{
				 echo "<td><a href='verconcursos.php?cod=$registro[0]' class='d-none d-sm-inline-block btn btn-sm btn-primary shadow-sm'>Consultar</a> 
				  <a href='../CUS008/CUS008.php?cod=$registro[0]' class='d-none d-sm-inline-block btn btn-sm btn-primary shadow-sm'>Ver proyectos</a></td>";

			}				 
			 }
			 
			 else{
				 echo "<td><a href='verconcursos.php?cod=$registro[0]' class='d-none d-sm-inline-block btn btn-sm btn-primary shadow-sm'>Consultar</a> 
				  <a href='../CUS008/CUS008.php?cod=$registro[0]' class='d-none d-sm-inline-block btn btn-sm btn-primary shadow-sm'>Ver proyectos</a></td>";
				  echo"<td>No evalúa este concurso</td>";
				 
			 }
             echo "	</tr>";

           }
		   echo "</tbody>";
           echo "</table>";

           }

             ?>

		  </form>
	  <?php
			}
			else {
			$concurso = $_POST['concurso'];
			echo"<form action='CUS004.php' enctype='multipart/form-data'>";


			if ($concurso==''){
				echo"No ha seleccionado ningún concurso";
			}
			else {
            $sentencia2= "SELECT codigo_concurso,nombre_concurso,fecha_inicio, fecha_fin FROM concurso where (estado='A') and
			nombre_concurso like '%$concurso%';";
			$resultado2 = mysqli_query($enlace,$sentencia2);
            $contar= mysqli_num_rows($resultado2);
           if ($contar==0){
           echo  "No hay concurso con ese nombre";
           }
           else {

           echo "<form action='' method= 'POST'>";
           echo "<table class='table table-bordered' id='dataTable' width='100%' cellspacing='0'>";
           echo "<thead>";
           echo "	<tr>";
           echo "		<td>Codigo Concurso</td>";
           echo "		<td>Nombre Concurso</td>";
           echo "		<td>Fecha inicio</td>";
		   echo "		<td>Fecha fin</td>";
           echo "		<td>Opciones</td>";
		   echo "	</tr>";
		   echo "</thead>";
		   echo "<tbody>";

           for ($i=1; $i <= $contar; $i++){
             $registro = mysqli_fetch_row($resultado2);


             echo "	<tr>";
             echo "		<td>",$registro[0],"</td>";
             echo "		<td>",$registro[1],"</td>";
             echo "		<td>",$registro[2],"</td>";
			 echo "		<td>",$registro[3],"</td>";
             echo "		<td> <a href='verconcursos.php?cod=$registro[0]' class='d-none d-sm-inline-block btn btn-sm btn-primary shadow-sm'>Consultar</a> <a href='../CUS008/CUS008.php?cod=$registro[0]' class='d-none d-sm-inline-block btn btn-sm btn-primary shadow-sm'>Ver proyectos</a>
			 <a href='../CUS017/CUS017.php?cod=$registro[0]' class='d-none d-sm-inline-block btn btn-sm btn-primary shadow-sm'>Evaluar Concurso</a></td>";  
             echo "	</tr>";

           }
		   echo "</tbody>";
           echo "</table>";

           }
			}

			echo" <br><br>";
			echo"<input type='submit' class='btn btn-primary' value='Regresar a relación de concursos'>";
			echo"</form>";

			 }
				echo"</div>";
			echo"</div>";
		echo"</div>";
			 			include("../inc/menubajo.php");
			 }
	  ?>
</html>
