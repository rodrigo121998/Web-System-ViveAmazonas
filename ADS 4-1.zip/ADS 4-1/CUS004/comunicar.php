<?php
session_start(); //inicio de sesión
			if (!isset($_SESSION["usuario"])){
				session_destroy();
				echo "<br><br> <font color='red'>Intento de acceso sin autorización!!!</font>";
				header("Location:../intranet.html");
				exit;
			}
ob_start();
require_once ('../dompdf/autoload.inc.php');

use Dompdf\Dompdf;
$enlace = mysqli_connect("localhost","root","","base_va");
$codigos = unserialize($_GET['cod']);
list($concurso,$unidad)=$codigos;
$sentencia="select nombre_concurso from concurso where codigo_concurso='$concurso'";
$resultado=mysqli_query($enlace,$sentencia);
$fila=mysqli_fetch_row($resultado);
$usuario = $_SESSION['usuario'];
$sentencia2="Select nombre_plantilla, texto from plantilla where tipo_Plantilla='Informe Técnico';";
$resultado2=mysqli_query($enlace,$sentencia2);
$fila2=mysqli_fetch_row($resultado2);
$html = html_entity_decode($fila2[1], ENT_QUOTES);
$sentencia6="Select concat(nombres,' ',apellidos) from usuarios where usuario='$usuario' ;";
$resultado6=mysqli_query($enlace,$sentencia6);
$fila6=mysqli_fetch_row($resultado6);

$hoy = date("F j, Y");


$html = str_replace('(UNIDAD)', $unidad, $html);
$html = str_replace('(NOMCON)', $fila[0], $html);
$html = str_replace('(NOMPERSONA)', $fila6[0], $html);
$html = str_replace('(FECHAACTUAL)', $hoy, $html);

$dompdf = new Dompdf();
$dompdf->loadHtml($html);
$dompdf->setPaper('A4', ''); // (Opcional) Configurar papel y orientación(horizontal=landscape)
$dompdf->render(); // Generar el PDF desde contenido HTML
$pdf = $dompdf->output(); // Obtener el PDF generado
//$dompdf->stream("rptDocumentoEntregados.pdf", array("Attachment" => false));
$pdf_name='Informetecnico.pdf';
file_put_contents($pdf_name,$pdf);
$sentencia3="update concurso set fecha_informe1=NOW()
where codigo_concurso='$concurso';";
$resultado3 = mysqli_query($enlace,$sentencia3);

require "../PHPMailer/class.phpmailer.php";
$mail = new PHPMailer();
$mail->isSMTP();
$mail->SMTPAuth = true;
$mail->SMTPSecure='tls';
$mail->Host = "smtp.gmail.com";
$mail->Port = '587';
$mail->SMTPDebug  = 2;
$mail->IsHTML(true);

$mail->Username = 'vive.amazonas.1@gmail.com';
$mail->Password = 'vive.amazonas123';		

$mail->ClearAddresses(); 	
$correo='rosoriol@pucp.edu.pe';
$mail->setFrom('vive.amazonas.1@gmail.com', 'Vive Amazonas');
$mail -> addAddress ( $correo,'Cliente' );
$mail->WordWrap=50;
$mail->addAttachment($pdf_name);
$subjects =  "Informe tecnico '$fila[0]' ";

$mail -> Subject = $subjects;
$mail ->  Body = " <b>Adjunto encontrará el informe técnico del concurso '$fila[0]'.</b><br>" ;	                 
if($mail-> send()) {
echo"Enviado";
}
unlink($pdf_name);
//header_remove();
header("Location:CUS004.php");
//header_remove();
ob_end_flush();

?>