<html>
<head> </head>
<body>
	<?php
			session_start(); //inicio de sesión
			if (!isset($_SESSION["usuario"])){
				session_destroy();
				echo "<br><br> <font color='red'>Intento de acceso sin autorización!!!</font>";
				header("Location:../intranet.html");
				exit;
			}
			$cod=$_GET["cod"];
			$enlace = mysqli_connect("localhost","root","","base_va");
            $sentencia="UPDATE concurso SET Estado='I' where codigo_concurso='$cod';";
            $resultado=mysqli_query($enlace,$sentencia);
			header("Location:CUS001concursos.php");
?>

</body>
</html>