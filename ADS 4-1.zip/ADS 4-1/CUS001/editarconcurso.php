
		<?php
				  session_start(); //inicio de sesión
					if (!isset($_SESSION["usuario"])){
						session_destroy();
						echo "<br><br> <font color='red'>Intento de acceso sin autorización!!!</font>";
						header("Location:../intranet.html");
						exit;
					}
					  $cod=$_GET["cod"];
					  $concurso = $_POST['concurso'];
					  $inicio = $_POST['inicio'];
					  $fin = $_POST['fin'];
					  $descripcion = $_POST['descripcion'];
					  $clasi = $_POST['clasi'];
					  $objetivos = $_POST['objetivos'];
					  $monto = $_POST['monto'];
					  $dirigido = $_POST['dirigido'];
					  $donador = $_POST['donador'];
					  $enlace = mysqli_connect("localhost","root","","base_va");
					 $sentencia="update concurso set nombre_concurso = '$concurso',
					 fecha_inicio= '$inicio',
					 fecha_fin = '$fin',
					 descripcion_concurso='$descripcion',
					 clasificacion = '$clasi',
					objetivos='$objetivos',
					monto_financiado='$monto', 
					dirigido_a='$dirigido',
					donador='$donador',
					fecha_informe1=DATE_ADD('$fin',INTERVAL 15 DAY),
					fecha_informe2=DATE_ADD('$fin',INTERVAL 22 DAY)
					 where codigo_concurso='$cod';";
					$resultado = mysqli_query($enlace,$sentencia);
					header("Location:CUS001concursos.php");
		?>