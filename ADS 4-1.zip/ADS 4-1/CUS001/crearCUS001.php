<html>
<head> </head>
<body>
<?php
			session_start(); //inicio de sesión
			if (!isset($_SESSION["usuario"])){
				session_destroy();
				echo "<br><br> <font color='red'>Intento de acceso sin autorización!!!</font>";
				header("Location:../intranet.html");
				exit;
			}
						
			  $concurso = $_POST['concurso'];
			  $inicio = $_POST['inicio'];
			  $fin = $_POST['fin'];
			  $descripcion = $_POST['descripcion'];
			  $clasi = $_POST['clasi'];
			  $nombre_imagen=$_FILES['imagen']['name'];
			  $tipo_imagen=$_FILES['imagen']['type'];
			  $tamano_imagen=$_FILES['imagen']['size'];
			  $carpeta_destino=$_SERVER['DOCUMENT_ROOT'].'/ADS 4/upload/';
			  move_uploaded_file($_FILES['imagen']['tmp_name'],$carpeta_destino.$nombre_imagen);
			  $imagen_objetivo=fopen($carpeta_destino.$nombre_imagen,'r');
			  $contenido_imagen=fread($imagen_objetivo,$tamano_imagen);
			  $contenido_imagen=addslashes($contenido_imagen);
			  fclose($imagen_objetivo);
			  $objetivos = $_POST['objetivos'];
			  $monto = $_POST['monto'];
			  $dirigido = $_POST['dirigido'];
			  $donador = $_POST['donador'];
			  $nombre_bases=$_FILES['bases']['name'];
			  $tipo_bases=$_FILES['bases']['type'];
			  $tamano_bases=$_FILES['bases']['size'];
			  move_uploaded_file($_FILES['bases']['tmp_name'],$carpeta_destino.$nombre_bases);
			  $bases_objetivo=fopen($carpeta_destino.$nombre_bases,'r');
			  $contenido_bases=fread($bases_objetivo,$tamano_bases);
			  $contenido_bases=addslashes($contenido_bases);
			  fclose($bases_objetivo);
			$enlace = mysqli_connect("localhost","root","","base_va");
			$sentencia="INSERT INTO concurso(nombre_concurso,fecha_inicio,fecha_fin,descripcion_concurso,clasificacion,imagen,
						objetivos,monto_financiado,dirigido_a,donador,base_concurso,tipo_imagen,tipo_base,fecha_informe1,fecha_informe2)
						VALUES ('$concurso','$inicio','$fin','$descripcion','$clasi','$contenido_imagen','$objetivos','$monto',
						'$dirigido','$donador','$contenido_bases','$tipo_imagen','$tipo_bases',DATE_ADD('$fin',INTERVAL 15 DAY),DATE_ADD('$fin',INTERVAL 22 DAY));";
			$resultado = mysqli_query($enlace,$sentencia);
              header("Location:CUS001concursos.php");

             ?>
</body>
</html>