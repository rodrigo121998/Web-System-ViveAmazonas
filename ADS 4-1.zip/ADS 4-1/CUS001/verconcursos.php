<html lang="en">
	<?php
			session_start(); //inicio de sesión
			if (!isset($_SESSION["usuario"])){
				session_destroy();
				echo "<br><br> <font color='red'>Intento de acceso sin autorización!!!</font>";
				header("Location:../intranet.html");
				exit;
			}
			 else {
				include("../inc/menuarriba.php");
			 /*$id_us= $_SESSION['id_us'];
			 $correo_us= $_SESSION['correo_us'];*/
				include("../inc/menu.php");
	 ?>
			<h1 class="h3 mb-2 text-gray-800">Ver datos de concursos</h1>
			<p class="mb-4">En esta página se puede consultar los concursos.</p>
			<div class="card shadow mb-4">
				<div class="card-header py-3">
				  <h6 class="m-0 font-weight-bold text-primary">Consulta de Concursos</h6>
				</div>
				<div class="card-body">
					<div class="table-responsive">
			<?php

            $cod=$_GET["cod"];
            $sentencia="SELECT * FROM concurso where codigo_concurso='$cod';";

            $resultado=mysqli_query($enlace,$sentencia);
            $fila=mysqli_fetch_row($resultado);

            echo"<form class='user' action='CUS001concursos.php' enctype='multipart/form-data'>";
            echo"Nombre Concurso: <input class='form-control' name='concurso' type='text' value='$fila[1]' readonly> <br><br>";
			echo"Fecha inicio del concurso: <input class='form-control' name='inicio' type='date' value='$fila[2]' readonly> <br><br>";
			echo"Fecha fin del concurso: <input class='form-control' name='fin' type='date' value='$fila[3]' readonly> <br><br>";
			echo"Descripción del concurso:<br>";
			echo"<textarea class='form-control' name='descripcion' rows='10' cols='40' value='$fila[5]' readonly>$fila[5]</textarea>";
			echo"<br><br>";
			echo"Clasificación <input class='form-control' name='clasi' type='text' value='$fila[4]' readonly> <br><br>";
			echo"Imagen: ";
			if ($fila[6]<>NULL){
			echo"<a href='descargar_imagen.php?cod=$cod' class='d-none d-sm-inline-block btn btn-sm btn-primary shadow-sm'>Imagen</a><br><br>"; 
			} else {
				echo "No hay archivo subido<br><br>";
			}
			echo"Objetivos:<br>";
			echo"<textarea class='form-control' name='objetivos' rows='10' cols='40' value='$fila[7]' readonly>$fila[7]</textarea>";
			echo"<br><br>";
			echo"Monto financiado: <input class='form-control' name='monto' type='number' value='$fila[8]' readonly> <br><br>";
			echo"¿A quién se encuentra dirigido?: <input class='form-control' name='dirigido' type='text' value='$fila[9]' readonly> <br><br>";
				$sentencia4="Select IDDonante,Nombre_donante from donantes where (estado='A') and (IDDonante='$fila[10]');";
				$resultado4 = mysqli_query($enlace,$sentencia4);
				$registro4 = mysqli_fetch_row($resultado4);
			echo"Donador: <input class='form-control' name='donador' value='$registro4[1]' readonly> <br><br>";
            echo"Bases de concurso: "; 
			if ($fila[11]<>NULL){
			echo"<a href='descargar_bases.php?cod=$cod' class='d-none d-sm-inline-block btn btn-sm btn-primary shadow-sm'>Bases</a><br><br>";
			} else{
				echo "No hay archivo subido<br><br>";
			}
            echo "<input type='submit' value='Terminado' name='Terminado' class='d-none d-sm-inline-block btn btn-sm btn-primary shadow-sm'>";

            echo" </form>";
            ?>
			
					</div>
				</div>
			</div>
	  <?php
			include("../inc/menubajo.php");
			 }
	  ?>
</html>
