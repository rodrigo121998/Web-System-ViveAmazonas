<html lang="en">
	<?php
			session_start(); //inicio de sesión
			if (!isset($_SESSION["usuario"])){
				session_destroy();
				echo "<br><br> <font color='red'>Intento de acceso sin autorización!!!</font>";
				header("Location:../intranet.html");
				exit;
			}
			 else {
				include("../inc/menuarriba.php");
			 /*$id_us= $_SESSION['id_us'];
			 $correo_us= $_SESSION['correo_us'];*/
				include("../inc/menu.php");
	 ?>
			<h1 class="h3 mb-2 text-gray-800">Creación de concurso</h1>
			<p class="mb-4">En esta página se puede crear los concursos.</p>
			<script src="http://code.jquery.com/jquery-latest.min.js" type="text/javascript"></script>
			<link rel="stylesheet" href="../css/estilos.css"/>
			<script src="script.js"></script>
			<script>
				function alerta()
				{
					return confirm("¿Esta seguro que desea crear este concurso?");
				}
			</script>
			<div class="card shadow mb-4">
				<div class="card-header py-3">
				  <h6 class="m-0 font-weight-bold text-primary">Creación de Concursos</h6>
				</div>
				<div class="card-body">
					<div class="table-responsive">
			<form action='CUS001concursos.php'>
			<input type='submit' value="Regresar a relación de concursos" class='d-none d-sm-inline-block btn btn-sm btn-primary shadow-sm'>
			</form><br>
            <form class="user" onSubmit='return alerta();' action='crearCUS001.php' method="POST" enctype='multipart/form-data'>
            Nombre Concurso: <input class="form-control" placeholder='Nombre del concurso' name="concurso" type="text"> <br><br>
			Fecha inicio del concurso: <input class="form-control" name='inicio' type='date'> <br><br>
			Fecha fin del concurso: <input class="form-control" name='fin' type='date'> <br><br>
			Descripción del concurso:<br>
			<textarea  class="form-control" name="descripcion" rows="5" placeholder='Escribe aquí la descripción'></textarea>
			<br><br>
			Clasificación <input class="form-control" name="clasi" type="text"> <br><br>
			Imagen: <input name="imagen" class="form-control-file" type="file" accept=".jpg,.png"><br><br>
			Objetivos:<br>
			<textarea name="objetivos" class="form-control" rows="5" placeholder='Escribe aquí los objetivos'></textarea>
			<br><br>
			Monto financiado: <input class="form-control" name="monto" type="number"> <br><br>
			¿A quién se encuentra dirigido?: <input class="form-control" name="dirigido" type="text"> <br><br>
			Donador: <select class="form-control"  name="donador">
				<option value="">Elige una opción</option>
				<?php
				$sentencia2="Select IDDonante,Nombre_donante from donantes where estado='A';";
				$resultado2 = mysqli_query($enlace,$sentencia2);
				$contar= mysqli_num_rows($resultado2);
				if ($contar==0){
				   echo  "<option value=''>No hay donantes</option>";
				}
				else {
					for ($i=1; $i <= $contar; $i++){
					$registro = mysqli_fetch_row($resultado2);
					echo "<option value=$registro[0]>$registro[1]</option>";
					
				}
				}
				?>				
			</select><br><br>
            Bases de concurso: <input name="bases"  class="form-control-file" type="file" accept=".jpg,.png,application/msword,application/pdf"> <br><br>
            <input type='submit' value='Guardar' name='Guardar' class='d-none d-sm-inline-block btn btn-sm btn-primary shadow-sm'>

            </form>
					</div>
				</div>
			</div>
	  <?php
				include("../inc/menubajo.php");
			 }
	  ?>
</html>