<?php
	$cod = unserialize($_GET['cod']);
	$enlace = mysqli_connect("localhost","root","","base_va");
	if ($cod==""){
		
		$sentencia2="SELECT a.Codigo_Empresa, a.Nombre_Empresa, a.RUC, a.Grupo,b.usuario, a.Pagina_web
			FROM empresas_proponentes a,usuarios b where a.Estado='A' and a.ID_Representante=b.id;";
        $resultado2 = mysqli_query($enlace,$sentencia2);
		$numFilas = mysqli_num_rows($resultado2);
		
		if ($numFilas == 0) {
			echo "No hay empresas proponentes <br>";
		}
		else {
			echo "<br><br>";
			//Inicio de exportación en Excel
			header('Content-type: application/vnd.ms-excel');
			header("Content-Disposition: attachment; filename=Reporteprop.xls"); //Indica el nombre del archivo resultante
			header("Pragma: no-cache");
			header("Expires: 0");
			echo "<table align='center'>";
			echo "<thead>";
			echo "	<tr>";
           echo "		<td>Codigo Concurso</td>";
           echo "		<td>Nombre Concurso</td>";
           echo "		<td>Fecha inicio</td>";
		   echo "		<td>Fecha fin</td>";						
			echo "	</tr>";
			echo "</thead>";
			echo "<tbody>";
							
			/*Estoy definiendo una iteración*/
			for ($i=1; $i <= $numFilas; $i++){
				/*Esta función permite obtener un registro (fila) del resultado de un query*/
				$registro = mysqli_fetch_row($resultado2);
				echo "	<tr>";
				echo "		<td style='visibility:collapse;'>",$registro[0],"</td>";
				echo "		<td>",$registro[0],"</td>";
             echo "		<td>",$registro[1],"</td>";
             echo "		<td>",$registro[2],"</td>";
				echo "	</tr>";					
			}
			echo "</tbody>";
			echo "</table>";
		}
	}
	else {
			echo "<br><br>";
			header('Content-type: application/vnd.ms-excel');
			header("Content-Disposition: attachment; filename=Reporteprop.xls"); //Indica el nombre del archivo resultante
			header("Pragma: no-cache");
			header("Expires: 0");
			echo "<table align='center'>";
			echo "<thead>";
			echo "	<tr>";
           echo "		<td>Codigo Concurso</td>";
           echo "		<td>Nombre Concurso</td>";
           echo "		<td>Fecha inicio</td>";
		   echo "		<td>Fecha fin</td>";							
			echo "	</tr>";
			echo "</thead>";
			echo "<tbody>";
								
			/*Estoy definiendo una iteración*/
			foreach ($cod as $codigo){
				/*Esta función permite obtener un registro (fila) del resultado de un query*/
				$sentencia2="SELECT a.Codigo_Empresa, a.Nombre_Empresa, a.RUC, a.Grupo,b.usuario, a.Pagina_web
				FROM empresas_proponentes a,usuarios b where a.Estado='A' and a.ID_Representante=b.id and a.Codigo_Empresa='$codigo';";
				$resultado2 = mysqli_query($enlace,$sentencia2);
				$registro = mysqli_fetch_row($resultado2);
				echo "	<tr>";
				echo "		<td style='visibility:collapse;'>",$registro[0],"</td>";
				echo "		<td>",$registro[0],"</td>";
             echo "		<td>",$registro[1],"</td>";
             echo "		<td>",$registro[2],"</td>";
				echo "	</tr>";					
			}
			echo "</tbody>";
			echo "</table>";
		
	}
?>