<?php
			session_start(); //inicio de sesión
					if (!isset($_SESSION["usuario"])){
						session_destroy();
						echo "<br><br> <font color='red'>Intento de acceso sin autorización!!!</font>";
						header("Location:../intranet.html");
						exit;
					}
			$cod=$_GET["cod"];
			$nombre_bases=$_FILES['bases']['name'];
			$tipo_bases=$_FILES['bases']['type'];
			$tamano_bases=$_FILES['bases']['size'];
			$carpeta_destino=$_SERVER['DOCUMENT_ROOT'].'/ADS 4/upload/';
			move_uploaded_file($_FILES['bases']['tmp_name'],$carpeta_destino.$nombre_bases);
			$bases_objetivo=fopen($carpeta_destino.$nombre_bases,'r');
			$contenido_bases=fread($bases_objetivo,$tamano_bases);
			$contenido_bases=addslashes($contenido_bases);
			fclose($bases_objetivo);
			$enlace = mysqli_connect("localhost","root","","base_va");
			$sentencia="update concurso set base_concurso='$contenido_bases',
			tipo_base='$tipo_bases' where codigo_concurso='$cod';";
			$resultado = mysqli_query($enlace,$sentencia);
			header("Location:modificarconcursos.php?cod=$cod");
?>