<html>
		<?php

		 session_start(); //inicio de sesión
						if (!isset($_SESSION["usuario"])){
							session_destroy();
							echo "<br><br> <font color='red'>Intento de acceso sin autorización!!!</font>";
							header("Location:../intranet.html");
							exit;
						}
			 else {
				 include("../inc/menuarriba.php");
			 /*$id_us= $_SESSION['id_us'];
			 $correo_us= $_SESSION['correo_us'];*/
					include("../inc/menu.php");
					$cod=$_GET['cod'];
		 ?>
			<h1 class="h3 mb-2 text-gray-800">Proyectos disponibles para postulación</h1>
			<p class="mb-4">En esta página puede seleccionar el proyecto con el que desea postular</p>
			<script src="http://code.jquery.com/jquery-latest.min.js" type="text/javascript"></script>
			<link rel="stylesheet" href="../css/estilos.css"/>
			<script src="script.js"></script>
			<script>
				function alerta()
				{
					return confirm("¿Esta seguro que desea postular con este proyecto?");
				}
			</script>
			<div class="card shadow mb-4">
				<div class="card-header py-3">
				  <h6 class="m-0 font-weight-bold text-primary">Tabla de Proyectos disponibles</h6>
				</div>
				<div class="card-body">
					<div class="table-responsive">
			<?php		
			echo"<form class='d-none d-sm-inline-block form-inline mr-auto ml-md-3 my-2 my-md-0 mw-100 navbar-search' action='postularproyectos.php?cod=$cod' method='POST' enctype='multipart/form-data'>";
			?>	
				<div class="input-group">
					<input type='text' class="form-control bg-light border-0 small" name='proyecto' placeholder='Buscar proyecto...'>
					<input type='submit' class="btn btn-primary" name='buscar' value="Buscar proyecto" ><br><br>
				</div>
			</form>
			<br><br>
			<?php



			if (!isset($_POST["buscar"])){
            $sentencia2= "SELECT Codigo_Proyecto,Nombre_Proyecto FROM proyectos a,empresas_proponentes b, (select id from usuarios where usuario='$usuario') c 
			where (a.Estado NOT IN('I')) and b.ID_Representante=c.id and b.Codigo_Empresa=a.Codigo_Proponente and b.Estado='A' and a.Estado_Proyecto='Por enviar';";
			$resultado2 = mysqli_query($enlace,$sentencia2);
            $contar= mysqli_num_rows($resultado2);
			echo "<script src='http://code.jquery.com/jquery-latest.min.js' type='text/javascript'></script>";
			echo "<link rel='stylesheet' href='../css/estilos.css'/>";
			echo "<script src='script.js'></script>";
			echo "<script>";
			echo "function alerta(){";
			echo"return confirm('¿Está seguro que desea postular con este proyecto?');}";
			echo "</script>";
           echo"<form  action='CUS00406.php' method='POST'>";
		   if ($contar==0){
           echo  "No hay proyectos <br><br>";
           }

           else {

           echo "<form action='' method= 'POST'>";
           echo "<table class='table table-bordered' id='dataTable' width='100%' cellspacing='0'>";
           echo "<thead>";
		   echo "	<tr>";
           echo "		<td>Codigo Proyecto</td>";
           echo "		<td>Nombre Proyecto</td>";
           echo "		<td>Seleccionar</td>";
           echo "	</tr>";
			echo "</thead>";
		   echo "<tbody>";
           for ($i=1; $i <= $contar; $i++){
             $registro = mysqli_fetch_row($resultado2);


             echo "	<tr>";
             echo "		<td>",$registro[0],"</td>";
             echo "		<td>",$registro[1],"</td>";
			 $cod=$_GET["cod"];
			 $codigos=array($cod,$registro[0]);
			 $codigos = serialize($codigos);
			$codigos = urlencode($codigos);
			 
			echo "		<td><a class='btn btn-primary' onclick='return alerta();'href='enviarproyecto.php?codigos=$codigos'>Enviar</a></td>";

						 echo "	</tr>";

           }
		   echo "</tbody>";
           echo "</table>";

           }
					 $i=0;
             ?>
			<input type='submit' class="btn btn-primary" value="Regresar a relación de concursos" >
		  </form>

	  <?php
			}
			 else {
			$proyecto = $_POST['proyecto'];
			echo"<form action='CUS00406.php' enctype='multipart/form-data'>";
			if ($proyecto==''){
				echo"No ha seleccionado ningún proyecto";
			}
			else {
            $sentencia2= "SELECT Codigo_Proyecto,Nombre_Proyecto FROM proyectos a,empresas_proponentes b, (select id from usuarios where usuario='$usuario') c 
			where (a.Estado NOT IN('I')) and b.ID_Representante=c.id and b.Codigo_Empresa=a.Codigo_Proponente and b.Estado='A' and a.Estado_Proyecto='Por enviar' and a.Nombre_Proyecto like '%$proyecto%';";
			$resultado2 = mysqli_query($enlace,$sentencia2);
            $contar= mysqli_num_rows($resultado2);
           if ($contar==0){
           echo  "No hay proyectos con ese nombre<br>";
           }
           else {

           echo "<form action='' method= 'POST'>";
           echo "<table class='table table-bordered' id='dataTable' width='100%' cellspacing='0'>";
           echo "<thead>";
		   echo "	<tr>";
           echo "		<td>Codigo Proyecto</td>";
           echo "		<td>Nombre Proyecto</td>";
           echo "		<td>Seleccionar</td>";
           echo "	</tr>";
		   echo "</thead>";
		   echo "<tbody>";
           for ($i=1; $i <= $contar; $i++){
             $registro = mysqli_fetch_row($resultado2);


             echo "	<tr>";
             echo "		<td>",$registro[0],"</td>";
             echo "		<td>",$registro[1],"</td>";
			 			 $cod=$_GET["cod"];
			 $codigos=array($cod,$registro[0]);
			 $codigos = serialize($codigos);
			$codigos = urlencode($codigos);
			 
			 
			echo "		<td><a class='btn btn-primary' onclick='return alerta();'href='enviarproyecto.php?codigos=$codigos'>Enviar</a></td>";
						 echo "	</tr>";

           }
		   echo "</tbody>";
           echo "</table>";

           }
			}

			echo" <br><br>";
			echo"<input type='submit' class='btn btn-primary' value='Regresar a relación de concursos'>";
			echo"</form>";


		 }
				echo"</div>";
			echo"</div>";
		echo"</div>";
			 include("../inc/menubajo.php");
			 }

	  ?>
</html>
