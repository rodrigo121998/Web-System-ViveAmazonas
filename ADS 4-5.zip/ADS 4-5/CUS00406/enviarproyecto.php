<html>
<head> </head>
<body>
	<?php
			session_start(); //inicio de sesión
			if (!isset($_SESSION["usuario"])){
				session_destroy();
				echo "<br><br> <font color='red'>Intento de acceso sin autorización!!!</font>";
				header("Location:../intranet.html");
				exit;
			}

			$codigos = unserialize($_GET['codigos']);
			list($cod,$proyecto)=$codigos;
			//echo"$concurso<br>";
			//echo"$proyecto";
			$enlace = mysqli_connect("localhost","root","","base_va");
				$sentencia3="UPDATE proyectos SET Estado_Proyecto= 'Enviado', Codigo_Concurso=$cod, FechaEnvio=Now() WHERE Codigo_Proyecto=$proyecto;";
				$consulta3=mysqli_query($enlace,$sentencia3);
			header("Location:postularproyectos.php?cod=$cod");

?>

</body>
</html>
