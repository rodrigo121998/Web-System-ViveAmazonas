<html lang="en">
		<?php

						session_start(); //inicio de sesión
						if (!isset($_SESSION["usuario"])){
							session_destroy();
							echo "<br><br> <font color='red'>Intento de acceso sin autorización!!!</font>";
							header("Location:../intranet.html");
							exit;
						}
			 else {
				 	include("../inc/menuarriba.php");
			 /*$id_us= $_SESSION['id_us'];
			 $correo_us= $_SESSION['correo_us'];*/
					include("../inc/menu.php");
		 ?>
			<h1 class="h3 mb-2 text-gray-800">Relación de Concursos</h1>
			<p class="mb-4">En esta página se puede visualizar los concursos.</p>
			<script src="http://code.jquery.com/jquery-latest.min.js" type="text/javascript"></script>
			<link rel="stylesheet" href="../css/estilos.css"/>
			<script src="script.js"></script>
			<div class="card shadow mb-4">
				<div class="card-header py-3">
				  <h6 class="m-0 font-weight-bold text-primary">Tabla de Concursos</h6>
				</div>
				<div class="card-body">
					<div class="table-responsive">
			<form class="d-none d-sm-inline-block form-inline mr-auto ml-md-3 my-2 my-md-0 mw-100 navbar-search" action='CUS00406.php' method='POST' enctype='multipart/form-data'>
				<div class="input-group">

						<input type='text' class="form-control bg-light border-0 small" name='concurso' placeholder='Buscando Concurso...'>
						<input type='submit' class="btn btn-primary" name='buscar' value="Buscar">
				</div>
			</form>
			<br><br>
			<?php
			if (!isset($_POST["buscar"])){
			$sentencia0="Call actualizarcon(NOW());";
			$resultado0 = mysqli_query($enlace,$sentencia0);
            $sentencia2= "SELECT codigo_concurso,nombre_concurso,fecha_inicio, fecha_fin,estado FROM concurso where (estado IN ('A','C'));";
			$resultado2 = mysqli_query($enlace,$sentencia2);
            $contar= mysqli_num_rows($resultado2);

           if ($contar==0){
           echo  "No hay concursos <br>";
           }
           else {

           echo "<form action='' method= 'POST'>";
           echo "<table class='table table-bordered' id='dataTable' width='100%' cellspacing='0'>";
		   echo "<thead>";
           echo "	<tr>";
           echo "		<td>Codigo Concurso</td>";
           echo "		<td>Nombre Concurso</td>";
           echo "		<td>Fecha inicio</td>";
		   echo "		<td>Fecha fin</td>";
           echo "		<td>Opciones</td>";
           echo "	</tr>";


           for ($i=1; $i <= $contar; $i++){
             $registro = mysqli_fetch_row($resultado2);


             echo "	<tr>";
             echo "		<td>",$registro[0],"</td>";
             echo "		<td>",$registro[1],"</td>";
             echo "		<td>",$registro[2],"</td>";
			 echo "		<td>",$registro[3],"</td>";
			 if($registro[4]=='A'){
             echo "		<td>  <a href='verconcursos.php?cod=$registro[0]' class='d-none d-sm-inline-block btn btn-sm btn-primary shadow-sm'>Consultar</a> 
			 <a href='postularproyectos.php?cod=$registro[0]' class='d-none d-sm-inline-block btn btn-sm btn-primary shadow-sm'>Postular</a></td>";
             }
			 else{
			echo "		<td>  <a href='verconcursos.php?cod=$registro[0]' class='d-none d-sm-inline-block btn btn-sm btn-primary shadow-sm'>Consultar</a></td>";	 
			 }
			 echo "	</tr>";

           }
		   echo "</tbody>";
           echo "</table>";

           }

             ?>

		  </form>
	  <?php
			}
			else {
			$concurso = $_POST['concurso'];
			echo"<form action='CUS00406.php' enctype='multipart/form-data'>";


			if ($concurso==''){
				echo"No ha seleccionado ningún concurso";
			}
			else {
            $sentencia2= "SELECT codigo_concurso,nombre_concurso,fecha_inicio, fecha_fin FROM concurso where (estado IN ('A','C')) and
			nombre_concurso like '%$concurso%';";
			$resultado2 = mysqli_query($enlace,$sentencia2);
            $contar= mysqli_num_rows($resultado2);
           if ($contar==0){
           echo  "No hay concurso con ese nombre";
           }
           else {

           echo "<form action='' method= 'POST'>";
           echo "<table class='table table-bordered' id='dataTable' width='100%' cellspacing='0'>";
           echo "<thead>";
           echo "	<tr>";
           echo "		<td>Codigo Concurso</td>";
           echo "		<td>Nombre Concurso</td>";
           echo "		<td>Fecha inicio</td>";
		   echo "		<td>Fecha fin</td>";
           echo "		<td>Opciones</td>";
		   echo "	</tr>";
		   echo "</thead>";
		   echo "<tbody>";

           for ($i=1; $i <= $contar; $i++){
             $registro = mysqli_fetch_row($resultado2);


             echo "	<tr>";
             echo "		<td>",$registro[0],"</td>";
             echo "		<td>",$registro[1],"</td>";
             echo "		<td>",$registro[2],"</td>";
			 echo "		<td>",$registro[3],"</td>";
			  if($registro[4]=='A'){
             echo "		<td>  <a href='verconcursos.php?cod=$registro[0]' class='d-none d-sm-inline-block btn btn-sm btn-primary shadow-sm'>Consultar</a> 
			 <a href='postularproyectos.php?cod=$registro[0]' class='d-none d-sm-inline-block btn btn-sm btn-primary shadow-sm'>Postular</a></td>";
             }
			 else{
			echo "		<td>  <a href='verconcursos.php?cod=$registro[0]' class='d-none d-sm-inline-block btn btn-sm btn-primary shadow-sm'>Consultar</a></td>";	 
			 }
             echo "	</tr>";

           }
		   echo "</tbody>";
           echo "</table>";

           }
			}

			echo" <br><br>";
			echo"<input type='submit' class='btn btn-primary' value='Regresar a relación de concursos'>";
			echo"</form>";

			 }
				echo"</div>";
			echo"</div>";
		echo"</div>";
			 			include("../inc/menubajo.php");
			 }
	  ?>
</html>
