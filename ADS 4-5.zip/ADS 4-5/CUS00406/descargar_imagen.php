<?php
$cod=$_GET["cod"];
$enlace = mysqli_connect("localhost","root","","base_va");
$sentencia="Select tipo_imagen,imagen from concurso where codigo_concurso=$cod;";
$resultado = mysqli_query($enlace,$sentencia);
$fila=mysqli_fetch_row($resultado);
header("Content-type: $fila[0]");
echo $fila[1];
?>