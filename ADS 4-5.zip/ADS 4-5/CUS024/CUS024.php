<html lang="en">
	
		<?php
		
		session_start(); //inicio de sesión
		if (!isset($_SESSION["usuario"])){
			session_destroy();
			echo "<br><br> <font color='red'>Intento de acceso sin autorización!!!</font>";
			header("Location:../intranet.html");
			exit;
		}
			
		else {
			include("../inc/menuarriba.php");
		 /*$id_us= $_SESSION['id_us'];
		 $correo_us= $_SESSION['correo_us'];*/
			include("../inc/menu.php");
			
		?>
			<h1 class="h3 mb-2 text-gray-800">Relación de negociaciones</h1>
			<p class="mb-4">En esta página se puede consultar las negociaciones</p>
			<script src="http://code.jquery.com/jquery-latest.min.js" type="text/javascript"></script>
			<link rel="stylesheet" href="../css/estilos.css"/>
			<script src="script.js"></script>
			<script>
			
				
				</script>
				<div class="card shadow mb-4">
					<div class="card-header py-3">
					  <h6 class="m-0 font-weight-bold text-primary">Tabla de negociaciones</h6>
					</div>
					<div class="card-body">
						<div class="table-responsive">
				<form class="d-none d-sm-inline-block form-inline mr-auto ml-md-3 my-2 my-md-0 mw-100 navbar-search" action='CUS024.php' method='POST' enctype='multipart/form-data'>
					<div class="input-group">
				
							<input type='text' class="form-control bg-light border-0 small" name='negociacion' placeholder='Buscar negociación...'>  
							<input type='submit' class="btn btn-primary" name='buscar' value="Buscar">
					</div>
				</form>
				<br><br>
				<?php
				if (!isset($_POST["buscar"])){
				
		
				$sentencia= "SELECT n.codigo_negociacion, n.fecha_inicio_convenio,p.Nombre_Proyecto,c.nombre_concurso,n.fecha_negociacion,n.fecha_fin_convenio 
				FROM negociaciones as n, proyectos as p, concurso as c, (select id from usuarios where usuario='$usuario')as u,empresas_proponentes as e  
				WHERE n.estado='E' and n.codigo_proyecto=p.Codigo_Proyecto and p.Codigo_Concurso=c.codigo_concurso and p.Codigo_Proponente=e.Codigo_Empresa  
				and e.ID_Representante=u.id;";
				$resultado= mysqli_query($enlace,$sentencia);
				$contar= mysqli_num_rows($resultado);								
												
				
							
				if ($contar==0){
				echo  "No hay negociaciones <br>";
					}
				else {

				echo "<form action='' method= 'POST'>";
				echo "<table class='table table-bordered' id='dataTable' width='100%' cellspacing='0'>";
				echo "<thead>";
				echo "	<tr>";
				echo "		<td>Nombre Proyecto</td>";
				echo "		<td>Nombre Concurso</td>";
				echo "		<td>Fecha Negociación</td>";
				echo "		<td>Inicio Convenio</td>";
				echo "		<td>Fin Convenio</td>";
				echo "		<td>Convenio de Donación</td>";
				echo "	</tr>";
				
				$ruta = 'documento.php?codigo_negociacion=';
				
				for ($i=1; $i <= $contar; $i++){
				$registro = mysqli_fetch_row($resultado);

				
				
				echo "	<tr>";
				echo "		<td>",$registro[2],"</td>";
				echo "		<td>",$registro[3],"</td>";
				echo "		<td>",$registro[4],"</td>";
				echo "		<td>",$registro[1],"</td>";
				echo "		<td>",$registro[5],"</td>";
				
				?>
				<td><a href="<?php echo $ruta.$registro[0]; ?>" >Ver Convenio</a></td>
				<?php
				echo "	</tr>";	
				
				}
				echo "</tbody>";
				echo "</table>";
				
				}
            ?>
			
			</form>
			<?php
			}
			else { 
			$negociacion = $_POST['negociacion'];
			echo"<form action='CUS024.php' enctype='multipart/form-data'>";
	  
			
            if ($negociacion==''){
				echo"No ha seleccionado ninguna negociacion";
			}
			else {
			
			$sentencia2= "SELECT n.codigo_negociacion, n.fecha_inicio_convenio,p.Nombre_Proyecto,c.nombre_concurso,n.fecha_negociacion,n.fecha_fin_convenio 
				FROM negociaciones as n, proyectos as p, concurso as c, (select id from usuarios where usuario='$usuario')as u,empresas_proponentes as e  
				WHERE n.estado='E' and n.codigo_proyecto=p.Codigo_Proyecto and p.Codigo_Concurso=c.codigo_concurso and p.Codigo_Proponente=e.Codigo_Empresa  
				and e.ID_Representante=u.id and (p.Nombre_Proyecto LIKE '%$negociacion%' OR c.nombre_concurso LIKE '%$negociacion%');";
				
			$resultado2 = mysqli_query($enlace,$sentencia2);
            $contar= mysqli_num_rows($resultado2);
			
			   if ($contar==0){
			   echo  "No hay negociaciones coincidentes <br>";
				}
			   
			   else { 
			    echo "<form action='' method= 'POST'>";
				echo "<table class='table table-bordered' id='dataTable' width='100%' cellspacing='0'>";
				echo "<thead>";
				echo "	<tr>";
				echo "		<td>Nombre Proyecto</td>";
				echo "		<td>Nombre Concurso</td>";
				echo "		<td>Fecha Negociación</td>";
				echo "		<td>Inicio Convenio</td>";
				echo "		<td>Fin Convenio</td>";
				echo "		<td>Convenio de Donación</td>";
				echo "	</tr>";
				echo "</thead>";
				echo "<tbody>";
				
				$ruta = 'documento.php?codigo_negociacion=';
				
				for ($i=1; $i <= $contar; $i++){
				
				$registro = mysqli_fetch_row($resultado2);
				
				echo "	<tr>";
				echo "		<td>",$registro[2],"</td>";
				echo "		<td>",$registro[3],"</td>";
				echo "		<td>",$registro[4],"</td>";
				echo "		<td>",$registro[1],"</td>";
				echo "		<td>",$registro[5],"</td>";
				
				?>
				<td><a href="<?php echo $ruta.$registro[0]; ?>" >Ver Convenio</a></td>
				<?php
				echo "	</tr>";	
				
				}
				echo "</tbody>";
				echo "</table>";
				
				}
			}
			echo" <br><br>";
			echo"<input type='submit' class='btn btn-primary' value='Regresar a relación de negociaciones'>";
			echo"</form>";
           
	
			 }
			 echo"</div>";
			echo"</div>";
		echo"</div>";
			 			include("../inc/menubajo.php");
			 }
	  ?>		
</html>
