<?php

$codigo_negociacion=$_GET["codigo_negociacion"];

$enlace = mysqli_connect("localhost","root","","base_va");

$sentencia="Select tipo_convenio,convenio_donacion from negociaciones where codigo_negociacion=$codigo_negociacion;";

$resultado = mysqli_query($enlace,$sentencia);

$fila=mysqli_fetch_row($resultado);

header("Content-type: $fila[0]");

echo $fila[1];

?>