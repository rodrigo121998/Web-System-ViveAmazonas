<?php

require_once ('../dompdf/autoload.inc.php');

use Dompdf\Dompdf;
$enlace = mysqli_connect("localhost","root","","base_va");
$codigo_negociacion = $_GET['codigo_negociacion'];
$sentencia="SELECT n.fecha_negociacion, e.Nombre_Empresa, CONCAT(u.nombres,' ',u.apellidos) as nombre_representante, c.nombre_concurso,
n.fecha_inicio_convenio,n.fecha_fin_convenio,c.monto_financiado, p.Nombre_Proyecto FROM negociaciones as n, empresas_proponentes as e, usuarios as u,
concurso as c, proyectos as p WHERE n.codigo_proyecto=p.Codigo_Proyecto and p.Codigo_Proponente=e.Codigo_Empresa and p.Codigo_Concurso=c.codigo_concurso
and e.ID_Representante=u.id;";

$resultado=mysqli_query($enlace,$sentencia);
$fila=mysqli_fetch_row($resultado);


	$sentencia2="Select nombre_plantilla, texto from plantilla where tipo_Plantilla='Convenio de Financiamiento';";
	$resultado2=mysqli_query($enlace,$sentencia2);
	$fila2=mysqli_fetch_row($resultado2);
	$html = html_entity_decode($fila2[1], ENT_QUOTES);


$hoy = date("F j, Y");
$firma = '<img src="../upload/firma.png" style="width:90px;">';


$html = str_replace('(FECHANEGOCIACION)', $fila[0], $html);
$html = str_replace('(NOMEMPRESA)', $fila[1], $html);
$html = str_replace('(NOMPERSONA)', $fila[2], $html);
$html = str_replace('(NOMCON)', $fila[3], $html);
$html = str_replace('(FECHAINICIO)', $fila[4], $html);
$html = str_replace('(FECHAFIN)', $fila[5], $html);
$html = str_replace('(MONTOFINANCIADO)', $fila[6], $html);
$html = str_replace('(NOMPROY)', $fila[7], $html);
$html = str_replace('(FECHAACTUAL)', $hoy, $html);


$dompdf = new Dompdf();
$dompdf->loadHtml($html);
$dompdf->setPaper('A4', ''); // (Opcional) Configurar papel y orientación(horizontal=landscape)
$dompdf->render(); // Generar el PDF desde contenido HTML
$pdf = $dompdf->output(); // Obtener el PDF generado
$dompdf->stream("rptDocumentoEntregados.pdf", array("Attachment" => True));
?>