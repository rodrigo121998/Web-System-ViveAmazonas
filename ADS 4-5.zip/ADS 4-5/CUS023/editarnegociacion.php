<html>

	<head>

	</head>

	<body>
		<?php
				  session_start(); //inicio de sesión
					if (!isset($_SESSION["usuario"])){
						session_destroy();
						echo "<br><br> <font color='red'>Intento de acceso sin autorización!!!</font>";
						header("Location:../intranet.html");
						exit;
					}
					$codigo_negociacion=$_GET["codigo_negociacion"];
					$codigo_proyecto = $_POST['codigo_proyecto'];
					$fecha_envio = $_POST['fecha_envio'];
					$fecha_negociacion = $_POST['fecha_negociacion'];
					$fecha_inicio = $_POST['fecha_inicio'];
					$fecha_fin = $_POST['fecha_fin'];
					
					
					$enlace = mysqli_connect("localhost","root","","base_va");
					$sentencia="update negociaciones set codigo_proyecto = '$codigo_proyecto',
					fecha_negociacion= '$fecha_negociacion',
					fecha_inicio_convenio = '$fecha_inicio',
					fecha_fin_convenio = '$fecha_fin',
					fecha_envio_comunicacion='$fecha_envio'		
					
					where codigo_negociacion='$codigo_negociacion';";
					$resultado = mysqli_query($enlace,$sentencia);
						
					header("Location:CUS023negociaciones.php");
		?>
	</body>
</html>