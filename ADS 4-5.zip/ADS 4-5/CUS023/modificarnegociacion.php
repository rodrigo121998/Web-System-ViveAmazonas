<html lang="en">
	<?php
			session_start(); //inicio de sesión
			if (!isset($_SESSION["usuario"])){
				session_destroy();
				echo "<br><br> <font color='red'>Intento de acceso sin autorización!!!</font>";
				header("Location:../intranet.html");
				exit;
			}
			 else {
			include("../inc/menuarriba.php");	 
			 /*$id_us= $_SESSION['id_us'];
			 $correo_us= $_SESSION['correo_us'];*/
			include("../inc/menu.php");

	 ?>
			<h1 class="h3 mb-2 text-gray-800">Modificación de datos de la negociación</h1>
			<p class="mb-4">En esta página se puede modificar las negociaciones</p>
			<div class="card shadow mb-4">
				<div class="card-header py-3">
				  <h6 class="m-0 font-weight-bold text-primary">Modificación de negociaciones</h6>
				</div>
				<div class="card-body">
					<div class="table-responsive">
			<form action='CUS023negociaciones.php'>
			<input type='submit' value="Regresar a relación de negociaciones" class='d-none d-sm-inline-block btn btn-sm btn-primary shadow-sm' >
			</form><br>
			
			<?php

            $codigo_negociacion=$_GET["codigo_negociacion"];
			
			$sentencia="SELECT * FROM negociaciones where codigo_negociacion='$codigo_negociacion';";
            $resultado=mysqli_query($enlace,$sentencia);
            $fila=mysqli_fetch_row($resultado);
			
			$sentencia2="Select Codigo_Proyecto,Nombre_Proyecto from proyectos where (Estado_Proyecto='Ganador') and (Codigo_Proyecto='$fila[1]');";
			$resultado2= mysqli_query($enlace,$sentencia2);
			$registro= mysqli_fetch_row($resultado2);
			
			$sentencia3="Select Codigo_Proyecto,Nombre_Proyecto from proyectos where (Estado_Proyecto='Ganador')and (Codigo_Proyecto<>'$fila[1]');";
			$resultado3 = mysqli_query($enlace,$sentencia3);
			$contar= mysqli_num_rows($resultado3);			
 
			echo "<script src='http://code.jquery.com/jquery-latest.min.js' type='text/javascript'></script>";
			echo "<link rel='stylesheet' href='../css/estilos.css'/>";
			echo "<script src='script.js'></script>";
			echo "<script>";
			echo "function alerta(){";
			echo "return confirm('¿Está seguro que desea modificar esta negociacion?');}";
			echo "</script>";
            echo "<form class='user'onSubmit='return alerta();' action='editarnegociacion.php?codigo_negociacion=$codigo_negociacion' method='POST' enctype='multipart/form-data'>";
			
			echo "Código del proyecto: <select class='form-control' name='codigo_proyecto'>";	
			echo "<option value=$registro[0]>$registro[1]</option>";
				
				if ($contar==0){
				   echo  "<option value=''>No hay otros proyectos</option>";
				}
				else {
					for ($i=1; $i <= $contar; $i++){
					$registro2 = mysqli_fetch_row($resultado3);
					echo "<option value=$registro2[0]>$registro2[1]</option>";					
					}
				}			
			echo"</select><br><br>";
			echo "Fecha de negociación: <input class='form-control' name='fecha_negociacion' type='date' value='$fila[2]'> <br><br>";	
			echo "Convenio de donación:";
			
				if ($fila[3]<>NULL){
				echo"<a href='descargar_documento.php?codigo_negociacion=$codigo_negociacion'class='d-none d-sm-inline-block btn btn-sm btn-primary shadow-sm'>Descargar Documento</a> ";
				echo"<a href='subir_documento.php?codigo_negociacion=$codigo_negociacion' class='d-none d-sm-inline-block btn btn-sm btn-primary shadow-sm'>Cambiar Documento</a><br><br>";
					} 
				else{
					echo "No hay archivo subido<br><br>";
					echo"<a href='subir_documento.php?codigo_negociacion=$codigo_negociacion' class='d-none d-sm-inline-block btn btn-sm btn-primary shadow-sm'>Agregar Documento</a><br><br>";
					}
			echo "Fecha inicio del convenio: <input class='form-control' name='fecha_inicio' type='date' value='$fila[4]'> <br><br>";
			echo "Fecha fin del convenio: <input class='form-control' name='fecha_fin' type='date' value='$fila[5]'> <br><br>";
			
			
            echo "<input type='submit' value='Guardar' name='Guardar' class='d-none d-sm-inline-block btn btn-sm btn-primary shadow-sm'>";
            echo" </form>";
            ?>
		</div>
				</div>
			</div>
	  <?php
			include("../inc/menubajo.php");
			 }
	  ?>
</html>
