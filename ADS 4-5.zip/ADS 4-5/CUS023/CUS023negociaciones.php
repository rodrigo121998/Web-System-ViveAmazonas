<html lang="en">
	
		<?php
		
		session_start(); //inicio de sesión
		if (!isset($_SESSION["usuario"])){
			session_destroy();
			echo "<br><br> <font color='red'>Intento de acceso sin autorización!!!</font>";
			header("Location:../intranet.html");
			exit;
		}
			
		else {
			include("../inc/menuarriba.php");
		 /*$id_us= $_SESSION['id_us'];
		 $correo_us= $_SESSION['correo_us'];*/
			include("../inc/menu.php");
			
		?>
			<h1 class="h3 mb-2 text-gray-800">Relación de negociaciones</h1>
			<p class="mb-4">En esta página se puede administrar las negociaciones</p>
			<script src="http://code.jquery.com/jquery-latest.min.js" type="text/javascript"></script>
			<link rel="stylesheet" href="../css/estilos.css"/>
			<script src="script.js"></script>
			<script>
				function alerta()
				{
					return confirm("¿Esta seguro que desea eliminar esta negociación?");
				}
				
				function alerta2()
				{
					return confirm("¿Esta seguro que desea enviar este borrador de convenio de financiamiento?");
				}
				
				function alerta5()
				{
					return confirm("El borrado de convenio ya fue enviado. ¿Desea modificar la negociación?");
				}
				function alerta6()
				{
					return confirm("Este convenio de financiamiento ya se envió, ¿desea enviarla otra vez?");
				}
				
				</script>
				<div class="card shadow mb-4">
					<div class="card-header py-3">
					  <h6 class="m-0 font-weight-bold text-primary">Tabla de negociaciones</h6>
					</div>
					<div class="card-body">
						<div class="table-responsive">
				<form class="d-none d-sm-inline-block form-inline mr-auto ml-md-3 my-2 my-md-0 mw-100 navbar-search" action='CUS023negociaciones.php' method='POST' enctype='multipart/form-data'>
					<div class="input-group">
				
							<input type='text' class="form-control bg-light border-0 small" name='negociacion' placeholder='Buscar negociación...'>  
							<input type='submit' class="btn btn-primary" name='buscar' value="Buscar">
					</div>
				</form>
				<br><br>
				<?php
				if (!isset($_POST["buscar"])){
				
		
				$sentencia= "SELECT n.codigo_negociacion,p.Nombre_Proyecto,c.nombre_concurso,n.fecha_negociacion,n.estado 
				FROM negociaciones as n, proyectos as p, concurso as c WHERE n.codigo_proyecto=p.Codigo_Proyecto and   
				p.Codigo_Concurso=c.codigo_concurso  ORDER BY n.fecha_negociacion DESC;";
				$resultado= mysqli_query($enlace,$sentencia);
				$contar= mysqli_num_rows($resultado);								
												
				echo "<form action='crearnegociacion.php' method='POST'>";
							
				if ($contar==0){
				echo  "No hay negociaciones <br>";
					}
				else {

				echo "<form action='' method= 'POST'>";
				echo "<table class='table table-bordered' id='dataTable' width='100%' cellspacing='0'>";
				echo "<thead>";
				echo "	<tr>";
				echo "		<td>Código Negociación</td>";
				echo "		<td>Nombre Proyecto</td>";
				echo "		<td>Nombre Concurso</td>";
				echo "		<td>Fecha Negociación</td>";
				echo "		<td>Estado</td>";
				echo "		<td>Convenio de Donación</td>";
				echo "		<td>Opciones</td>";
				echo "	</tr>";
				
				$ruta = 'documento.php?codigo_negociacion=';
				
				for ($i=1; $i <= $contar; $i++){
				$registro = mysqli_fetch_row($resultado);

				
				if($registro[4]=='PE'){
				echo "	<tr>";
				echo "		<td>",$registro[0],"</td>";
				echo "		<td>",$registro[1],"</td>";
				echo "		<td>",$registro[2],"</td>";
				echo "		<td>",$registro[3],"</td>";
				echo "		<td>",$registro[4],"</td>";
				echo "		<td><a onclick='return alerta2();'href='enviarborrador.php?codigo_negociacion=$registro[0]'>Enviar correo</a><br> ";
				?>
				<a href="<?php echo $ruta.$registro[0]; ?>" >Generar borrador</a></td>
				<?php
				echo "		<td><a href='modificarnegociacion.php?codigo_negociacion=$registro[0]'>Modificar</a>  
				<a href='vernegociacion.php?codigo_negociacion=$registro[0]'>Consultar</a>  
				<a onclick='return alerta();' href='eliminarnegociacion.php?codigo_negociacion=$registro[0]'>Eliminar</a></td> ";
				echo "	</tr>";	
					}
				elseif ($registro[4]=='E') {
				echo "	<tr>";
				echo "		<td>",$registro[0],"</td>";
				echo "		<td>",$registro[1],"</td>";
				echo "		<td>",$registro[2],"</td>";
				echo "		<td>",$registro[3],"</td>";
				echo "		<td>",$registro[4],"</td>";
				echo "		<td><a onclick='return alerta6();'href='enviarborrador.php?codigo_negociacion=$registro[0]'>Enviar correo</a><br>"; 
				?>
				<a href="<?php echo $ruta.$registro[0]; ?>" >Generar borrador</a></td>
				<?php
				echo "		<td><a onclick='return alerta5();' href='modificarnegociacion.php?codigo_negociacion=$registro[0]'>Modificar</a>  
				<a href='vernegociacion.php?codigo_negociacion=$registro[0]'>Consultar</a>  
				<a onclick='return alerta();' href='eliminarnegociacion.php?codigo_negociacion=$registro[0]'>Eliminar</a></td> ";
				echo "	</tr>";		
				}
				}
				echo "</tbody>";
				echo "</table>";
				
				}
            ?>
			 <div class="d-sm-flex align-items-center justify-content-between mb-4">			
			<input type='submit' class="btn btn-primary" value="Crear negociación" >
			 <?php
			 echo"<a href='exportar.php?cod=''' class='d-none d-sm-inline-block btn btn-sm btn-primary shadow-sm'><i class='fas fa-download fa-sm text-white-50'></i> Exportar Reporte</a>";
			 ?>
			 </div>
			</form>
			<?php
			}
			else { 
			$negociacion = $_POST['negociacion'];
			echo"<form action='CUS023negociaciones.php' enctype='multipart/form-data'>";
	  
			
            if ($negociacion==''){
				echo"No ha seleccionado ninguna negociacion";
			}
			else {
			
			$sentencia2= "SELECT n.codigo_negociacion,p.Nombre_Proyecto,c.nombre_concurso,n.fecha_negociacion,n.estado 
				FROM negociaciones as n, proyectos as p, concurso as c WHERE (p.Nombre_Proyecto LIKE '%$negociacion%' OR c.nombre_concurso LIKE '%$negociacion%') and   
				n.codigo_proyecto=p.Codigo_Proyecto and  p.Codigo_Concurso=c.codigo_concurso ORDER BY n.fecha_negociacion DESC;";
			$resultado2 = mysqli_query($enlace,$sentencia2);
            $contar= mysqli_num_rows($resultado2);
			
			   if ($contar==0){
			   echo  "No hay negociaciones concidentes <br>";
				}
			   
			   else { 
			   echo "<form action='' method= 'POST'>";
				echo "<table class='table table-bordered' id='dataTable' width='100%' cellspacing='0'>";
				echo "<thead>";
				echo "	<tr>";
				echo "		<td>Código Negociación</td>";
				echo "		<td>Nombre Proyecto</td>";
				echo "		<td>Nombre Concurso</td>";
				echo "		<td>Fecha Negociación</td>";
				echo "		<td>Estado</td>";
				echo "		<td>Convenio de Donación</td>";
				echo "		<td>Opciones</td>";
				echo "	</tr>";
				echo "</thead>";
				echo "<tbody>";
				
				$cod=array();
				$ruta = 'documento.php?codigo_negociacion=';
				
				for ($i=1; $i <= $contar; $i++){
				
				$registro = mysqli_fetch_row($resultado2);
				
				if($registro[4]=='PE'){
				echo "	<tr>";
				echo "		<td>",$registro[0],"</td>";
				 array_push($cod,$registro[0]);
				echo "		<td>",$registro[1],"</td>";
				echo "		<td>",$registro[2],"</td>";
				echo "		<td>",$registro[3],"</td>";
				echo "		<td>",$registro[4],"</td>";
				echo "		<td><a onclick='return alerta2();'href='enviarborrador.php?codigo_negociacion=$registro[0]'>Enviar correo</a><br>";
				?>
				<a href="<?php echo $ruta.$registro[0]; ?>" >Generar borrador</a></td>
				<?php
				echo "		<td><a href='modificarnegociacion.php?codigo_negociacion=$registro[0]'>Modificar</a>  
				<a href='vernegociacion.php?codigo_negociacion=$registro[0]'>Consultar</a>  
				<a onclick='return alerta();' href='eliminarnegociacion.php?codigo_negociacion=$registro[0]'>Eliminar</a></td> ";
				echo "	</tr>";	
					}
				elseif ($registro[4]=='E') {
				echo "	<tr>";
				echo "		<td>",$registro[0],"</td>";
				array_push($cod,$registro[0]);
				echo "		<td>",$registro[1],"</td>";
				echo "		<td>",$registro[2],"</td>";
				echo "		<td>",$registro[3],"</td>";
				echo "		<td>",$registro[4],"</td>";
				echo "		<td><a onclick='return alerta6();'href='enviarborrador.php?codigo_negociacion=$registro[0]'>Enviar correo</a><br>";
				?>
				<a href="<?php echo $ruta.$registro[0]; ?>" >Generar borrador</a></td>
				<?php
				echo "		<td><a onclick='return alerta5();' href='modificarnegociacion.php?codigo_negociacion=$registro[0]'>Modificar</a>  
				<a href='vernegociacion.php?codigo_negociacion=$registro[0]'>Consultar</a>  
				<a onclick='return alerta();' href='eliminarnegociacion.php?codigo_negociacion=$registro[0]'>Eliminar</a></td> ";
				echo "	</tr>";		
				}
				}
				echo "</tbody>";
				echo "</table>";
				
				}
			}
			echo" <br><br>";
			$cod = serialize($cod);
			$cod = urlencode($cod);
			echo"<div class='d-sm-flex align-items-center justify-content-between mb-4'>";
			echo"<input type='submit' class='btn btn-primary' value='Regresar a relación de concursos'>";
			echo"<a href='exportar.php?cod=$cod' class='d-none d-sm-inline-block btn btn-sm btn-primary shadow-sm'><i class='fas fa-download fa-sm text-white-50'></i> Exportar Reporte</a>";
			echo"</div>";
			echo"</form>";
           
	
			 }
			 echo"</div>";
			echo"</div>";
		echo"</div>";
			 			include("../inc/menubajo.php");
			 }
	  ?>		
</html>
