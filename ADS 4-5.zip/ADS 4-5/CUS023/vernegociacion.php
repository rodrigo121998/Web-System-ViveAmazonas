<html lang="en">
	<?php
			session_start(); //inicio de sesión
			if (!isset($_SESSION["usuario"])){
				session_destroy();
				echo "<br><br> <font color='red'>Intento de acceso sin autorización!!!</font>";
				header("Location:../intranet.html");
				exit;
			}
			 else {
				include("../inc/menuarriba.php");
			 /*$id_us= $_SESSION['id_us'];
			 $correo_us= $_SESSION['correo_us'];*/
				include("../inc/menu.php");
	 ?>
			<h1 class="h3 mb-2 text-gray-800">Ver datos de negociacion</h1>
			<p class="mb-4">En esta página se puede consultar las negociaciones</p>
			<div class="card shadow mb-4">
				<div class="card-header py-3">
				  <h6 class="m-0 font-weight-bold text-primary">Consulta de negociaciones</h6>
				</div>
				<div class="card-body">
					<div class="table-responsive">
			<?php

            $codigo_negociacion=$_GET["codigo_negociacion"];
			
			$sentencia="SELECT * FROM negociaciones where codigo_negociacion='$codigo_negociacion';";
            $resultado=mysqli_query($enlace,$sentencia);
            $fila=mysqli_fetch_row($resultado);
			
			$sentencia2="Select Codigo_Proyecto,Nombre_Proyecto from proyectos where (estado<>'I') and (Codigo_Proyecto='$fila[1]');";
			$resultado2= mysqli_query($enlace,$sentencia2);
			$registro= mysqli_fetch_row($resultado2);
								
					
			echo"<form action='CUS023negociaciones.php' enctype='multipart/form-data'>";
            echo "Código del proyecto: <input class='form-control' name='codigo_proyecto' value='$registro[0]' readonly><br><br>";
			echo "Fecha envío de comunicado: <input class='form-control' name='fecha_envio' type='date' value='$fila[6]' readonly> <br><br>";
			echo "Fecha de negociación: <input class='form-control' name='fecha_negociacion' type='date' value='$fila[2]' readonly> <br><br>";	
			echo"Convenio de Donación: ";
				if ($fila[3]<>NULL){
				echo"<a href='descargar_documento.php?codigo_negociacion=$codigo_negociacion' class='d-none d-sm-inline-block btn btn-sm btn-primary shadow-sm'>Descargar Documento</a><br><br>"; 
					} 
				else {
					echo "No hay archivo subido<br><br>";
					}
			echo "Fecha inicio del convenio: <input class='form-control' name='fecha_inicio' type='date' value='$fila[4]' readonly> <br><br>";
			echo "Fecha fin del convenio: <input class='form-control' name='fecha_fin' type='date' value='$fila[5]' readonly> <br><br>";
									
            echo "<input type='submit' value='Terminado' name='Terminado' class='d-none d-sm-inline-block btn btn-sm btn-primary shadow-sm'>";

            echo" </form>";
             ?>
			
					</div>
				</div>
			</div>
	  <?php
			include("../inc/menubajo.php");
			 }
	  ?>
</html>
