<html>
<head> </head>
<body>
	<?php
			session_start(); //inicio de sesión
			if (!isset($_SESSION["usuario"])){
				session_destroy();
				echo "<br><br> <font color='red'>Intento de acceso sin autorización!!!</font>";
				header("Location:../intranet.html");
				exit;
			}
			$codigo_negociacion=$_GET["codigo_negociacion"];
			
			$enlace = mysqli_connect("localhost","root","","base_va");
            $sentencia="UPDATE negociaciones SET estado='I' where codigo_negociacion='$codigo_negociacion';";
            $resultado=mysqli_query($enlace,$sentencia);
			
			header("Location:CUS023negociaciones.php");
?>

</body>
</html>