<?php
ob_start();
require_once ('../dompdf/autoload.inc.php');

use Dompdf\Dompdf;
$enlace = mysqli_connect("localhost","root","","base_va");
$codigo_negociacion = $_GET['codigo_negociacion'];
$sentencia="SELECT n.fecha_negociacion, e.Nombre_Empresa, CONCAT(u.nombres,' ',u.apellidos) as nombre_representante, c.nombre_concurso,
n.fecha_inicio_convenio,n.fecha_fin_convenio,c.monto_financiado, p.Nombre_Proyecto, e.Correo_Empresa FROM negociaciones as n, empresas_proponentes as e, usuarios as u,
concurso as c, proyectos as p WHERE codigo_negociacion=$codigo_negociacion and n.codigo_proyecto=p.Codigo_Proyecto and p.Codigo_Proponente=e.Codigo_Empresa and p.Codigo_Concurso=c.codigo_concurso
and e.ID_Representante=u.id;";

$resultado=mysqli_query($enlace,$sentencia);
$fila=mysqli_fetch_row($resultado);


	$sentencia2="Select nombre_plantilla, texto from plantilla where tipo_Plantilla='Convenio de Financiamiento';";
	$resultado2=mysqli_query($enlace,$sentencia2);
	$fila2=mysqli_fetch_row($resultado2);
	$html = html_entity_decode($fila2[1], ENT_QUOTES);

$hoy = date("F j, Y");
$firma = '<img src="../upload/firma.png" style="width:90px;">';


$html = str_replace('(FECHANEGOCIACION)', $fila[0], $html);
$html = str_replace('(NOMEMPRESA)', $fila[1], $html);
$html = str_replace('(NOMPERSONA)', $fila[2], $html);
$html = str_replace('(NOMCON)', $fila[3], $html);
$html = str_replace('(FECHAINICIO)', $fila[4], $html);
$html = str_replace('(FECHAFIN)', $fila[5], $html);
$html = str_replace('(MONTOFINANCIADO)', $fila[6], $html);
$html = str_replace('(NOMPROY)', $fila[7], $html);
$html = str_replace('(FECHAACTUAL)', $hoy, $html);

$dompdf = new Dompdf();
$dompdf->loadHtml($html);
$dompdf->setPaper('A4', ''); // (Opcional) Configurar papel y orientación(horizontal=landscape)
$dompdf->render(); // Generar el PDF desde contenido HTML
$pdf = $dompdf->output(); // Obtener el PDF generado
//$dompdf->stream("rptDocumentoEntregados.pdf", array("Attachment" => false));
$pdf_name='rptDocumentoEntregados.pdf';
file_put_contents($pdf_name,$pdf);

$sentencia3="update negociaciones set fecha_envio_comunicacion=NOW()
where codigo_negociacion='$codigo_negociacion';";
$resultado3 = mysqli_query($enlace,$sentencia3);

require "../PHPMailer/class.phpmailer.php";
$mail = new PHPMailer();
$mail->isSMTP();
$mail->SMTPAuth = true;
$mail->SMTPSecure='tls';
$mail->Host = "smtp.gmail.com";
$mail->Port = '587';
$mail->SMTPDebug  = 2;
$mail->IsHTML(true);

$mail->Username = 'vive.amazonas.1@gmail.com';
$mail->Password = 'vive.amazonas123';		

$mail->ClearAddresses(); 	
$correo=$fila[8];
$mail->setFrom('vive.amazonas.1@gmail.com', 'Vive Amazonas');
$mail -> addAddress ( $correo,'Cliente' );
$mail->WordWrap=50;
$mail->addAttachment($pdf_name);
$subjects =  "Convenio de financiamiento '$fila[3]' ";
$mail -> Subject = $subjects;
$mail ->  Body = " <b>Estimado(a) $fila[2], invitamos a que se acerque a las instalaciones de VIVEAMAZONAS el día $fila[0] a las 10 de la mañanana para la firma de su convenio de financiamiento. Adjunto documento para su lectura.¡Te estaremos esperando! </b><br>" ;	                 
if($mail-> send()) {
echo"Enviado";
}

$sentencia4="UPDATE negociaciones SET estado='E' WHERE codigo_negociacion=$codigo_negociacion;";
$resultado4=mysqli_query($enlace,$sentencia4);


unlink($pdf_name);
//header_remove();
header("Location:CUS023negociaciones.php");
//header_remove();
ob_end_flush();

?>