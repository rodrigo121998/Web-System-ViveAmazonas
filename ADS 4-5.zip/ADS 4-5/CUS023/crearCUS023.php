<html>
<head> </head>
<body>
<?php
			session_start(); //inicio de sesión
			if (!isset($_SESSION["usuario"])){
				session_destroy();
				echo "<br><br> <font color='red'>Intento de acceso sin autorización!!!</font>";
				header("Location:../intranet.html");
				exit;
			}
						
			$codigo_proyecto = $_POST['codigo_proyecto'];
			$fecha_envio = $_POST['fecha_envio'];
			$fecha_negociacion = $_POST['fecha_negociacion'];
			
			$nombre_documento=$_FILES['documento']['name'];
			$tipo_documento=$_FILES['documento']['type'];
			$tamano_documento=$_FILES['documento']['size'];
			$carpeta_destino=$_SERVER['DOCUMENT_ROOT'].'/ADS 4/upload/';
			move_uploaded_file($_FILES['documento']['tmp_name'],$carpeta_destino.$nombre_documento);
			$documento_objetivo=fopen($carpeta_destino.$nombre_documento,'r');
			$contenido_documento=fread($documento_objetivo,$tamano_documento);
			$contenido_documento=addslashes($contenido_documento);
			fclose($documento_objetivo);
		
			$fecha_inicio = $_POST['fecha_inicio'];
			$fecha_fin = $_POST['fecha_fin'];
		
			
			$enlace = mysqli_connect("localhost","root","","base_va");
			$sentencia="INSERT INTO negociaciones(codigo_proyecto,fecha_negociacion,convenio_donacion,fecha_inicio_convenio,fecha_fin_convenio,
			estado,tipo_convenio) VALUES ('$codigo_proyecto','$fecha_negociacion','$contenido_documento','$fecha_inicio',
			'$fecha_fin','PE','$tipo_documento');";
			$resultado = mysqli_query($enlace,$sentencia);
            
			header("Location:CUS023negociaciones.php");

             ?>
</body>
</html>