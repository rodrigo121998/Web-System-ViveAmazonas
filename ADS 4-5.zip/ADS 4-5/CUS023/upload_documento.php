<?php

			session_start(); //inicio de sesión

					if (!isset($_SESSION["usuario"])){

						session_destroy();

						echo "<br><br> <font color='red'>Intento de acceso sin autorización!!!</font>";

						header("Location:../intranet.html");

						exit;

					}

			$codigo_negociacion=$_GET["codigo_negociacion"];
			$nombre_documento=$_FILES['documento']['name'];
			$tipo_documento=$_FILES['documento']['type'];
			$tamano_documento=$_FILES['documento']['size'];
			$carpeta_destino=$_SERVER['DOCUMENT_ROOT'].'/ADS 4/upload/';
			move_uploaded_file($_FILES['documento']['tmp_name'],$carpeta_destino.$nombre_documento);
			$documento_objetivo=fopen($carpeta_destino.$nombre_documento,'r');
			$contenido_documento=fread($documento_objetivo,$tamano_documento);
			$contenido_documento=addslashes($contenido_documento);
			fclose($documento_objetivo);

			$enlace = mysqli_connect("localhost","root","","base_va");
			$sentencia="update negociaciones set convenio_donacion='$contenido_documento',
			tipo_convenio='$tipo_documento' where codigo_negociacion='$codigo_negociacion';";
			$resultado = mysqli_query($enlace,$sentencia);

			header("Location:modificarnegociacion.php?codigo_negociacion=$codigo_negociacion");

?>