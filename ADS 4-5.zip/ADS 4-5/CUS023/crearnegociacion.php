<html lang="en">
	<?php
			session_start(); //inicio de sesión
			if (!isset($_SESSION["usuario"])){
				session_destroy();
				echo "<br><br> <font color='red'>Intento de acceso sin autorización!!!</font>";
				header("Location:../intranet.html");
				exit;
			}
			 else {
				 include("../inc/menuarriba.php");
			 /*$id_us= $_SESSION['id_us'];
			 $correo_us= $_SESSION['correo_us'];*/
				include("../inc/menu.php");
	 ?>
			<h1 class="h3 mb-2 text-gray-800">Creación de negociación</h1>
			<p class="mb-4">En esta página se puede crear las negociaciones.</p>
			<script src="http://code.jquery.com/jquery-latest.min.js" type="text/javascript"></script>
			<link rel="stylesheet" href="../css/estilos.css"/>
			<script src="script.js"></script>
			<script>
				function alerta()
				{
					return confirm("¿Esta seguro que desea crear esta negociación?");
				}
			</script>
			<div class="card shadow mb-4">
				<div class="card-header py-3">
				  <h6 class="m-0 font-weight-bold text-primary">Creación de negociaciones</h6>
				</div>
				<div class="card-body">
					<div class="table-responsive">
			<form action='CUS023negociaciones.php'>
			<input type='submit' value="Regresar a relación de negociaciones" class='d-none d-sm-inline-block btn btn-sm btn-primary shadow-sm'>
			</form><br>
            <form class="user" onSubmit='return alerta();' action='crearCUS023.php' method="POST"  enctype='multipart/form-data'>
            Código del proyecto: <select class="form-control" name="codigo_proyecto">
				<option value="">Elige una opción</option>
				<?php
				$sentencia="Select Codigo_Proyecto,Nombre_proyecto from proyectos where Estado_Proyecto='Ganador';";
				$resultado = mysqli_query($enlace,$sentencia);
				$contar= mysqli_num_rows($resultado);
				
				if ($contar==0){
				   echo  "<option value=''>No hay proyectos ganadores</option>";
					}
				else {
					for ($i=1; $i <= $contar; $i++){
					$registro = mysqli_fetch_row($resultado);
					echo "<option value=$registro[0]>$registro[0] $registro[1]</option>";	
						}
					}
				?>				
			</select><br><br>
			Fecha de negociación: <input class="form-control" name='fecha_negociacion' type='date'> <br><br>	
			Convenio de donación: <input class="form-control-file" name="documento" type="file" accept=".jpg,.png,.doc,.pdf"> <br><br>
			Fecha inicio del convenio: <input class="form-control" name='fecha_inicio' type='date'> <br><br>
			Fecha fin del convenio: <input class="form-control" name='fecha_fin' type='date'> <br><br>
			
				
             <input type='submit' value='Guardar' name='Guardar' class='d-none d-sm-inline-block btn btn-sm btn-primary shadow-sm'>

            </form>
		</div>
				</div>
			</div>
	  <?php
				include("../inc/menubajo.php");
			 }
	  ?>
</html>