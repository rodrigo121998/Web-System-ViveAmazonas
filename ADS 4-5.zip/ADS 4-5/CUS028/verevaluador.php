<html lang="en">
	<?php
	 session_start(); //inicio de sesión
						if (!isset($_SESSION["usuario"])){
							session_destroy();
							echo "<br><br> <font color='red'>Intento de acceso sin autorización!!!</font>";
							header("Location:../intranet.html");
							exit;
						}
			 else {
				 include("../inc/menuarriba.php");
			 /*$id_us= $_SESSION['id_us'];
			 $correo_us= $_SESSION['correo_us'];*/
			include("../inc/menu.php");
	 ?>
	<div>
		<h1 class="h3 mb-2 text-gray-800">Evaluadores de un concurso</h1>
			<p class="mb-4">En esta página se puede consultar los evaluadores de un concurso</p>
			<script src="http://code.jquery.com/jquery-latest.min.js" type="text/javascript"></script>
			<link rel="stylesheet" href="../css/estilos.css"/>
			<script src="script.js"></script>
			<script>
				function alerta()
				{
					return confirm("¿Esta seguro que desea eliminar este evaluador?");
				}
			</script>
			<div class="card shadow mb-4">
				<div class="card-header py-3">
				  <h6 class="m-0 font-weight-bold text-primary">Evaluadores de concurso</h6>
				</div>
				<div class="card-body">
					<div class="table-responsive">
			<form class='user' action='CUS028.php' method='POST'>
			<?php
			$cod=$_GET["cod"];
            $sentencia2="select a.id, b.cargo_evaluador, CONCAT(u.nombres,' ',u.apellidos) as evaluador from usuarios as u, evaluadoresxconcurso a 
			LEFT join evaluadores b on a.id_evaluador=b.codigo_evaluador where b.usuario=u.id and a.id_concurso='$cod';";
            $resultado2 = mysqli_query($enlace,$sentencia2);
            $contar= mysqli_num_rows($resultado2);
           echo "<form action='' method= 'POST'>";
           echo "<table class='table table-bordered' id='dataTable' width='100%' cellspacing='0'>";
           echo "<thead>";
           echo "	<tr>";
           echo "		<td>Codigo</td>";
           echo "		<td>Cargo Evaluador</td>";
		   echo "		<td>Evaluador</td>";
		   echo "		<td>Opciones</td>";
           echo "	</tr>";
		   echo "</thead>";
		   echo "<tbody>";

           for ($i=1; $i <= $contar; $i++){
             $registro = mysqli_fetch_row($resultado2);
             echo "	<tr>";
             echo "		<td>",$registro[0],"</td>";
             echo "		<td>",$registro[1],"</td>";
			 echo "		<td>",$registro[2],"</td>";
             echo "		<td><a href='modificarevaluador.php?cod=$registro[0]' class='d-none d-sm-inline-block btn btn-sm btn-primary shadow-sm'>Modificar evaluador</a>";
			 echo"		<a onclick='return alerta();' href='eliminarevaluador.php?cod=$registro[0]' class='d-none d-sm-inline-block btn btn-sm btn-primary shadow-sm'>Eliminar evaluador</a><td>";
             echo "	</tr>";

           }
           echo "</tbody>";
           echo "</table>";

           

             ?>
			 <input type='submit' value="Regresar a relación de concursos" class='d-none d-sm-inline-block btn btn-sm btn-primary shadow-sm'>
		</form>
					</div>
				</div>
			</div>
	  <?php
			include("../inc/menubajo.php");
			 }
	  ?>
</html>