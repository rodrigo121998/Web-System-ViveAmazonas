<html>
<head> </head>
<body>
<?php
	session_start(); //inicio de sesión
	if (!isset($_SESSION["usuario"])){
		session_destroy();
		echo "<br><br> <font color='red'>Intento de acceso sin autorización!!!</font>";
		header("Location:../intranet.html");
		exit;
	}
	$cod=$_GET["cod"];
	$idevaluador = $_POST["idevaluador"];
	$enlace=mysqli_connect("localhost","root","","base_va");
	$sentencia="INSERT INTO evaluadoresxconcurso(id_concurso,id_evaluador)
	VALUES ('$cod','$idevaluador');";
	$resultado = mysqli_query($enlace,$sentencia);
	header("Location:CUS028.php");

 ?>
</body>
</html>