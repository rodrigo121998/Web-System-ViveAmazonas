	<html lang="en">
	<?php
	 session_start(); //inicio de sesión
			if (!isset($_SESSION["usuario"])){
				session_destroy();
				echo "<br><br> <font color='red'>Intento de acceso sin autorización!!!</font>";
				header("Location:../intranet.html");
				exit;
			}
			 else {
				 include("../inc/menuarriba.php");
			 /*$id_us= $_SESSION['id_us'];
			 $correo_us= $_SESSION['correo_us'];*/
				include("../inc/menu.php");
	 ?>
			<h1 class="h3 mb-2 text-gray-800">Agregar evaluador</h1>
            <p class="mb-4">En esta página se puede agregar evaluadores a los concursos</p>
			<script src="http://code.jquery.com/jquery-latest.min.js" type="text/javascript"></script>
			<link rel="stylesheet" href="css/estilos.css"/>
			<script src="script.js"></script>
			<script>
				function alerta()
				{
					return confirm("¿Esta seguro que desea agregar este evaluador al concurso?");
				}
			</script>
			<div class="card shadow mb-4">
				<div class="card-header py-3">
				  <h6 class="m-0 font-weight-bold text-primary">Asignación de evaluador</h6>
				</div>
				<div class="card-body">
					<div class="table-responsive">
			<form action='CUS028.php'>
			<input type='submit' value='Regresar a relación de concursos' class='d-none d-sm-inline-block btn btn-sm btn-primary shadow-sm'>
			</form><br>
			<?php
			$cod=$_GET["cod"];
            $sentencia3="SELECT codigo_concurso,nombre_concurso FROM concurso where codigo_concurso='$cod';";
			$resultado3 = mysqli_query($enlace,$sentencia3);
			$registro3 = mysqli_fetch_row($resultado3);
            echo"<form class='user' onSubmit='return alerta();' action='AgregarCUS028.php?cod=$registro3[0]' method='POST'>";
            echo"Concurso: <input class='form-control' name='idcon' type='text' value='$registro3[1]' readonly><br><br>";
            echo"Evaluador: <select class='form-control' name='idevaluador'>";
			echo"<option value=''>Elige una opción</option>";
				$sentencia2="select e.codigo_evaluador,e.cargo_evaluador, CONCAT(u.nombres,' ',u.apellidos) as nombre from evaluadores as e, usuarios as u  
				where e.usuario=u.id and e.codigo_evaluador not in (select a.id_evaluador as codigo from evaluadoresxconcurso a 
				LEFT join evaluadores b on a.id_evaluador=b.codigo_evaluador where a.id_concurso='$cod');";
				$resultado2 = mysqli_query($enlace,$sentencia2);
				$contar= mysqli_num_rows($resultado2);
				for ($i=1; $i <= $contar; $i++){
				$registro = mysqli_fetch_row($resultado2);
				echo "<option value=$registro[0]>$registro[1]-$registro[2]</option>";	
				}
				?>
			</select><br><br>
            <input type='submit' value='Guardar' name='Guardar' class='d-none d-sm-inline-block btn btn-sm btn-primary shadow-sm'>

            </form>
					</div>
				</div>
			</div>
	  <?php
			include("../inc/menubajo.php");
			 }
	  ?>
</html>