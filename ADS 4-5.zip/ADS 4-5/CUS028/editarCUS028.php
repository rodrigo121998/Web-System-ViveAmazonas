<html>
<head> </head>
<body>
<?php
	session_start(); //inicio de sesión
	if (!isset($_SESSION["usuario"])){
		session_destroy();
		echo "<br><br> <font color='red'>Intento de acceso sin autorización!!!</font>";
		header("Location:../intranet.html");
		exit;
	}
	$cod=$_GET["cod"];
	$idevaluador = $_POST["idevaluador"];
	$sentencia3="select id_concurso from evaluadoresxconcurso where id='$cod';";
	$enlace=mysqli_connect("localhost","root","","base_va");
	$resultado3=mysqli_query($enlace,$sentencia3);
	$registrocero = mysqli_fetch_row($resultado3);
	$sentencia="update evaluadoresxconcurso set id_evaluador='$idevaluador' where id='$cod';";
	$resultado = mysqli_query($enlace,$sentencia);
	header("Location:verevaluador.php?cod=$registrocero[0]");

 ?>
</body>
</html>