<html>
 <?php
 
   
	 session_start(); //inicio de sesión
						if (!isset($_SESSION["usuario"])){
							session_destroy();
							echo "<br><br> <font color='red'>Intento de acceso sin autorización!!!</font>";
							header("Location:../intranet.html");
							exit;
						}
			 else {
				 include("../inc/menuarriba.php");
		    $enlace = mysqli_connect("localhost","root","","base_va");
			include("../inc/menu.php");
?>
			<h1 class="h3 mb-2 text-gray-800">Aprobación de usuarios</h1>
			<p class="mb-4">En esta página se puede aprobar usuarios.</p>
			<script src="http://code.jquery.com/jquery-latest.min.js" type="text/javascript"></script>
			<link rel="stylesheet" href="../css/estilos.css"/>
			<script src="script.js"></script>
			<script>
				function alerta()
				{
					return confirm("¿Esta seguro que desea aprobar a los usuarios seleccionados?");
				}
			</script>
			
			<div class="card shadow mb-4">
				<div class="card-header py-3">
				  <h6 class="m-0 font-weight-bold text-primary">Tabla de Usuarios por aprobar</h6>
				</div>
				<div class="card-body">
					<div class="table-responsive">						
<?php
			 $sentencia="SELECT usuario,nombres,apellidos,correo FROM usuarios where estado='PA';";
			 $consulta=mysqli_query($enlace,$sentencia);	
			 $contar=  mysqli_num_rows($consulta);
			if ($contar==0){
			echo  "No hay cuentas por aprobar<br>";
			}
			else {
			echo"<form  action='CUS025aprobar.php' method='POST' enctype='multipart/form-data'>";
			  
				echo"	<input type='submit' class='btn btn-primary' name='aprobar' value='Aprobar todo'>";
			 
			echo"</form>";
			echo"<br>";
			
				
			echo "<form class='user' onSubmit='return alerta();' action='CUS025_2.php' method= 'POST'>";
			echo "<table class='table table-bordered' id='dataTable' width='100%' cellspacing='0'>";
		   echo "<thead>";
           echo "	<tr>";
			echo "		<td>Usuario</td>";
			echo "		<td>Nombre</td>";
			echo "		<td>Apellidos</td>";
			echo "		<td>Correos</td>";
			echo "		<td>Aprobar</td>";
			echo "		<td>Desaprobar</td>";
           echo "	</tr>";
		   echo "</thead>";
		   echo "<tbody>";
			$arreglo[]="";
			for ($i=1; $i <= $contar; $i++){
				$registro = mysqli_fetch_row($consulta);
				$correo[$i]=  $registro[3];
				echo "	<tr>";
				echo "		<td>",$registro[0],"</td>";
				echo "		<td>",$registro[1],"</td>";
				echo "		<td>",$registro[2],"</td>";
				echo "		<td>",$registro[3],"</td>";
				echo "		<td><label><input type='radio'  name= arreglo[$i] value='A' > </label></td>";
				echo "		<td><label><input type='radio'  name= arreglo[$i] value='D' > </label></td>";
				echo "	</tr>";
			}
		   echo "</tbody>";
           echo "</table>";
		   if (!isset($_POST["aprobar"])){
			echo  "<input type= 'reset' value='Restaurar' class='d-none d-sm-inline-block btn btn-sm btn-primary shadow-sm' >";
		   }
		   else{
			echo"<a  href= 'CUS025aprobar.php' class='d-none d-sm-inline-block btn btn-sm btn-primary shadow-sm' >Refrescar</a>";
		   }
			echo  "<input type= 'submit' name= 'Enviar' value='Enviar' class='d-none d-sm-inline-block btn btn-sm btn-primary shadow-sm' >";
			echo "</form>";
			}
			if (isset($_POST["aprobar"])){
			$sentencia="SELECT usuario,nombres,apellidos,correo FROM usuarios where estado='PA';";
			$consulta=mysqli_query($enlace,$sentencia);	
			$contar=  mysqli_num_rows($consulta);
			require_once "../PHPMailer/PHPMailerAutoload.php";
			$mail = new PHPMailer();
			$mail->isSMTP();
			$mail->SMTPAuth = true;
			$mail->SMTPSecure='tls';
			$mail->Host = "smtp.gmail.com";
			$mail->Port = '587';
			$mail->SMTPDebug  = 2;
			$mail->IsHTML(true);

			$mail->Username = 'vive.amazonas.1@gmail.com';
			$mail->Password = 'vive.amazonas123';
					
			$enlace = mysqli_connect("localhost","root","","base_va");		
			$sentencia="SELECT usuario,correo FROM usuarios where estado='PA';";
			$consulta=mysqli_query($enlace,$sentencia);	
			 
						
				for ( $i=1; $i <= $contar; $i++) { 
						$mail->ClearAddresses(); 	
						$registro = mysqli_fetch_row($consulta);
						$correo=$registro[1];
						$sentencia3="UPDATE usuarios SET estado= 'A' WHERE usuario=$registro[0];";
						$consulta3=mysqli_query($enlace,$sentencia3);
						
						if ($arreglo = 'A' ) {
							$mail->setFrom('vive.amazonas.1@gmail.com', 'Vive Amazonas');
							$mail -> addAddress ( $correo,'Cliente' );
							$subjects =  'Cuenta verificada';
							$mail -> Subject = $subjects;
							$mail ->  Body = ' <b>Su cuenta ha sido verificada.</b><br> Ya puede ingresar al intranet ' ;	                 
							if($mail-> send()) {
								echo"Enviado";					
						}
						else {
								echo" Mal";
								echo $correo;
						}
				 }	 
			}

			}
			
				echo"</div>";
			echo"</div>";
		echo"</div>";
			include("../inc/menubajo.php");
			 }
?>		
</html>