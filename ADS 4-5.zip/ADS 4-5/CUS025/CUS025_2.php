	
	

<?php

require_once "../PHPMailer/PHPMailerAutoload.php";
$mail = new PHPMailer();
$mail->isSMTP();
$mail->SMTPAuth = true;
$mail->SMTPSecure='tls';
$mail->Host = "smtp.gmail.com";
$mail->Port = '587';
$mail->SMTPDebug  = 2;
$mail->IsHTML(true);

$mail->Username = 'vive.amazonas.1@gmail.com';
$mail->Password = 'vive.amazonas123';
$enlace = mysqli_connect("localhost","root","","base_va");		
$sentencia="SELECT usuario,correo FROM usuarios where estado='PA';";
$consulta=mysqli_query($enlace,$sentencia);	
	
if ( !empty($_POST["arreglo"]) && is_array($_POST["arreglo"]) ) { 
    foreach ( $_POST["arreglo"] as $arreglo ) { 
			$mail->ClearAddresses(); 	
			$registro = mysqli_fetch_row($consulta);
			$correo=$registro[1];
			$sentencia3="UPDATE usuarios SET estado= '$arreglo' WHERE usuario=$registro[0];";
			$consulta3=mysqli_query($enlace,$sentencia3);
			
			if ($arreglo = 'A' ) {
                $mail->setFrom('vive.amazonas.1@gmail.com', 'Vive Amazonas');
                $mail -> addAddress ( $correo,'Cliente' );
                $subjects =  'Cuenta verificada';
				$mail -> Subject = $subjects;
				$mail ->  Body = ' <b>Su cuenta ha sido verificada.</b><br> Ya puede ingresar al intranet ' ;	                 
				if($mail-> send()) {
					echo"Enviado";					
			}
			else {
					echo" Mal";
					echo $correo;
			}
     }	 
}		
}
header_remove();
header("Location:CUS025aprobar.php");
 

?>