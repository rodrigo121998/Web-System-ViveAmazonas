<html>
		<?php
		
		 session_start(); //inicio de sesión
						if (!isset($_SESSION["usuario"])){
							session_destroy();
							echo "<br><br> <font color='red'>Intento de acceso sin autorización!!!</font>";
							header("Location:../intranet.html");
							exit;
						}
			 else {
				 include("../inc/menuarriba.php");
			 /*$id_us= $_SESSION['id_us'];
			 $correo_us= $_SESSION['correo_us'];*/
					include("../inc/menu.php");
		 ?>
			<h1 class="h3 mb-2 text-gray-800">Relación de Proyectos Evaluados</h1>
			<p class="mb-4">En esta página se puede comunicar los resultados de los proyectos.</p>
			<script src="http://code.jquery.com/jquery-latest.min.js" type="text/javascript"></script>
			<link rel="stylesheet" href="../css/estilos.css"/>
			<script src="script.js"></script>
			<script>
				function alerta()
				{
					return confirm("¿Esta seguro que desea comunicar el resultado de este proyecto?");
				}
			</script>
			<div class="card shadow mb-4">
				<div class="card-header py-3">
				  <h6 class="m-0 font-weight-bold text-primary">Tabla de Proyectos Evaluados</h6>
				</div>
				<div class="card-body">
					<div class="table-responsive">
			<form class="d-none d-sm-inline-block form-inline mr-auto ml-md-3 my-2 my-md-0 mw-100 navbar-search" action='CUS027comunicar.php' method='POST' enctype='multipart/form-data'>
				<div class="input-group">	
					<input type='text' class="form-control bg-light border-0 small" name='proyecto' placeholder='Buscar proyecto...'>  
					<input type='submit' class="btn btn-primary" name='buscar' value="Buscar proyecto" ><br><br>
				</div>
			</form>
			<br><br>
			<?php
			if (!isset($_POST["buscar"])){
            $sentencia2= "SELECT DISTINCT a.Codigo_Proyecto,a.Nombre_Proyecto,a.Estado_Proyecto,b.Correo_Empresa FROM proyectos a, empresas_proponentes b
			where a.Estado='A' and (a.Estado_Proyecto IN ('Ganador','Rechazado por un evaluador')) and b.Codigo_Empresa=a.Codigo_Proponente and b.Estado='A';";
			$resultado2 = mysqli_query($enlace,$sentencia2);
            $contar= mysqli_num_rows($resultado2);
           echo"<form action='' method='POST'>";
		   if ($contar==0){
           echo  "No hay proyectos <br>";
           }
           else {

           echo "<form action='' method= 'POST'>";
           echo "<table class='table table-bordered' id='dataTable' width='100%' cellspacing='0'>";
           echo "<thead>";
		   echo "	<tr>";
           echo "		<td>Codigo Proyecto</td>";
           echo "		<td>Nombre Proyecto</td>";
           echo "		<td>Estado Proyecto</td>";
		   echo "		<td>Correo Empresa</td>";
           echo "		<td>Opciones</td>";
           echo "	</tr>";
			echo "</thead>";
		   echo "<tbody>";
		   $ruta = 'documento.php?cod=';
           for ($i=1; $i <= $contar; $i++){
             $registro = mysqli_fetch_row($resultado2);


             echo "	<tr>";
             echo "		<td>",$registro[0],"</td>";
             echo "		<td>",$registro[1],"</td>";
             echo "		<td>",$registro[2],"</td>";
			 echo "		<td>",$registro[3],"</td>";
             echo "		<td><a onclick='return alerta();' href='comunicar.php?cod=$registro[0]' class='d-none d-sm-inline-block btn btn-sm btn-primary shadow-sm'>Enviar correo</a> ";
			 ?>
			 <a href="<?php echo $ruta.$registro[0]; ?>" class='d-none d-sm-inline-block btn btn-sm btn-primary shadow-sm'>Generar documento</a></td>
             <?php
			 echo "	</tr>";

           }
		   echo "</tbody>";
           echo "</table>";

           }

             ?>
		  </form>
	  <?php
			}
			 else {
			$proyecto = $_POST['proyecto'];
			echo"<form action='CUS027comunicar.php' enctype='multipart/form-data'>";
			if ($proyecto==''){
				echo"No ha seleccionado ningún proyecto";
			}
			else {
            $sentencia2= "SELECT DISTINCT a.Codigo_Proyecto,a.Nombre_Proyecto,a.Estado_Proyecto,b.Correo_Empresa FROM proyectos a, empresas_proponentes b where a.Estado='A' and
			(a.Estado_Proyecto IN ('Ganador','Rechazado por un evaluador')) and b.Codigo_Empresa=a.Codigo_Proponente and b.Estado='A' and a.Nombre_Proyecto like '%$proyecto%';";
			$resultado2 = mysqli_query($enlace,$sentencia2);
            $contar= mysqli_num_rows($resultado2);
           if ($contar==0){
           echo  "No hay proyectos con ese nombre<br>";
           }
           else {

           echo "<form action='' method= 'POST'>";
           echo "<table class='table table-bordered' id='dataTable' width='100%' cellspacing='0'>";
           echo "<thead>";
		   echo "	<tr>";
           echo "		<td>Codigo Proyecto</td>";
           echo "		<td>Nombre Proyecto</td>";
           echo "		<td>Estado Proyecto</td>";
		   echo "		<td>Correo Empresa</td>";
           echo "		<td>Opciones</td>";
           echo "	</tr>";
		   echo "</thead>";
		   echo "<tbody>";
			$ruta = 'documento.php?cod=';
           for ($i=1; $i <= $contar; $i++){
             $registro = mysqli_fetch_row($resultado2);


             echo "	<tr>";
             echo "		<td>",$registro[0],"</td>";
             echo "		<td>",$registro[1],"</td>";
             echo "		<td>",$registro[2],"</td>";
			 echo "		<td>",$registro[3],"</td>";
             echo "		<td><a onclick='return alerta();' href='comunicar.php?cod=$registro[0]' class='d-none d-sm-inline-block btn btn-sm btn-primary shadow-sm'>Enviar correo</a> ";
			 ?>
			 <a href="<?php echo $ruta.$registro[0]; ?>" class='d-none d-sm-inline-block btn btn-sm btn-primary shadow-sm'>Generar documento</a></td>
             <?php
             echo "	</tr>";

           }
		   echo "</tbody>";
           echo "</table>";

           }
			}

			echo" <br><br>";
			echo"<input type='submit' class='btn btn-primary' value='Regresar a relación de proyectos'>";
			echo"</form>";
			
			 }
				echo"</div>";
			echo"</div>";
		echo"</div>";
			 include("../inc/menubajo.php");
			 }
	  ?>
</html>