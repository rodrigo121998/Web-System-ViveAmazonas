<?php
ob_start();
require_once ('../dompdf/autoload.inc.php');

use Dompdf\Dompdf;
$enlace = mysqli_connect("localhost","root","","base_va");
$cod = $_GET['cod'];
$sentencia="SELECT a.Nombre_Proyecto,a.Estado_Proyecto,b.Nombre_Empresa,b.Correo_Empresa,concat(c.nombres,' ',c.apellidos) as nombre,d.nombre_concurso
 FROM proyectos a, empresas_proponentes b,usuarios c,concurso d
 where a.Codigo_Proyecto='$cod' and a.Codigo_Proponente=b.Codigo_Empresa and b.ID_Representante=c.id and a.Codigo_Concurso=d.codigo_concurso;";
$resultado=mysqli_query($enlace,$sentencia);
$fila=mysqli_fetch_row($resultado);

if ($fila[1]=='Ganador'){
				$sentencia2="Select nombre_plantilla, texto from plantilla where tipo_Plantilla='Documento de aprobación';";
				$resultado2=mysqli_query($enlace,$sentencia2);
				$fila2=mysqli_fetch_row($resultado2);
				$html = html_entity_decode($fila2[1], ENT_QUOTES);
			}
else{
	$sentencia2="Select nombre_plantilla, texto from plantilla where tipo_Plantilla='Documento de desaprobación';";
	$resultado2=mysqli_query($enlace,$sentencia2);
	$fila2=mysqli_fetch_row($resultado2);
	$html = html_entity_decode($fila2[1], ENT_QUOTES);
}

$hoy = date("F j, Y");
$firma = '<img src="../upload/firma.png" style="width:90px;">';


$html = str_replace('(NOMPROY)', $fila[0], $html);
$html = str_replace('(NOMEMPRESA)', $fila[2], $html);
$html = str_replace('(NOMPERSONA)', $fila[4], $html);
$html = str_replace('(NOMCON)', $fila[5], $html);
$html = str_replace('(FECHAACTUAL)', $hoy, $html);
$html = str_replace('(FIRMA)', $firma, $html);

$dompdf = new Dompdf();
$dompdf->loadHtml($html);
$dompdf->setPaper('A4', ''); // (Opcional) Configurar papel y orientación(horizontal=landscape)
$dompdf->render(); // Generar el PDF desde contenido HTML
$pdf = $dompdf->output(); // Obtener el PDF generado
//$dompdf->stream("rptDocumentoEntregados.pdf", array("Attachment" => false));
$pdf_name='rptDocumentoEntregados.pdf';
file_put_contents($pdf_name,$pdf);
$sentencia3="update proyectos set FechaEnvio_Comunicacion=NOW()
where codigo_proyecto='$cod';";
$resultado3 = mysqli_query($enlace,$sentencia3);

require "../PHPMailer/class.phpmailer.php";
$mail = new PHPMailer();
$mail->isSMTP();
$mail->SMTPAuth = true;
$mail->SMTPSecure='tls';
$mail->Host = "smtp.gmail.com";
$mail->Port = '587';
$mail->SMTPDebug  = 2;
$mail->IsHTML(true);

$mail->Username = 'vive.amazonas.1@gmail.com';
$mail->Password = 'vive.amazonas123';		

$mail->ClearAddresses(); 	
$correo=$fila[3];
$mail->setFrom('vive.amazonas.1@gmail.com', 'Vive Amazonas');
$mail -> addAddress ( $correo,'Cliente' );
$mail->WordWrap=50;
$mail->addAttachment($pdf_name);
$subjects =  "Resultado de concurso '$fila[5]' ";
$mail -> Subject = $subjects;
$mail ->  Body = " <b>Adjunto encontrará los resultados del concurso '$fila[5]'.</b><br>" ;	                 
if($mail-> send()) {
echo"Enviado";
}
unlink($pdf_name);
//header_remove();
header("Location:CUS027comunicar.php");
//header_remove();
ob_end_flush();

?>