<html>
<head>
	<title> Sistema de registro </title>
	<meta charset="utf-8" />
	<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
	<meta name="description" content="" />
	<meta name="author" content="" />
	<title></title>
	<!-- Favicon-->
	<link rel="icon" type="image/x-icon" href="assets/img/favicon.ico" />
	<!-- Font Awesome icons (free version)-->
	<script src="https://use.fontawesome.com/releases/v5.13.0/js/all.js" crossorigin="anonymous"></script>
	<!-- Google fonts-->
	<link href="https://fonts.googleapis.com/css?family=Merriweather+Sans:400,700" rel="stylesheet" />
	<link href="https://fonts.googleapis.com/css?family=Merriweather:400,300,300italic,400italic,700,700italic" rel="stylesheet" type="text/css" />
	<!-- Third party plugin CSS-->
	<link href="https://cdnjs.cloudflare.com/ajax/libs/magnific-popup.js/1.1.0/magnific-popup.min.css" rel="stylesheet" />
	<!-- Core theme CSS (includes Bootstrap)-->
	<link href="css/styles_4.css" rel="stylesheet" />
</head>
<body>
        <header class="masthead">
            <div class="container h-100">
                <div class="row h-100 align-items-center justify-content-center text-center">
                    <div class="col-lg-10">
                        <h2 class="text-uppercase text-white font-weight-bold">
							<?php 
								header("Content-type: text/html; charset=utf8");
								   $usuario = $_POST["usuario"];
								   $nombres= $_POST["nombres"];
								   $apellidos = $_POST["apellidos"];
								   $fech_nac= $_POST["fec_nac"]; 
								   $sexo= $_POST["sexo"];
								   $correo= $_POST["correo"];
								 
								   $anio= intval(substr($fech_nac,0,4));
								   $mes= intval(substr($fech_nac,5,2));
								   $dia= intval(substr($fech_nac,8,2)); 
								   $contraseña= $anio*$mes + $dia;
								   $avatar= 'avatar.jpg';
								   $estado= 'PA';
								   $CONserver = "localhost";
								   $CONuser= "root";
								   $CONpass= "";
                                   $CONdb= 'base_va';
								   
                                   $conexion= new mysqli($CONserver,$CONuser,$CONpass,$CONdb); 
                                   if($conexion->connect_errno) {
									   
									 die("La conexión ha fallado");  
								   } 
                                  
								  $consulta=$conexion->query( "SELECT * FROM usuarios WHERE usuario = '$usuario'; ");
								  $contar= $consulta->num_rows;
								  
								  if ($contar==1) {
									  echo " Ya hay un usario con ese DNI";
									  echo '<a class="btn btn-primary btn-xl js-scroll-trigger" href="registro_2.html"> Regresar </a>';
								  }
								  else {
									  
								  
								  $insertar= $conexion->query("INSERT INTO usuarios(usuario,contraseña,nombres,apellidos,fech_nac,avatar,sexo,correo,estado) VALUES ('$usuario','$contraseña','$nombres','$apellidos','$fech_nac','$avatar','$sexo','$correo','$estado') ;");
								   
									  if ($insertar) {
											
										echo "Hola,"; 
										echo $nombres ;
										echo " " ;
										echo $apellidos;
										echo "!<br>";
										echo " Te has registrado correctamente.  <br> Vive amazonas se contactará contigo al aprobar tu solicitud.<br>";
										echo "Su usuario es : <br>";
										echo $usuario;
										echo "<br>";
										echo 'Su clave es :' . PHP_EOL;
										echo "<br>";
										echo $contraseña . "\n";
										
									}
                                   }
								  
							?>
							<br><br>
						</h2>					
					<div class="align-items-center justify-content-center text-center">
						<a class="btn btn-primary btn-xl js-scroll-trigger" href="principal_viva.php"> Regresar </a>
					</div>                       						
					</div>
				</div>
			</div>
        </header>
	
</body>
</html>