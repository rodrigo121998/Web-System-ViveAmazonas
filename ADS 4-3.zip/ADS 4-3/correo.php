<html>
<?php
   $CONserver = "localhost";
   $CONuser= "root";
   $CONpass= "";
   $CONdb= 'base_va';
   
   $conexion= new mysqli($CONserver,$CONuser,$CONpass,$CONdb); 
   if($conexion->connect_errno) {
	   
	 die("La conexión ha fallado");  
   } 
?>

<head>
<meta content="width=device-width, initial-scale=1.0" name="viewport">
		<meta name="referrer" content="origin-when-crossorigin" id="meta_referrer">
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge" />
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
        <meta name="description" content="" />
        <meta name="author" content="" />
        <title> Intranet Vive-Amazonas </title>
		<link href="css/styles_14.css" rel="stylesheet" />
        <link href="https://cdn.datatables.net/1.10.20/css/dataTables.bootstrap4.min.css" rel="stylesheet" crossorigin="anonymous" />
        <script src="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.11.2/js/all.min.js" crossorigin="anonymous"></script>
</head>

<body>
<?php
								if(isset($_POST['Enviar'])){									
									for ($i=1; $i <= $contar; $i++){
										if(!empty($_POST[$i])) {
											
											$subjects =  'Cuenta verificada';
											$mail ->  setFrom ('vive.amazonas.1@gmail.com', 'Vive Amazonas' );
											$mail -> addAddress ( $correo[$i],'Cliente' );
											$mail -> addAttachment ('admin123.jpg','Te esperamos!' );
											$mail -> Subject = $subjects;
											$mail ->  Body = ' <b>Su cuenta ha sido verificada.</b><br> Ya puede ingresar al intranet ' ;
											$insertar= $conexion->query("UPDATE usuarios SET estado= '$_POST[$i]' WHERE usuario=$registro[0];");		
												if ( $mail -> send() ) {										
													echo 'Enviado y actualizado la base con éxito";';
													header ("Location: perfil.php");
												}
												else {
													echo 'Error, no se envio corrreo ni se actualizó la base';
												}
											}
										else  {
										echo "<p><b>Por favor seleccione al menos una opción.</b></p>";
										}
									}
																		
								}	
							   
								elseif(isset($_POST['Aprobar_todo'])){
								for ($i=1; $i <= $contar; $i++){
										if(!empty($_POST[$i])) {										
											$subjects =  'Cuenta verificada';
											$mail ->  setFrom ('vive.amazonas.1@gmail.com', 'Vive Amazonas' );
											$mail -> addAddress (intval($correo[$i]),'Cliente');
											$mail -> addAttachment ('admin123.jpg','Te esperamos!' );
											$mail -> Subject = $subjects;
											$mail ->  Body = ' <b>Su cuenta ha sido verificada.</b><br> Ya puede ingresar al intranet ' ;
											$insertar= $conexion->query("UPDATE usuarios SET estado= 'A' WHERE usuario=$registro[0];");
												if ( $mail -> send() ) {												
													echo 'Enviado';
													
													header ("Location: perfil.php");
												}
												else {
													echo 'Error, no se envio corrreo ni se actualizó en la base';
													header ("Location: perfil.php");
											}
											}										
									} 		
								}	
								
								else {
									echo " no envio";
								}	
?>								
</body>


</html>