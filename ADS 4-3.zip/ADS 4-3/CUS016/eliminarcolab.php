<html>
	<head>
	</head>

    <body background-image: url('fondo.jpg') >

	<?php
	session_start(); //inicio de sesión
			if (!isset($_SESSION["usuario"])){
				session_destroy();
				echo "<br><br> <font color='red'>Intento de acceso sin autorización!!!</font>";
				header("Location:../intranet.html");
				exit;
			}
			$cod=$_GET["cod"];
            
			include ("../inc/clases.php");
			$objColaborador=new Colaborador();
			$objColaborador->EliminarColaborador($cod);
			
			header("Location:CUS016colabor.php");
?>
</html>