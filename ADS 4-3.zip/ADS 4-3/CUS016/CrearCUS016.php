<html>
<head> </head>
<body>
<?php
	session_start(); //inicio de sesión
	if (!isset($_SESSION["usuario"])){
		session_destroy();
		echo "<br><br> <font color='red'>Intento de acceso sin autorización!!!</font>";
		header("Location:../intranet.html");
		exit;
	}
	$cargo = $_POST["cargo"];
	$ingreso = $_POST["ingreso"];
	$area = $_POST["area"];
	$sub = $_POST["sub"];
	$descripcion = $_POST["descripcion"];
	$idus = $_POST["idus"];
	
	include("../inc/clases.php");
	$objColaborador=new Colaborador();
	$objColaborador->CrearCUS016($cargo,$ingreso,$area,$sub,$descripcion,$idus);
	header("Location:CUS016colabor.php");

 ?>
</body>
</html>