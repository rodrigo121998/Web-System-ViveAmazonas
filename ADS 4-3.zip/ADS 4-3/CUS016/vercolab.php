<html>
	<?php
	 session_start(); //inicio de sesión
			if (!isset($_SESSION["usuario"])){
				session_destroy();
				echo "<br><br> <font color='red'>Intento de acceso sin autorización!!!</font>";
				header("Location:../intranet.html");
				exit;
			}
			 else {
				 include("../inc/menuarriba.php");
			 /*$id_us= $_SESSION['id_us'];
			 $correo_us= $_SESSION['correo_us'];*/
				include("../inc/menu.php");
	 ?>
			<h1 class="h3 mb-2 text-gray-800">Ver datos de Colaborador</h1>
			<p class="mb-4">En esta página se puede consultar los Colaboradores.</p>
			<div class="card shadow mb-4">
				<div class="card-header py-3">
				  <h6 class="m-0 font-weight-bold text-primary">Consulta de Colaboradores</h6>
				</div>
				<div class="card-body">
					<div class="table-responsive">
			<?php

            $cod=$_GET["cod"];
            include ("../inc/clases.php");
			$objColaborador=new Colaborador();
			list($fila,$registro2)=$objColaborador->VerColaborador($cod);

            echo"<form class='user' action='CUS016colabor.php' method='POST'>";
            echo" Cargo: <input class='form-control' name='cargo' type='text' value='$fila[1]' readonly> <br><br>";
            echo" Fecha de ingreso: <input class='form-control' name='ingreso' type='date' value='$fila[2]' readonly> <br><br>";
            echo"Área: <input class='form-control' name='area' type='text' value='$fila[3]' readonly> <br><br>";
			echo"Subárea: <input class='form-control' name='sub' type='text' value='$fila[4]' readonly> <br><br>";
			echo"Descripción del puesto:<br>";
			echo"<textarea class='form-control' name='descripcion' rows='10' cols='40' value='$fila[5]' readonly>$fila[5]</textarea>";
			echo"<br><br>";	
            echo" ID de usuario: <input class='form-control' name='idus' type='text' value='$registro2[1]' readonly> <br><br>";
            echo "<input class='d-none d-sm-inline-block btn btn-sm btn-primary shadow-sm' type='submit' value='Terminado' name='Terminado'>";
            echo" </form>";
            ?>
					</div>
				</div>
			</div>
	  <?php
			include("../inc/menubajo.php");
			 }
	  ?>
</html>