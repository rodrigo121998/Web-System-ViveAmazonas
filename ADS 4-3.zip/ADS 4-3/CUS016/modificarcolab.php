<html lang="en">
	<?php
	 session_start(); //inicio de sesión
			if (!isset($_SESSION["usuario"])){
				session_destroy();
				echo "<br><br> <font color='red'>Intento de acceso sin autorización!!!</font>";
				header("Location:../intranet.html");
				exit;
			}
			 else {
				 include("../inc/menuarriba.php");
			 /*$id_us= $_SESSION['id_us'];
			 $correo_us= $_SESSION['correo_us'];*/
				include("../inc/menu.php");
	 ?>
			<h1 class="h3 mb-2 text-gray-800">Modificación de datos de Colaborador</h1>
			<p class="mb-4">En esta página se puede modificar los Colaboradores.</p>
			<div class="card shadow mb-4">
				<div class="card-header py-3">
				  <h6 class="m-0 font-weight-bold text-primary">Modificación de Concursos</h6>
				</div>
				<div class="card-body">
					<div class="table-responsive">
			<form action='CUS016colabor.php'>
			<input type='submit' value="Regresar a relación de Colaboradores"  class='d-none d-sm-inline-block btn btn-sm btn-primary shadow-sm'>
			</form><br>
			<?php

            $cod=$_GET["cod"];
            include ("../inc/clases.php");
			$objColaborador= new Colaborador();
			list($fila,$registro2,$resultado3,$contar3)=$objColaborador->ModificarColaborador($cod);
			
			
			echo "<script src='http://code.jquery.com/jquery-latest.min.js' type='text/javascript'></script>";
			echo "<link rel='stylesheet' href='css/estilos.css'/>";
			echo "<script src='script.js'></script>";
			echo "<script>";
			echo "function alerta(){";
			echo	"return confirm('¿Está seguro que desea modificar este Colaborador?');}";
			echo "</script>";
            echo"<form class='user' onSubmit='return alerta();' action='editarcolab.php?cod=$cod' method='POST'>";
            echo" Cargo: <input name='cargo' class='form-control' type='text' value='$fila[1]' required> <br><br>";
            echo" Fecha de ingreso: <input name='ingreso' class='form-control' type='date' value='$fila[2]' required> <br><br>";
            echo"Área: <input class='form-control' name='area' type='text' value='$fila[3]' required> <br><br>";
			echo"Subárea: <input class='form-control' name='sub' type='text' value='$fila[4]' required> <br><br>";
			echo"Descripción del puesto:<br>";
			echo"<textarea class='form-control' name='descripcion' rows='10' cols='40' value='$fila[5]'>$fila[5]</textarea>";
			echo"<br><br>";
            echo"ID de usuario: <select class='form-control' name='idus'>";	
			echo "<option value='$registro2[0]'>$registro2[1]</option>";
			
			if ($contar3==0){
			   echo  "<option value=''>No hay colaboradores</option>";
			}
			else {
				for ($i=1; $i <= $contar3; $i++){
				$registro3 = mysqli_fetch_row($resultado3);
				echo "<option value=$registro3[0]>$registro3[1]</option>";
				
			}
			}
			echo"</select><br><br>";

            echo "<input type='submit' value='Guardar' name='Guardar' class='d-none d-sm-inline-block btn btn-sm btn-primary shadow-sm'>";

            echo" </form>";
            ?>
					</div>
				</div>
			</div>
	  <?php
	  include("../inc/menubajo.php");
			 }
	  ?>
</html>
