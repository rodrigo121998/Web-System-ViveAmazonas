<html>
	<?php
	 session_start(); //inicio de sesión
						if (!isset($_SESSION["usuario"])){
							session_destroy();
							echo "<br><br> <font color='red'>Intento de acceso sin autorización!!!</font>";
							header("Location:../intranet.html");
							exit;
						}
			 else {
				 include("../inc/menuarriba.php");
			 /*$id_us= $_SESSION['id_us'];
			 $correo_us= $_SESSION['correo_us'];*/
			include("../inc/menu.php");
	 ?>
		<h1 class="h3 mb-2 text-gray-800">Relación de Colaboradores</h1>
		<p class="mb-4">En esta página se puede administrar los Colaboradores.</p>	
			<script src="http://code.jquery.com/jquery-latest.min.js" type="text/javascript"></script>
			<link rel="stylesheet" href="../css/estilos.css"/>
			<script src="script.js"></script>
			<script>
				function alerta()
				{
					return confirm("¿Esta seguro que desea eliminar este Colaborador?");
				}
			</script>
			<div class="card shadow mb-4">
				<div class="card-header py-3">
				  <h6 class="m-0 font-weight-bold text-primary">Tabla de Concursos</h6>
				</div>
				<div class="card-body">
					<div class="table-responsive">
			<form class="d-none d-sm-inline-block form-inline mr-auto ml-md-3 my-2 my-md-0 mw-100 navbar-search" action='CUS016colabor.php' method='POST' enctype='multipart/form-data'>
				<div class="input-group">
				<input type='text' class="form-control bg-light border-0 small" name='colaborador' placeholder='Buscando Colaborador...'>
			<input type='submit' class="btn btn-primary" name='buscar' value="Buscar" >
			</div>
			</form>
			<br><br>
			<?php
			if (!isset($_POST["buscar"])){
			include ("../inc/clases.php");
				$objColaborador=new Colaborador();
				list($resultado,$contar,$resultado2,$contar2)=$objColaborador->MostrarColaboradores();
            $sentencia2="SELECT a.cod_colaborador, CONCAT(b.nombres,' ',b.apellidos) as Nombre_Colaborador, a.cargo
			FROM colaboradores a,usuarios b where a.estado='A' and a.id_usuario_colab=b.id;";
            $resultado2 = mysqli_query($enlace,$sentencia2);
            $contar2= mysqli_num_rows($resultado2);
			echo"<form action='crearcolaborador.php' method='POST'>";
           if ($contar2==0){
           echo  "No hay colaboradores <br>";
           }
           else {

           echo "<form action='' method= 'POST'>";
           echo "<table class='table table-bordered' id='dataTable' width='100%' cellspacing='0'>";
           echo "<thead>";
           echo "	<tr>";
           echo "		<td>Codigo Colaborador</td>";
           echo "		<td>Nombre Colaborador</td>";
           echo "		<td>Cargo</td>";
           echo "		<td>Opciones</td>";
           echo "	</tr>";
		   echo "</thead>";
		   echo "<tbody>";
           for ($i=1; $i <= $contar; $i++){
             $registro = mysqli_fetch_row($resultado2);


             echo "	<tr>";
             echo "		<td>",$registro[0],"</td>";
             echo "		<td>",$registro[1],"</td>";
             echo "		<td>",$registro[2],"</td>";
             echo "		<td><a href='modificarcolab.php?cod=$registro[0]' class='d-none d-sm-inline-block btn btn-sm btn-primary shadow-sm'>Modificar</a>
			 <a href='vercolab.php?cod=$registro[0]' class='d-none d-sm-inline-block btn btn-sm btn-primary shadow-sm'>Consultar</a>
			 <a onclick='return alerta();' href='eliminarcolab.php?cod=$registro[0]' class='d-none d-sm-inline-block btn btn-sm btn-primary shadow-sm'>Eliminar</a></td> ";
             echo "	</tr>";

           }
           echo "</tbody>";
           echo "</table>";
           }
		   echo"<br><br>";
		   echo"<div class='d-sm-flex align-items-center justify-content-between mb-4'>";
		   echo" <input type='submit' class='btn btn-primary' value='Crear Colaborador' >";
		   echo"<a href='exportar.php?cod=''' class='d-none d-sm-inline-block btn btn-sm btn-primary shadow-sm'><i class='fas fa-download fa-sm text-white-50'></i> Exportar Reporte</a>";
			echo"</div>";
		echo"</form>";
		
			}
			else{
		   $colaborador = $_POST['colaborador'];
			echo"<form action='CUS016colabor.php' enctype='multipart/form-data'>";
			if ($colaborador==''){
				echo"No ha seleccionado ningún colaborador";
			}
			else {
           include ("../inc/clases.php");
			$objColaborador=new Colaborador();
			list($resultado,$contar)=$objColaborador->BuscarColaborador($colaborador);
           if ($contar==0){
           echo  "No hay colaborador con ese nombre";
           }
           else {

           echo "<form action='' method= 'POST'>";
           echo "<table class='table table-bordered' id='dataTable' width='100%' cellspacing='0'>";
           echo "<thead>";
           echo "	<tr>";
           echo "		<td>Codigo Colaborador</td>";
           echo "		<td>Nombre Colaborador</td>";
           echo "		<td>Cargo</td>";
           echo "		<td>Opciones</td>";
           echo "	</tr>";
		   echo "</thead>";
		   echo "<tbody>";
			$cod=array();
           for ($i=1; $i <= $contar; $i++){
             $registro = mysqli_fetch_row($resultado);

             echo "	<tr>";
             echo "		<td>",$registro[0],"</td>";
			 array_push($cod,$registro[0]);
             echo "		<td>",$registro[1],"</td>";
             echo "		<td>",$registro[2],"</td>";
             echo "		<td><a href='modificarcolab.php?cod=$registro[0]' class='d-none d-sm-inline-block btn btn-sm btn-primary shadow-sm'>Modificar</a>
			 <a href='vercolab.php?cod=$registro[0]' class='d-none d-sm-inline-block btn btn-sm btn-primary shadow-sm'>Consultar</a>
			 <a onclick='return alerta();' href='eliminarcolab.php?cod=$registro[0]' class='d-none d-sm-inline-block btn btn-sm btn-primary shadow-sm'>Eliminar</a></td> ";
             echo "	</tr>";

           }
           echo "</tbody>";
           echo "</table>";

           }
			}
			echo" <br><br>";
			$cod = serialize($cod);
			$cod = urlencode($cod);
			echo"<div class='d-sm-flex align-items-center justify-content-between mb-4'>";
			echo"<input type='submit' class='btn btn-primary' value='Regresar a relación de colaboradores'>";
			echo"<a href='exportar.php?cod=$cod' class='d-none d-sm-inline-block btn btn-sm btn-primary shadow-sm'><i class='fas fa-download fa-sm text-white-50'></i> Exportar Reporte</a>";
			echo"</div>";
		echo"</form>";
			 }
			 
					echo"</div>";
				echo"</div>";
			echo"</div>";
			include("../inc/menubajo.php");
			 }
	  ?>
</html>
