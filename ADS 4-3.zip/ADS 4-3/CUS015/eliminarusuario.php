<html>
<head> </head>
<body>
	<?php
			session_start(); //inicio de sesión
			if (!isset($_SESSION["usuario"])){
				session_destroy();
				echo "<br><br> <font color='red'>Intento de acceso sin autorización!!!</font>";
				header("Location:../intranet.html");
				exit;
			}
			$dni=$_GET["dni"];
			
			include ("../inc/clases.php");
			$objUsuario= new Usuario ();
			$objUsuario->EliminarUsuario($dni);
			
			header("Location:CUS015usuarios.php");
?>

</body>
</html>