<html lang="en">

		<?php
		
		session_start(); //inicio de sesión
		if (!isset($_SESSION["usuario"])){
			session_destroy();
			echo "<br><br> <font color='red'>Intento de acceso sin autorización!!!</font>";
			header("Location:../intranet.html");
			exit;
		}
			
		else {
			include("../inc/menuarriba.php");
		 /*$id_us= $_SESSION['id_us'];
		 $correo_us= $_SESSION['correo_us'];*/
			include("../inc/menu.php");
			
		 ?>
			<h1 class="h3 mb-2 text-gray-800">Relación de Usuarios</h1>
			<p class="mb-4">En esta página se puede administrar los usuarios.</p>
			<script src="http://code.jquery.com/jquery-latest.min.js" type="text/javascript"></script>
			<link rel="stylesheet" href="../css/estilos.css"/>
			<script src="script.js"></script>
			<script>
				function alerta()
				{
					return confirm("¿Esta seguro que desea eliminar este usuario?");
				}
				function alerta2()
				{
					return confirm("¿Esta seguro que desea activar este usuario?");
				}				
				
			</script>
			<div class="card shadow mb-4">
				<div class="card-header py-3">
				  <h6 class="m-0 font-weight-bold text-primary">Tabla de Usuarios</h6>
				</div>
				<div class="card-body">
					<div class="table-responsive">
			<form class="d-none d-sm-inline-block form-inline mr-auto ml-md-3 my-2 my-md-0 mw-100 navbar-search" action='CUS015usuarios.php' method='POST' enctype='multipart/form-data'>
				<div class="input-group">
			
						<input type='text' class="form-control bg-light border-0 small" name='usuario' placeholder='Buscando Usuario...'>  
						<input type='submit' class="btn btn-primary" name='buscar' value="Buscar">
				</div>
			</form>
			<br><br>
				
				<?php
				if (!isset($_POST["buscar"])){
				include ("../inc/clases.php");
				$objUsuario= new Usuario ();
				list($resultado,$contar)=$objUsuario->MostrarUsuarios();
				
				
			
				echo "<form action='crearusuario.php' method='POST'>";
				
				if ($contar==0){
				echo  "No hay usuarios <br>";
					}
				else {

				echo "<form action='' method= 'POST'>";
				echo "<table class='table table-bordered' id='dataTable' width='100%' cellspacing='0'>";
				echo "<thead>";
				echo "	<tr>";
				echo "		<td>DNI</td>";
				echo "		<td>Nombres</td>";
				echo "		<td>Apellidos</td>";
				echo "		<td>Fecha de nacimiento</td>";
				echo "		<td>Correo</td>";
				echo "		<td>Estado</td>";
				echo "		<td>Opciones</td>";
				echo "	</tr>";

				for ($i=1; $i <= $contar; $i++){
				$registro = mysqli_fetch_row($resultado);

				if ($registro[5]=='A'){
				echo "	<tr>";
				echo "		<td>",$registro[0],"</td>";
				echo "		<td>",$registro[1],"</td>";
				echo "		<td>",$registro[2],"</td>";
				echo "		<td>",$registro[3],"</td>";
				echo "		<td>",$registro[4],"</td>";
				echo "		<td>",$registro[5],"</td>";
				echo "		<td><a href='modificarusuario.php?dni=$registro[0]'>Modificar</a>  
				<a href='verusuario.php?dni=$registro[0]'>Consultar</a>  
				<a onclick='return alerta();' href='eliminarusuario.php?dni=$registro[0]'>Eliminar</a></td> ";
				echo "	</tr>";
					}
				else {
				echo "	<tr>";
				echo "		<td>",$registro[0],"</td>";
				echo "		<td>",$registro[1],"</td>";
				echo "		<td>",$registro[2],"</td>";
				echo "		<td>",$registro[3],"</td>";
				echo "		<td>",$registro[4],"</td>";
				echo "		<td>",$registro[5],"</td>";
				echo "		<td><a href='modificarusuario.php?dni=$registro[0]'>Modificar</a>  
				<a href='verusuario.php?dni=$registro[0]'>Consultar</a>  
				<a onclick='return alerta2();' href='activarusuario.php?dni=$registro[0]'>Activar</a></td> ";
				echo "	</tr>";	
					}	
				}
				echo "</tbody>";
				echo "</table>";
				}
            ?>
			<div class="d-sm-flex align-items-center justify-content-between mb-4">
			<input type='submit' class="btn btn-primary" value="Crear usuario" >
			<?php
			 echo"<a href='exportar.php?cod=''' class='d-none d-sm-inline-block btn btn-sm btn-primary shadow-sm'><i class='fas fa-download fa-sm text-white-50'></i> Exportar Reporte</a>";
			 ?>
			 </div>
			</form>
			
		<?php
			}
			else { 
			$nombre_usuario = $_POST['usuario'];
			echo"<form action='CUS015usuarios.php' enctype='multipart/form-data'>";
			
			include ("../inc/clases.php");
			$objUsuario=new Usuario();
			list($contar,$resultado2)= $objUsuario->BuscarUsuario($nombre_usuario);
			
            if ($nombre_usuario==''){
				echo"No ha seleccionado ningún concurso";
			}
			else {
			   if ($contar==0){
			   echo  "No hay concursos con ese nombre <br>";
				}
			   
			   else { 
			   echo "<form action='' method= 'POST'>";
				echo "<table class='table table-bordered' id='dataTable' width='100%' cellspacing='0'>";
				echo "<thead>";
				echo "	<tr>";
				echo "		<td>DNI</td>";
				echo "		<td>Nombres</td>";
				echo "		<td>Apellidos</td>";
				echo "		<td>Fecha de nacimiento</td>";
				echo "		<td>Correo</td>";
				echo "		<td>Estado</td>";
				echo "		<td>Opciones</td>";
				echo "	</tr>";
				$cod=array();
				for ($i=1; $i <= $contar; $i++){
				
				$registro = mysqli_fetch_row($resultado2);
				echo "	<tr>";
				echo "		<td>",$registro[0],"</td>";
				array_push($cod,$registro[0]);
				echo "		<td>",$registro[1],"</td>";
				echo "		<td>",$registro[2],"</td>";
				echo "		<td>",$registro[3],"</td>";
				echo "		<td>",$registro[4],"</td>";
				echo "		<td>",$registro[5],"</td>";
				echo "		<td><a href='modificarusuario.php?dni=$registro[0]'>Modificar</a>  
				<a href='verusuario.php?dni=$registro[0]'>Consultar</a>  
				<a onclick='return alerta();' href='eliminarusuario.php?dni=$registro[0]'>Eliminar</a></td> ";
				echo "	</tr>";
					}
				echo "</tbody>";
				echo "</table>";
				}
			}
			
			echo" <br><br>";
			$cod = serialize($cod);
			$cod = urlencode($cod);
			echo"<div class='d-sm-flex align-items-center justify-content-between mb-4'>";
			echo"<input type='submit' class='btn btn-primary' value='Regresar a relación de usuarios'>";
			echo"<a href='exportar.php?cod=$cod' class='d-none d-sm-inline-block btn btn-sm btn-primary shadow-sm'><i class='fas fa-download fa-sm text-white-50'></i> Exportar Reporte</a>";
			echo"</div>";
			echo"</form>";
             }
				echo"</div>";
			echo"</div>";
		echo"</div>";
			 			include("../inc/menubajo.php");
			 }
	  ?>
</html>
