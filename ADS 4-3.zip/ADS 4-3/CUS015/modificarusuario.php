<html lang="en">
	<?php
			session_start(); //inicio de sesión
			if (!isset($_SESSION["usuario"])){
				session_destroy();
				echo "<br><br> <font color='red'>Intento de acceso sin autorización!!!</font>";
				header("Location:../intranet.html");
				exit;
			}
			 else {
			include("../inc/menuarriba.php");
			 /*$id_us= $_SESSION['id_us'];
			 $correo_us= $_SESSION['correo_us'];*/
			include("../inc/menu.php");

	 ?>
			<h1 class="h3 mb-2 text-gray-800">Modificación de datos del usuario</h1>
			<p class="mb-4">En esta página se puede modificar los usuarios.</p>
			<div class="card shadow mb-4">
				<div class="card-header py-3">
				  <h6 class="m-0 font-weight-bold text-primary">Modificación de Usuarios</h6>
				</div>
				<div class="card-body">
					<div class="table-responsive">
			<form action='CUS015usuarios.php'>
			<input type='submit' value="Regresar a relación de usuarios" class='d-none d-sm-inline-block btn btn-sm btn-primary shadow-sm' >
			</form><br>
			<?php

            $dni=$_GET["dni"];
			include ("../inc/clases.php");
			$objUsuario= new Usuario();
			$fila=$objUsuario->ModificarUsuario($dni);			
 
			echo "<script src='http://code.jquery.com/jquery-latest.min.js' type='text/javascript'></script>";
			echo "<link rel='stylesheet' href='../css/estilos.css'/>";
			echo "<script src='script.js'></script>";
			echo "<script>";
			echo "function alerta(){";
			echo"return confirm('¿Está seguro que desea modificar este usuario?');}";
			echo "</script>";
            echo"<form class='user' onSubmit='return alerta();' action='editarusuario.php?dni=$dni' method='POST'>";
			echo"DNI: <input class='form-control' name='dni' type='text' value='$fila[1]' readonly> <br><br>";
			echo"Nombres: <input class='form-control' name='nombre_usuario' type='text' value='$fila[3]'> <br><br>";
			echo"Apellidos: <input class='form-control' name='apellido_usuario' type='text' value='$fila[4]'> <br><br>";
			echo"Fecha de nacimiento: <input class='form-control' name='nacimiento' type='date' value='$fila[5]'> <br><br>";
			echo"Correo usuario: <input class='form-control' name='correo_usuario' type='email'  value='$fila[8]'> <br><br>";
			
		
            echo "<input type='submit' value='Guardar' name='Guardar' class='d-none d-sm-inline-block btn btn-sm btn-primary shadow-sm'>";
            echo" </form>";
            ?>
						</div>
				</div>
			</div>
	  <?php
			include("../inc/menubajo.php");
			 }
	  ?>
</html>