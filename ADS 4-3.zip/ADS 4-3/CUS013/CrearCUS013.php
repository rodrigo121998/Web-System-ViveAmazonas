<html>
<head> </head>
<body>
<?php
	session_start(); //inicio de sesión
	if (!isset($_SESSION["usuario"])){
		session_destroy();
		echo "<br><br> <font color='red'>Intento de acceso sin autorización!!!</font>";
		header("Location:../intranet.html");
		exit;
	}
  if ($_POST['usuario'] === '')
                    {
                        $_POST['usuario'] = 'NULL';
                    }
  $usuario = $_POST["usuario"];
  $nombre = $_POST["nombre"];
	$ruc = $_POST["ruc"];
	$fecha = $_POST["fecha"];
	$pagina = $_POST["pagina"];
	$telefono = $_POST["telefono"];
	$direccion = $_POST["direccion"];
	$correo = $_POST["correo"];
	$pais = $_POST["pais"];
	$monto = $_POST["monto"];
	$telefono2 = $_POST["telefono2"];
	$enlace=mysqli_connect("localhost","root","","base_va");
	$sentencia="INSERT INTO donantes (ID_usuario,Nombre_donante,RUC,Fecha_donacion,pagina_web,telefono,direccion_donan,
	correo,pais,monto_donado,telefono2,estado)
	VALUES ($usuario,'$nombre','$ruc','$fecha','$pagina','$telefono',
	'$direccion','$correo','$pais',$monto,'$telefono2','A');";
	$resultado = mysqli_query($enlace,$sentencia);
	header("Location:CUS013.php");

 ?>
</body>
</html>
