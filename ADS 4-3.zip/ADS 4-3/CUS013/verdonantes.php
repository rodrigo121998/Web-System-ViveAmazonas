<html lang="en">
	<?php
	 session_start(); //inicio de sesión
			if (!isset($_SESSION["usuario"])){
				session_destroy();
				echo "<br><br> <font color='red'>Intento de acceso sin autorización!!!</font>";
				header("Location:../intranet.html");
				exit;
			}
			 else {
				 include("../inc/menuarriba.php");
			 /*$id_us= $_SESSION['id_us'];
			 $correo_us= $_SESSION['correo_us'];*/
				include("../inc/menu.php");
	 ?>
			<h1 class="h3 mb-2 text-gray-800">Ver datos del donante</h1>
			<p class="mb-4">En esta página se puede consultar los donantes.</p>
			<div class="card shadow mb-4">
				<div class="card-header py-3">
				  <h6 class="m-0 font-weight-bold text-primary">Consulta de Donante</h6>
				</div>
				<div class="card-body">
					<div class="table-responsive">
			<?php

            $cod=$_GET["cod"];
            $sentencia="SELECT * FROM donantes where IDDonante='$cod';";

            $resultado=mysqli_query($enlace,$sentencia);
            $fila=mysqli_fetch_row($resultado);

            echo"<form  class='user' action='CUS013.php' method='POST'>";
            if ($fila[1]==NULL){
              echo " DNI del usuario: <input class='form-control' name='usuario' type='text' value='$fila[1]' readonly><br><br>";
            }
            else {
            $sentenciauno="Select a.id_usuario,b.usuario from usuariosxperfil a, usuarios b where (a.cod_perfil=4) and (a.id_usuario=b.id)
    				and (b.id='$fila[1]');";
    				$resultadouno = mysqli_query($enlace,$sentenciauno);
    				$registrocero = mysqli_fetch_row($resultadouno);
                echo" Usuario Responsable: <input class='form-control' name='usuario' type='text' value='$registrocero[1]' readonly> <br><br>";
			} 
                echo"<b1>Nota: Si el Donante no tiene Usuario creado, no seleccionar ninguna opción de DNI</b1><br><br>";
                echo" Nombre del Donante: <input class='form-control' name='nombre' type='text' value='$fila[2]' readonly> <br><br>";
                echo" RUC: <input class='form-control' name='ruc' type='text' value='$fila[3]'  readonly> <br><br>";
                echo" Fecha de primera donación: <input class='form-control' name='fecha' type='date' value='$fila[4]' readonly> <br><br>";
                echo" Página web: <input class='form-control' name='pagina' type='url' value='$fila[5]' readonly> <br><br>";
                echo" Teléfono de contacto: <input class='form-control' name='telefono' type='tel' value='$fila[6]' readonly> <br><br>";
                echo" Dirección del donante: <input class='form-control' name='direccion' type='text' value='$fila[7]' readonly> <br><br>";
                echo" Correo Donante: <input class='form-control' name='correo' type='email' value='$fila[8]' readonly> <br><br>";
                echo" País: <input class='form-control' name='pais' type='text' value='$fila[9]' readonly> <br><br>";
                echo" Monto donado: <input class='form-control' name='monto' type='number' value='$fila[10]' readonly> <br><br>";
                echo" Teléfono alterno: <input class='form-control' name='telefono2' type='tel' value='$fila[11]' readonly> <br><br>";
                echo" <br>";
			
            echo "<input type='submit' value='Terminado' name='Terminado' class='d-none d-sm-inline-block btn btn-sm btn-primary shadow-sm'>";
			
            echo" </form>";
             ?>
			
					</div>
				</div>
			</div>
	  <?php
			include("../inc/menubajo.php");
			 }
	  ?>
</html>
