<html lang="en">
	<?php
	 session_start(); //inicio de sesión
			if (!isset($_SESSION["usuario"])){
				session_destroy();
				echo "<br><br> <font color='red'>Intento de acceso sin autorización!!!</font>";
				header("Location:../intranet.html");
				exit;
			}
			 else {
				 include("../inc/menuarriba.php");
			 /*$id_us= $_SESSION['id_us'];
			 $correo_us= $_SESSION['correo_us'];*/
				include("../inc/menu.php");
	 ?>
			<h1 class="h3 mb-2 text-gray-800">Creación de donante</h1>
			<p class="mb-4">En esta página se puede crear los donantes.</p>
			<script src="http://code.jquery.com/jquery-latest.min.js" type="text/javascript"></script>
			<link rel="stylesheet" href="../css/estilos.css"/>
			<script src="script.js"></script>
			<script>
				function alerta()
				{
					return confirm("¿Esta seguro que desea crear este Donante?");
				}
			</script>
			<div class="card shadow mb-4">
				<div class="card-header py-3">
				  <h6 class="m-0 font-weight-bold text-primary">Creación de donantes</h6>
				</div>
				<div class="card-body">
					<div class="table-responsive">
			<form action='CUS013.php'>
			<input type='submit' value="Regresar a relación de donantes" class='d-none d-sm-inline-block btn btn-sm btn-primary shadow-sm'>
			</form><br>
            <form class="user" onSubmit='return alerta();' action='CrearCUS013.php' method="POST">
              DNI del usuario: <select class="form-control" name="usuario">
  			<option value="">Elige una opción</option>
  				<?php
  				$sentencia2="Select a.id_usuario,b.usuario from usuariosxperfil a, usuarios b where a.cod_perfil=4 and a.id_usuario=b.id;";
  				$resultado2 = mysqli_query($enlace,$sentencia2);
  				$contar= mysqli_num_rows($resultado2);
  				if ($contar==0){
  				   echo "<option value=5>No hay usuario representante</option>";
  				}
  				else {
  					for ($i=1; $i <= $contar; $i++){
  					$registro = mysqli_fetch_row($resultado2);
  					echo "<option value=$registro[0]>$registro[1]</option>";

  					}
  				}
  				?>
  			</select><br><br>
            <b1>Nota: Si el Donante no tiene Usuario creado, no seleccionar ninguna opción de DNI</b1><br><br>
            Nombre del Donante: <input class="form-control" name="nombre" type="text"> <br><br>
            RUC: <input class="form-control" name="ruc" type="text"> <br><br>
            Fecha de primera donación: <input class="form-control" name="fecha" type="date"> <br><br>
            Página web: <input class="form-control" name="pagina" type="url"> <br><br>
            Teléfono de contacto: <input class="form-control" name="telefono" type="tel"> <br><br>
            Dirección de Donante: <input class="form-control" name="direccion" type="text"> <br><br>
            Correo Donante: <input class="form-control" name="correo" type="email"> <br><br>
            País: <input class="form-control" name="pais" type="text"> <br><br>
            Monto Donado: <input class="form-control" name="monto" type="number"> <br><br>
            Teléfono alterno: <input class="form-control" name="telefono2" type="tel"> <br><br>
            <br>
           <input type='submit' value='Guardar' name='Guardar' class='d-none d-sm-inline-block btn btn-sm btn-primary shadow-sm'>

            </form>
			</div>
				</div>
			</div>
	  <?php
				include("../inc/menubajo.php");
			 }
	  ?>
</html>