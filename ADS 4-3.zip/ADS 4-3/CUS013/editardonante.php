<html>
	<head>
	</head>

	<body>
		<?php
		session_start(); //inicio de sesión
					if (!isset($_SESSION["usuario"])){
						session_destroy();
						echo "<br><br> <font color='red'>Intento de acceso sin autorización!!!</font>";
						header("Location:../intranet.html");
						exit;
					}
			$cod=$_GET["cod"];
      $usuario = $_POST["usuario"];
    	$nombre = $_POST["nombre"];
    	$ruc = $_POST["ruc"];
    	$fecha = $_POST["fecha"];
    	$pagina = $_POST["pagina"];
    	$telefono = $_POST["telefono"];
    	$direccion = $_POST["direccion"];
    	$correo = $_POST["correo"];
    	$pais = $_POST["pais"];
    	$monto = $_POST["monto"];
    	$telefono2 = $_POST["telefono2"];
			$enlace = mysqli_connect("localhost","root","","base_va");
			$sentencia="update donantes set ID_Usuario=$usuario , Nombre_donante = '$nombre',
			RUC= '$ruc',Fecha_donacion = '$fecha', pagina_web = '$pagina',
			telefono = '$telefono',direccion_donan = '$direccion',
			correo='$correo',pais='$pais',monto_donado=$monto,telefono2='$telefono2'
			where IDDonante='$cod';";
			$resultado = mysqli_query($enlace,$sentencia);
			header("Location:CUS013.php");
		?>
	</body>
</html>
