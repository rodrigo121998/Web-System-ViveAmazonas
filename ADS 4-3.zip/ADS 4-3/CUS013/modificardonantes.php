<html lang="en">
	<?php
	 session_start(); //inicio de sesión
			if (!isset($_SESSION["usuario"])){
				session_destroy();
				echo "<br><br> <font color='red'>Intento de acceso sin autorización!!!</font>";
				header("Location:../intranet.html");
				exit;
			}
			 else {
				include("../inc/menuarriba.php");
			 /*$id_us= $_SESSION['id_us'];
			 $correo_us= $_SESSION['correo_us'];*/
				include("../inc/menu.php");
	 ?>
			<h1 class="h3 mb-2 text-gray-800">Modificación de datos del donante</h1>
			<p class="mb-4">En esta página se puede modificar los donantes.</p>
			<div class="card shadow mb-4">
				<div class="card-header py-3">
				  <h6 class="m-0 font-weight-bold text-primary">Modificación de Donantes</h6>
				</div>
				<div class="card-body">
					<div class="table-responsive">
			<form action='CUS013.php'>
			<input type='submit' value="Regresar a relación de donantes" class='d-none d-sm-inline-block btn btn-sm btn-primary shadow-sm' >
			</form><br>
			<?php

            $cod=$_GET["cod"];
            $sentencia3="SELECT * FROM donantes where IDDonante='$cod';";

            $resultado3=mysqli_query($enlace,$sentencia3);
            $fila=mysqli_fetch_row($resultado3);
			echo "<script src='http://code.jquery.com/jquery-latest.min.js' type='text/javascript'></script>";
			echo "<link rel='stylesheet' href='css/estilos.css'/>";
			echo "<script src='script.js'></script>";
			echo "<script>";
			echo "function alerta(){";
			echo	"return confirm('¿Está seguro que desea modificar este Donante?');}";
			echo "</script>";
      echo"<form class='user' onSubmit='return alerta();' action='editardonante.php?cod=$cod' method='POST'>";
      echo" DNI del usuario: <select  class='form-control' name='usuario'>";
    $sentenciauno="Select a.id_usuario,b.usuario from usuariosxperfil a, usuarios b where (a.cod_perfil=4) and (a.id_usuario=b.id)
    and (b.id=$fila[1]);";
    $resultadouno = mysqli_query($enlace,$sentenciauno);
    $registrocero = mysqli_fetch_row($resultadouno);
    echo  "<option value='$registrocero[0]'>$registrocero[1]</option>";
    $sentencia2="Select a.id_usuario,b.usuario from usuariosxperfil a, usuarios b where (a.cod_perfil=4) and (a.id_usuario=b.id);";
    $resultado2 = mysqli_query($enlace,$sentencia2);
    $contar= mysqli_num_rows($resultado2);
    if ($contar==0){
     echo  "<option value=5>No hay otro posible Donante</option>";
    }
    else {
    for ($i=1; $i <= $contar; $i++){
    $registro = mysqli_fetch_row($resultado2);
    echo "<option value='$registro[0]'>$registro[1]</option>";

    }
    }
    echo "</select><br>";
            echo"<b1>Nota: Si el Donante no tiene Usuario creado, no seleccionar ninguna opción de DNI</b1><br><br>";
            echo" Nombre del Donante: <input  class='form-control' name='nombre' type='text' value='$fila[2]'> <br><br>";
            echo" RUC: <input  class='form-control' name='ruc' type='text' value='$fila[3]'> <br><br>";
            echo" Fecha de primera donación: <input  class='form-control' name='fecha' type='date' value='$fila[4]'> <br><br>";
            echo" Página web: <input  class='form-control' name='pagina' type='url' value='$fila[5]'> <br><br>";
            echo" Teléfono de contacto: <input  class='form-control' name='telefono' type='tel' value='$fila[6]'> <br><br>";
            echo" Dirección del donante: <input  class='form-control' name='direccion' type='text' value='$fila[7]'> <br><br>";
            echo" Correo Donante: <input  class='form-control' name='correo' type='email' value='$fila[8]'> <br><br>";
            echo" País: <input  class='form-control' name='pais' type='text' value='$fila[9]'> <br><br>";
            echo" Monto donado: <input  class='form-control' name='monto' type='number' value='$fila[10]'> <br><br>";
            echo" Teléfono alterno: <input  class='form-control' name='telefono2' type='tel' value='$fila[11]'> <br><br>";
            echo" <br>";
             echo "<input type='submit' value='Guardar' name='Guardar' class='d-none d-sm-inline-block btn btn-sm btn-primary shadow-sm'>";
            echo" </form>";
            ?>
		</div>
				</div>
			</div>
	  <?php
			include("../inc/menubajo.php");
			 }
	  ?>
</html>