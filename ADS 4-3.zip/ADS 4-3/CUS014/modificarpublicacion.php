<html lang="en">
	<?php
			session_start(); //inicio de sesión
			if (!isset($_SESSION["usuario"])){
				session_destroy();
				echo "<br><br> <font color='red'>Intento de acceso sin autorización!!!</font>";
				header("Location:../intranet.html");
				exit;
			}
			 else {
			include("../inc/menuarriba.php");	 
			 /*$id_us= $_SESSION['id_us'];
			 $correo_us= $_SESSION['correo_us'];*/
			include("../inc/menu.php");

	 ?>
			<h1 class="h3 mb-2 text-gray-800">Modificación de datos de publicaciones</h1>
			<p class="mb-4">En esta página se puede modificar los publicaciones.</p>
			<div class="card shadow mb-4">
				<div class="card-header py-3">
				  <h6 class="m-0 font-weight-bold text-primary">Modificación de Publicaciones</h6>
				</div>
				<div class="card-body">
					<div class="table-responsive">
			<form action='CUS014publicaciones.php'>
			<input type='submit' value="Regresar a relación de publicaciones" class='d-none d-sm-inline-block btn btn-sm btn-primary shadow-sm' >
			</form><br>
			
			<?php

            $codigo_publicacion=$_GET["codigo_publicacion"];
			include ("../inc/clases.php");
			$objPublicacion= new Publicacion();
			list($fila,$registro,$resultado3,$contar)=$objPublicacion->ModificarPublicacion($codigo_publicacion);			
 
			echo "<script src='http://code.jquery.com/jquery-latest.min.js' type='text/javascript'></script>";
			echo "<link rel='stylesheet' href='../css/estilos.css'/>";
			echo "<script src='script.js'></script>";
			echo "<script>";
			echo "function alerta(){";
			echo "return confirm('¿Está seguro que desea modificar esta publicación?');}";
			echo "</script>";
            echo "<form class='user'onSubmit='return alerta();' action='editarpublicacion.php?codigo_publicacion=$codigo_publicacion' method='POST' enctype='multipart/form-data'>";
			echo "Título publicación: <input class='form-control' name='titulo' type='text' value='$fila[2]'> <br><br>";
			echo "Mensaje:<br>";
			echo "<textarea class='form-control' name='mensaje' rows='10' cols='40' value='$fila[3]'>$fila[3]</textarea>";
			echo "<br><br>";
			echo "Archivo adjunto:";
			
				if ($fila[4]<>NULL){
				echo"<a href='descargar_documento.php?codigo_publicacion=$codigo_publicacion'class='d-none d-sm-inline-block btn btn-sm btn-primary shadow-sm'>Documento</a><br><br>";
				echo"<a href='subir_documento.php?codigo_publicacion=$codigo_publicacion' class='d-none d-sm-inline-block btn btn-sm btn-primary shadow-sm'>Cambiar Documento</a><br><br>";
					} 
				else{
					echo "No hay archivo subido<br><br>";
					echo"<a href='subir_documento.php?codigo_publicacion=$codigo_publicacion' class='d-none d-sm-inline-block btn btn-sm btn-primary shadow-sm'>Agregar Documento</a><br><br>";
					}		
					
			echo "Duración: <input class='form-control' name='duracion' type='text' value='$fila[5]'> <br><br>";
			echo "Formato: <input class='form-control' name='formato' type='text' value='$fila[6]'> <br><br>";
			echo "Categoría: <input class='form-control' name='categoria' type='text' value='$fila[7]'> <br><br>";
			echo "Código del concurso: <select class='form-control' name='codigo_concurso'>";	
			echo "<option value=$registro[0]>$registro[1]</option>";
				
				if ($contar==0){
				   echo  "<option value=''>No hay otros concursos</option>";
				}
				else {
					for ($i=1; $i <= $contar; $i++){
					$registro2 = mysqli_fetch_row($resultado3);
					echo "<option value=$registro2[0]>$registro2[1]</option>";					
					}
				}			
			echo"</select><br><br>";
            echo "<input type='submit' value='Guardar' name='Guardar' class='d-none d-sm-inline-block btn btn-sm btn-primary shadow-sm'>";
            echo" </form>";
            ?>
		</div>
				</div>
			</div>
	  <?php
			include("../inc/menubajo.php");
			 }
	  ?>
</html>
