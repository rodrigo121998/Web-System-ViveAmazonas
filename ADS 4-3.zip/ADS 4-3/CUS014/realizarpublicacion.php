<html>
<head> </head>
<body>
	<?php
			session_start(); //inicio de sesión
			if (!isset($_SESSION["usuario"])){
				session_destroy();
				echo "<br><br> <font color='red'>Intento de acceso sin autorización!!!</font>";
				header("Location:../intranet.html");
				exit;
			}
			$codigo_publicacion=$_GET["codigo_publicacion"];
			
			include ("../inc/clases.php");
			$objPublicacion= new Publicacion ();
			$objPublicacion->RealizarPublicacion($codigo_publicacion);
			
			header("Location:CUS014publicaciones.php");
?>

</body>
</html>