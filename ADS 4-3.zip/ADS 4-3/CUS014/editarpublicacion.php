<html>

	<head>

	</head>

	<body>
		<?php
				  session_start(); //inicio de sesión
					if (!isset($_SESSION["usuario"])){
						session_destroy();
						echo "<br><br> <font color='red'>Intento de acceso sin autorización!!!</font>";
						header("Location:../intranet.html");
						exit;
					}
					$codigo_publicacion=$_GET["codigo_publicacion"];
					$titulo = $_POST['titulo'];
					$mensaje = $_POST['mensaje'];
					$duracion = $_POST['duracion'];
					$formato = $_POST['formato'];
					$categoria = $_POST['categoria'];
					$codigo_concurso = $_POST['codigo_concurso'];
					
					include ("../inc/clases.php");
					$objPublicacion= new Publicacion();
					$objPublicacion->EditarPublicacion($codigo_publicacion,$titulo,$mensaje,$duracion,$formato,$categoria,$codigo_concurso);
						
					header("Location:CUS014publicaciones.php");
		?>
	</body>
</html>