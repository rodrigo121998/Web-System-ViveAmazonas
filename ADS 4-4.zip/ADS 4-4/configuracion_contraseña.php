
<?php
ob_start();

$enlace = mysqli_connect("localhost","root","","base_va");
$usuario = $_POST['usuario'];
$sentencia="SELECT nombres, contraseña, correo from usuarios where usuario=$usuario and estado='A';";

$resultado=mysqli_query($enlace,$sentencia);
$fila=mysqli_fetch_row($resultado);

require "PHPMailer/class.phpmailer.php";
$mail = new PHPMailer();
$mail->isSMTP();
$mail->SMTPAuth = true;
$mail->SMTPSecure='tls';
$mail->Host = "smtp.gmail.com";
$mail->Port = '587';
$mail->SMTPDebug  = 2;
$mail->IsHTML(true);

$mail->Username = 'vive.amazonas.1@gmail.com';
$mail->Password = 'vive.amazonas123';		

$mail->ClearAddresses(); 	
$correo=$fila[2];
$mail->setFrom('vive.amazonas.1@gmail.com', 'Vive Amazonas');
$mail -> addAddress ( $correo,'Cliente' );
$mail->WordWrap=50;
$subjects =  "Recuperación de contraseña";
$mail -> Subject = $subjects;
$mail ->  Body = " <b>Estimado(a) $fila[0], su contraseña es la siguiente: $fila[1]</b><br>  " ;	                 
if($mail-> send()) {
echo"Enviado";
}



//header_remove();
header("Location:confirmacion_contraseña.html");
//header_remove();
ob_end_flush();

?>