<html>
		<?php

		 session_start(); //inicio de sesi�n
						if (!isset($_SESSION["usuario"])){
							session_destroy();
							echo "<br><br> <font color='red'>Intento de acceso sin autorizaci�n!!!</font>";
							header("Location:../intranet.html");
							exit;
						}
			 else {
				 include("../inc/menuarriba.php");
			 /*$id_us= $_SESSION['id_us'];
			 $correo_us= $_SESSION['correo_us'];*/
					include("../inc/menu.php");
					$usuario=$_SESSION['usuario'];
		 ?>
			<h1 class="h3 mb-2 text-gray-800">Relación de Evaluaciones</h1>
			<p class="mb-4">En esta página se pueden visualizar las evaluaciones.</p>
			<script src="http://code.jquery.com/jquery-latest.min.js" type="text/javascript"></script>
			<link rel="stylesheet" href="../css/estilos.css"/>
			<script src="script.js"></script>
			<script>
				function alerta()
				{
					return confirm("Está seguro que desea eliminar este proyecto?");
				}
			</script>
			<div class="card shadow mb-4">
				<div class="card-header py-3">
				  <h6 class="m-0 font-weight-bold text-primary">Tabla de Evaluaciones</h6>
				</div>
				<div class="card-body">
					<div class="table-responsive">
			<form class="d-none d-sm-inline-block form-inline mr-auto ml-md-3 my-2 my-md-0 mw-100 navbar-search" action='' method='POST' enctype='multipart/form-data'>
				<div class="input-group">
					<input type='text' class="form-control bg-light border-0 small" name='proyecto' placeholder='Buscar proyecto...'>
					<input type='submit' class="btn btn-primary" name='buscar' value="Buscar proyecto" ><br><br>
				</div>
			</form>
			<br><br>
			<?php
			if (!isset($_POST["buscar"])){
				$sentencia5="select id_evaluador from (select codigo_evaluador from
					(select id from usuarios where usuario='$usuario') a, evaluadores b where a.id=b.usuario) c,
					(select b.id_evaluador from proyectos a, evaluadoresxconcurso b where a.Codigo_Concurso=b.id_concurso) d
					where c.codigo_evaluador=d.id_evaluador;";
					$resultado5 = mysqli_query($enlace,$sentencia5);
					$registro5 = mysqli_fetch_row($resultado5);
            $sentencia2= "SELECT a.codigo_proyecto,b.Nombre_Proyecto,a.tipo_evaluacion,a.puntaje,b.Estado_Proyecto,a.codigo_evaluacion FROM evaluaciones a, proyectos b where b.codigo_proyecto=a.codigo_proyecto and b.Estado='A' and a.evaluador='$registro5[0]';";
			$resultado2 = mysqli_query($enlace,$sentencia2);
            $contar= mysqli_num_rows($resultado2);

		   if ($contar==0){
           echo  "No hay evaluaciones <br>";
           }
           else {

           echo "<form action='' method= 'POST'>";
           echo "<table class='table table-bordered' id='dataTable' width='100%' cellspacing='0'>";
           echo "<thead>";
		   echo "	<tr>";
           echo "		<td>Codigo Proyecto</td>";
           echo "		<td>Nombre Proyecto</td>";
           echo "		<td>Tipo de evaluación</td>";
					 echo "		<td>Puntaje</td>";
					 //echo "		<td>Estado del proyecto</td>";
           echo "		<td>Opciones</td>";
           echo "	</tr>";
			echo "</thead>";
		   echo "<tbody>";
           for ($i=1; $i <= $contar; $i++){
             $registro = mysqli_fetch_row($resultado2);


             echo "	<tr>";
             echo "		<td>",$registro[0],"</td>";
             echo "		<td>",$registro[1],"</td>";
             echo "		<td>",$registro[2],"</td>";
						 echo "		<td>",$registro[3],"</td>";
						 //echo "		<td>",$registro[4],"</td>";
             echo "		<td> <a href='modificarevaluacion.php?cod=$registro[5]' class='d-none d-sm-inline-block btn btn-sm btn-primary shadow-sm'>Modificar</a> <a href='consultarevaluacion.php?cod=$registro[5]' class='d-none d-sm-inline-block btn btn-sm btn-primary shadow-sm'>Consultar</a> <a href='eliminarevaluacion.php?cod=$registro[0]' class='d-none d-sm-inline-block btn btn-sm btn-primary shadow-sm'>Eliminar</a> </td> ";
             echo "	</tr>";

           }
		   echo "</tbody>";
           echo "</table>";

           }

             ?>
		  </form>
	  <?php
			}
			 else {
			$proyecto = $_POST['proyecto'];
			echo"<form action='CUS0172.php' enctype='multipart/form-data'>";
			if ($proyecto==''){
				echo"No ha seleccionado ningún proyecto evaluado";
			}
			else {
				$sentencia6="select id_evaluador from (select codigo_evaluador from
					(select id from usuarios where usuario='$usuario') a, evaluadores b where a.id=b.usuario) c,
					(select b.id_evaluador from proyectos a, evaluadoresxconcurso b where a.Codigo_Concurso=b.id_concurso) d
					where c.codigo_evaluador=d.id_evaluador;";
					$resultado6 = mysqli_query($enlace,$sentencia6);
					$registro6 = mysqli_fetch_row($resultado6);
						$sentencia8= "SELECT a.codigo_proyecto,b.Nombre_Proyecto,a.tipo_evaluacion,a.puntaje,b.Estado_Proyecto,a.codigo_evaluacion FROM evaluaciones a, proyectos b where b.Estado='A' and  b.codigo_proyecto=a.codigo_proyecto and a.evaluador='$registro6[0]' and b.Nombre_Proyecto like '%$proyecto%';";
			$resultado = mysqli_query($enlace,$sentencia8);
			  $contar1= mysqli_num_rows($resultado);
           if ($contar1==0){
           echo  "No hay proyectos con ese nombre<br>";
           }
           else {

           echo "<form action='' method= 'POST'>";
           echo "<table class='table table-bordered' id='dataTable' width='100%' cellspacing='0'>";
           echo "<thead>";
		   echo "	<tr>";
			 echo "		<td>Codigo Proyecto</td>";
			 echo "		<td>Nombre Proyecto</td>";
			 echo "		<td>Tipo de evaluación</td>";
			 echo "		<td>Puntaje</td>";
			 //echo "		<td>Estado del proyecto</td>";
			 echo "		<td>Opciones</td>";
           echo "	</tr>";
		   echo "</thead>";
		   echo "<tbody>";

           for ($i=1; $i <= $contar1; $i++){
             $registro = mysqli_fetch_row($resultado);


             echo "	<tr>";
						 echo "		<td>",$registro[0],"</td>";
						 echo "		<td>",$registro[1],"</td>";
						 echo "		<td>",$registro[2],"</td>";
						echo "		<td>",$registro[3],"</td>";
						//echo "		<td>",$registro[4],"</td>";
						 echo "		<td> <a href='modificarevaluacion.php?cod=$registro[5]' class='d-none d-sm-inline-block btn btn-sm btn-primary shadow-sm'>Modificar</a> <a href='consultarevaluacion.php?cod=$registro[5]' class='d-none d-sm-inline-block btn btn-sm btn-primary shadow-sm'>Consultar</a> <a href='eliminarevaluacion.php?cod=$registro[0]' class='d-none d-sm-inline-block btn btn-sm btn-primary shadow-sm'>Eliminar</a> </td> ";
						 echo "	</tr>";
           }
		   echo "</tbody>";
           echo "</table>";

           }
			}

			echo" <br><br>";
			echo"<input type='submit' class='btn btn-primary' value='Regresar a relación de evaluaciones'>";
			echo"</form>";

			 }
				echo"</div>";
			echo"</div>";
		echo"</div>";
			 include("../inc/menubajo.php");
			 }
	  ?>
</html>
