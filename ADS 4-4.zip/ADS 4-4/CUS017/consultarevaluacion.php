<html>
	<?php
			session_start(); //inicio de sesión
			if (!isset($_SESSION["usuario"])){
				session_destroy();
				echo "<br><br> <font color='red'>Intento de acceso sin autorización!!!</font>";
				header("Location:../intranet.html");
				exit;
			}
			 else {
				 include("../inc/menuarriba.php");
			 /*$id_us= $_SESSION['id_us'];
			 $correo_us= $_SESSION['correo_us'];*/
				include("../inc/menu.php");
	 ?>
			<h1 class="h3 mb-2 text-gray-800">Ver datos de evaluación</h1>
			<p class="mb-4">En esta página se pueden consultar las evaluaciones</p>
			<div class="card shadow mb-4">
				<div class="card-header py-3">
				  <h6 class="m-0 font-weight-bold text-primary">Consulta de Evaluaciones</h6>
				</div>
				<div class="card-body">
					<div class="table-responsive">
			<?php

            $cod=$_GET["cod"];
            $enlace = mysqli_connect("localhost","root","","base_va");

            $sentencia="SELECT * FROM evaluaciones where codigo_evaluacion='$cod';";

            $resultado=mysqli_query($enlace,$sentencia);
            $fila=mysqli_fetch_row($resultado);

            echo"<form class='user' action='CUS0172.php' method='POST' enctype='multipart/form-data'>";
						echo" Codigo del Proyecto: <input class='form-control' name='proy' type='text' value='$fila[1]' readonly><br><br>";
						echo" Tipo de evaluación: <input class='form-control' name='tipo' type='text' value='$fila[3]' readonly><br><br>";
						echo" Puntaje asignado: <input class='form-control' name='puntaje' type='text' value='$fila[5]'readonly><br><br>";
						echo" Observaciones adicionales: <input class='form-control' name='obs' type='text' value='$fila[6]' readonly><br><br>";
						echo" Motivo de decisión: <input class='form-control' name='motivo' type='text' value='$fila[7]' readonly><br><br>";
            echo" <br>";

            echo "<input type='submit' value='Terminado' name='Terminado' class='d-none d-sm-inline-block btn btn-sm btn-primary shadow-sm'>";

            echo" </form>";
            ?>
					</div>
				</div>
			</div>
	  <?php
			include("../inc/menubajo.php");
			 }
	  ?>
</html>
