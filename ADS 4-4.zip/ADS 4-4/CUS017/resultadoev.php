<html>
	<?php
			session_start(); //inicio de sesión
			if (!isset($_SESSION["usuario"])){
				session_destroy();
				echo "<br><br> <font color='red'>Intento de acceso sin autorización!!!</font>";
				header("Location:../intranet.html");
				exit;
			}
			 else {
				 include("../inc/menuarriba.php");
			 /*$id_us= $_SESSION['id_us'];
			 $correo_us= $_SESSION['correo_us'];*/
				include("../inc/menu.php");
				$codigos = unserialize($_GET['cod']);
				list($cod,$decision)=$codigos;
				$codigos = serialize($codigos);
				$codigos = urlencode($codigos);

	 ?>
			<h1 class="h3 mb-2 text-gray-800">Resultado de la evaluación</h1>
			<p class="mb-4">En esta página se puede visualizar el puntaje asignado.</p>
			<div class="card shadow mb-4">
				<div class="card-header py-3">
				  <h6 class="m-0 font-weight-bold text-primary">Datos de la evaluación.</h6>
				</div>
				<div class="card-body">
					<?php
						if($decision=='DIGE'){
						$C1=intval($_POST["C1"]);
						$C2=intval($_POST["C2"]);
						$C3=intval($_POST["C3"]);
						$C4=intval($_POST["C4"]);
						$C5=intval($_POST["C5"]);
						$C6=intval($_POST["C6"]);
						$C7=intval($_POST["C7"]);
						$C8=intval($_POST["C8"]);
						$C9=intval($_POST["C9"]);
						$puntaje=$C1+$C2+$C3+$C4+$C5+$C6+$C7+$C8+$C9;
						$enlace = mysqli_connect("localhost","root","","base_va");
                   
						$sentencia="SELECT * FROM proyectos where Codigo_Proyecto='$cod';";

						$resultado=mysqli_query($enlace,$sentencia);
						$fila=mysqli_fetch_row($resultado);

						echo"<form class='user' action='ingresarev.php?cod=$cod' method='POST' enctype='multipart/form-data'>";
						echo" Nombre Proyecto: <input class='form-control' name='nombre' type='text' value='$fila[1]' readonly> <br><br>";
					    echo" Puntaje asignado: <input class='form-control' name='puntaje' type='text' value='$puntaje' readonly> <br><br>";
						echo" Resultado: <br> ";
						if( $puntaje<>9){
							 echo"  <input class='form-control' name='proy' type='text' value='Se rechaza el proyecto en la Fase 1' readonly> <br><br>";
							  echo"  <input class='form-control' name='decision' type='hidden' value='Rechazado por DIGE' readonly> <br><br>";
							 echo" Motivo  de decisión:<br>";
							 echo" <textarea  class='form-control' name='motivo' rows='5' placeholder='Escribe aquí la descripción'></textarea>";
							 echo"<br><br>";
							 echo" Observaciones adicionales:<br>";
							 echo "<textarea  class='form-control' name='observaciones' rows='5' placeholder='Escribe aquí la descripción'></textarea>";
							 echo "<br><br>";
						}	
                        else{
							echo"  <input class='form-control' name='proy' type='text' value='El proyecto está apto para pasar a la fase 2' readonly> <br><br>";
							 echo"  <input class='form-control' name='decision' type='hidden' value='Aceptado por DIGE' readonly> <br><br>";
							 echo" Motivo  de decisión:<br>";
							 echo" <textarea  class='form-control' name='motivo' rows='5' placeholder='Escribe aquí la descripción'></textarea>";
							 echo"<br><br>";
							 echo" Observaciones adicionales:<br>";
							 echo "<textarea  class='form-control' name='observaciones' rows='5' placeholder='Escribe aquí la descripción'></textarea>";
							 echo "<br><br>";							
							
						}	
							echo"<input type='submit' class='btn btn-primary' value='Ingresar evaluación'>";
							echo"</form>";							
							echo"<form class='user' action='evaluarproyectos.php?cod2=$codigos' method='POST' enctype='multipart/form-data'>";							
								echo"<input type='submit' class='btn btn-primary' value='Regresar a evaluar'>";
							echo"</form>";	
						}
						#<!-- Etapa 2 : Representante CTI  -->
						if($decision=='CTI'){
						$C1=$_POST['puntaje1'];
						$C2=$_POST['puntaje2'];
						$C3=$_POST['puntaje3'];
						$C4=$_POST['puntaje4'];
						$C5=$_POST['puntaje5'];
						
						$avance=$C1+$C2+$C3+$C4+$C5;
						$puntaje=$avance/5;
						$enlace = mysqli_connect("localhost","root","","base_va");
                   
						$sentencia="SELECT * FROM proyectos where Codigo_Proyecto='$cod';";

						$resultado=mysqli_query($enlace,$sentencia);
						$fila=mysqli_fetch_row($resultado);

						echo"<form class='user' action='ingresarev.php?cod=$cod' method='POST' enctype='multipart/form-data'>";
						echo" Nombre Proyecto: <input class='form-control' name='nombre' type='text' value='$fila[1]' readonly> <br><br>";
					    echo" Puntaje asignado: <input class='form-control' name='puntaje' type='text' value='$puntaje' readonly> <br><br>";
						echo" Resultado: <br> ";
						if( $puntaje<15){
							 echo"  <input class='form-control' name='proy' type='text' value='Se rechaza el proyecto en la Fase 1' readonly> <br><br>";
							  echo"  <input class='form-control' name='decision' type='hidden' value='Rechazado por CTI' readonly> <br><br>";
							 echo" Motivo  de decisión:<br>";
							 echo" <textarea  class='form-control' name='motivo' rows='5' placeholder='Escribe aquí la descripción'></textarea>";
							 echo"<br><br>";
							 echo" Observaciones adicionales:<br>";
							 echo "<textarea  class='form-control' name='observaciones' rows='5' placeholder='Escribe aquí la descripción'></textarea>";
							 echo "<br><br>";
						}	
                        else{
							echo"  <input class='form-control' name='proy' type='text' value='El proyecto está apto para pasar a la fase 2' readonly> <br><br>";
							 echo"  <input class='form-control' name='decision' type='hidden' value='Aceptado por CTI' readonly> <br><br>";
							 echo" Motivo  de decisión:<br>";
							 echo" <textarea  class='form-control' name='descripcion' rows='5' placeholder='Escribe aquí la descripción'></textarea>";
							 echo"<br><br>";
							 echo" Observaciones adicionales:<br>";
							 echo "<textarea  class='form-control' name='descripcion' rows='5' placeholder='Escribe aquí la descripción'></textarea>";
							 echo "<br><br>";							
							
						}	
							echo"<input type='submit' class='btn btn-primary' value='Ingresar evaluación'>";
							echo"</form>";		
							echo"<form class='user' action='evaluarproyectos.php?cod=$codigos' method='POST' enctype='multipart/form-data'>";							
								echo"<input type='submit' class='btn btn-primary' value='Regresar a evaluar'>";
							echo"</form>";	
						}
						#<!-- Etapa 3 : Representante CTE  -->

						if($decision=='CTE'){
						$C1=$_POST['puntaje1'];
						$C2=$_POST['puntaje2'];
						$C3=$_POST['puntaje3'];
						$C4=$_POST['puntaje4'];
						$C5=$_POST['puntaje5'];
						
						$avance=$C1+$C2+$C3+$C4+$C5;
						$puntaje=$avance/5;
						
						$enlace = mysqli_connect("localhost","root","","base_va");
                   
						$sentencia="SELECT * FROM proyectos where Codigo_Proyecto='$cod';";

						$resultado=mysqli_query($enlace,$sentencia);
						$fila=mysqli_fetch_row($resultado);

						echo"<form class='user' action='ingresarev.php?cod=$cod' method='POST' enctype='multipart/form-data'>";
						echo" Nombre Proyecto: <input class='form-control' name='nombre' type='text' value='$fila[1]' readonly> <br><br>";
					    echo" Puntaje asignado: <input class='form-control' name='puntaje' type='text' value='$puntaje' readonly> <br><br>";
						echo" Resultado: <br> ";
						if( $puntaje<15){
							 echo"  <input class='form-control' name='proy' type='text' value='Se rechaza el proyecto en la Fase 2' readonly> <br><br>";
							  echo"  <input class='form-control' name='decision' type='hidden' value='Rechazado por CTE' readonly> <br><br>";
							 echo" Motivo  de decisión:<br>";
							 echo" <textarea  class='form-control' name='motivo' rows='5' placeholder='Escribe aquí la descripción'></textarea>";
							 echo"<br><br>";
							 echo" Observaciones adicionales:<br>";
							 echo "<textarea  class='form-control' name='observaciones' rows='5' placeholder='Escribe aquí la descripción'></textarea>";
							 echo "<br><br>";
						}	
                        else{
							echo"  <input class='form-control' name='proy' type='text' value='El proyecto está apto para pasar a la fase 3' readonly> <br><br>";
							 echo"  <input class='form-control' name='decision' type='hidden' value='Aceptado por CTE' readonly> <br><br>";
							 echo" Motivo  de decisión:<br>";
							 echo" <textarea  class='form-control' name='descripcion' rows='5' placeholder='Escribe aquí la descripción'></textarea>";
							 echo"<br><br>";
							 echo" Observaciones adicionales:<br>";
							 echo "<textarea  class='form-control' name='descripcion' rows='5' placeholder='Escribe aquí la descripción'></textarea>";
							 echo "<br><br>";							
							
						}	
							echo"<input type='submit' class='btn btn-primary' value='Ingresar evaluación'>";
							echo"</form>";		
							echo"<form class='user' action='evaluarproyectos.php?cod=$codigos' method='POST' enctype='multipart/form-data'>";							
								echo"<input type='submit' class='btn btn-primary' value='Regresar a evaluar'>";
							echo"</form>";
						}
						
						#<!-- Etapa 4 : Revisión del director DE -->
		
						if($decision=='DE'){
						$C3=intval($_POST["C3"]);
						
						$puntaje=$C3;
							
						$enlace = mysqli_connect("localhost","root","","base_va");
                   
						$sentencia="SELECT * FROM proyectos where Codigo_Proyecto='$cod';";

						$resultado=mysqli_query($enlace,$sentencia);
						$fila=mysqli_fetch_row($resultado);

						echo"<form class='user' action='ingresarev.php?cod=$cod' method='POST' enctype='multipart/form-data'>";
						echo" Nombre Proyecto: <input class='form-control' name='nombre' type='text' value='$fila[1]' readonly> <br><br>";
					    echo" Puntaje asignado: <input class='form-control' name='puntaje' type='text' value='$puntaje' readonly> <br><br>";
						echo" Resultado: <br> ";
						if( $puntaje==0){
							 echo"  <input class='form-control' name='proy' type='text' value='Se rechaza el proyecto en la Fase 4' readonly> <br><br>";
							  echo"  <input class='form-control' name='decision' type='hidden' value='Rechazado por DE' readonly> <br><br>";
							 echo" Motivo  de decisión:<br>";
							 echo" <textarea  class='form-control' name='motivo' rows='5' placeholder='Escribe aquí la descripción'></textarea>";
							 echo"<br><br>";
							 echo" Observaciones adicionales:<br>";
							 echo "<textarea  class='form-control' name='observaciones' rows='5' placeholder='Escribe aquí la descripción'></textarea>";
							 echo "<br><br>";
						}	
                        else{
							echo"  <input class='form-control' name='proy' type='text' value='El proyecto está apto para pasar a la fase 5' readonly> <br><br>";
							 echo"  <input class='form-control' name='decision' type='hidden' value='Aceptado por DE' readonly> <br><br>";
							 echo" Motivo  de decisión:<br>";
							 echo" <textarea  class='form-control' name='descripcion' rows='5' placeholder='Escribe aquí la descripción'></textarea>";
							 echo"<br><br>";
							 echo" Observaciones adicionales:<br>";
							 echo "<textarea  class='form-control' name='descripcion' rows='5' placeholder='Escribe aquí la descripción'></textarea>";
							 echo "<br><br>";							
							
						}	
							echo"<input type='submit' class='btn btn-primary' value='Ingresar evaluación'>";
							echo"</form>";		
							echo"<form class='user' action='evaluarproyectos.php?cod=$codigos' method='POST' enctype='multipart/form-data'>";							
								echo"<input type='submit' class='btn btn-primary' value='Regresar a evaluar'>";
							echo"</form>";	
						}
						#<!-- Etapa 5 : Revisión del Donante-->

						if($decision=='DONANTE'){
							$C3=intval($_POST["C3"]);
						
						$puntaje=$C3;
							
						$enlace = mysqli_connect("localhost","root","","base_va");
                   
						$sentencia="SELECT * FROM proyectos where Codigo_Proyecto='$cod';";

						$resultado=mysqli_query($enlace,$sentencia);
						$fila=mysqli_fetch_row($resultado);

						echo"<form class='user' action='ingresarev.php?cod=$cod' method='POST' enctype='multipart/form-data'>";
						echo" Nombre Proyecto: <input class='form-control' name='nombre' type='text' value='$fila[1]' readonly> <br><br>";
					    echo" Puntaje asignado: <input class='form-control' name='puntaje' type='text' value='$puntaje' readonly> <br><br>";
						echo" Resultado: <br> ";
						if( $puntaje==0){
							 echo"  <input class='form-control' name='proy' type='text' value='Se rechaza el proyecto en la Fase 5' readonly> <br><br>";
							  echo"  <input class='form-control' name='decision' type='hidden' value='Rechazado por Donante' readonly> <br><br>";
							 echo" Motivo  de decisión:<br>";
							 echo" <textarea  class='form-control' name='motivo' rows='5' placeholder='Escribe aquí la descripción'></textarea>";
							 echo"<br><br>";
							 echo" Observaciones adicionales:<br>";
							 echo "<textarea  class='form-control' name='observaciones' rows='5' placeholder='Escribe aquí la descripción'></textarea>";
							 echo "<br><br>";
						}	
                        else{
							echo"  <input class='form-control' name='proy' type='text' value='El proyecto será financiado por Vive Amazonas' readonly> <br><br>";
							 echo"  <input class='form-control' name='decision' type='hidden' value='Ganador' readonly> <br><br>";
							 echo" Motivo  de decisión:<br>";
							 echo" <textarea  class='form-control' name='descripcion' rows='5' placeholder='Escribe aquí la descripción'></textarea>";
							 echo"<br><br>";
							 echo" Observaciones adicionales:<br>";
							 echo "<textarea  class='form-control' name='descripcion' rows='5' placeholder='Escribe aquí la descripción'></textarea>";
							 echo "<br><br>";							
							
						}	
							echo"<input type='submit' class='btn btn-primary' value='Ingresar evaluación'>";
							echo"</form>";		
							echo"<form class='user' action='evaluarproyectos.php?cod=$codigos' method='POST' enctype='multipart/form-data'>";							
								echo"<input type='submit' class='btn btn-primary' value='Regresar a evaluar'>";
							echo"</form>";
						}

				echo"</div>";
			echo"</div>";
		echo"</div>";
			include("../inc/menubajo.php");
			 }
	        ?>
</html>
