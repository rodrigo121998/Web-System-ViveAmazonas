<html lang="en">
		<?php

		 session_start(); //inicio de sesi�n
						if (!isset($_SESSION["usuario"])){
							session_destroy();
							echo "<br><br> <font color='red'>Intento de acceso sin autorizaci�n!!!</font>";
							header("Location:../intranet.html");
							exit;
						}
			 else {
				 include("../inc/menuarriba.php");
				 $usuario=$_SESSION['usuario'];
			 /*$id_us= $_SESSION['id_us'];
			 $correo_us= $_SESSION['correo_us'];*/
					include("../inc/menu.php");
					$cod2=$_GET["cod"];
		 ?>
			<h1 class="h3 mb-2 text-gray-800">Relacion de Proyectos</h1>
			<p class="mb-4">En esta pagina se puede administrar los proyectos.</p>
			<script src="http://code.jquery.com/jquery-latest.min.js" type="text/javascript"></script>
			<link rel="stylesheet" href="../css/estilos.css"/>
			<script src="script.js"></script>
			<script>
				function alerta()
				{
					return confirm("�Esta seguro que desea eliminar este proyecto?");
				}
			</script>
			<div class="card shadow mb-4">
				<div class="card-header py-3">
				  <h6 class="m-0 font-weight-bold text-primary">Tabla de Proyectos</h6>
				</div>
				<div class="card-body">
					<div class="table-responsive">
					<?php
			echo"<form class='d-none d-sm-inline-block form-inline mr-auto ml-md-3 my-2 my-md-0 mw-100 navbar-search' action='CUS017.php?cod=$cod2' method='POST' enctype='multipart/form-data'>";
			?>
				<div class="input-group">
					<input type='text' class="form-control bg-light border-0 small" name='proyecto' placeholder='Buscar proyecto...'>
					<input type='submit' class="btn btn-primary" name='buscar' value="Buscar proyecto" ><br><br>
				</div>
			</form>
			<br><br>
			<?php
       
			$sentencia3= "SELECT a.id_usuario,a.cod_perfil FROM usuariosxperfil a,usuarios b  where b.id= a.id_usuario and b.usuario='$usuario' ;";
			$resultado3 = mysqli_query($enlace,$sentencia3);
			$contar2= mysqli_num_rows($resultado3);
            $registro2 = mysqli_fetch_row($resultado3);
			
			$sentencia4 ="SELECT b.Unidad FROM evaluadoresxconcurso a, evaluadores b WHERE b.codigo_evaluador=a.id_evaluador and a.id_concurso='$cod2' and b.usuario='$registro2[0]'";
			$resultado4= mysqli_query($enlace,$sentencia4);
			$contar4= mysqli_num_rows($resultado4); 
			$registro4 = mysqli_fetch_row($resultado4);
			
			#<!-- Etapa 1 : Oficial DIGE  -->

			
			if ($registro4[0]=='DIGE'){
				if (!isset($_POST["buscar"])){
						$sentencia2= "SELECT Codigo_Proyecto,Nombre_Proyecto,FechaEnvio,Estado_Proyecto FROM proyectos where Estado='A' and  (Estado_Proyecto ='Enviado' or  Estado_Proyecto ='En Revision') and Codigo_Concurso='$cod2';";
						$resultado2 = mysqli_query($enlace,$sentencia2);
						$contar= mysqli_num_rows($resultado2);
						
					   if ($contar==0){
					   echo  "No hay proyectos <br>";
					   }
					   else {

					   echo "<form action='../CUS004/CUS004.php' method= 'POST'>";
					   echo "<table class='table table-bordered' id='dataTable' width='100%' cellspacing='0'>";
					   echo "<thead>";
					   echo "	<tr>";
					   echo "		<td>Codigo Proyecto</td>";
					   echo "		<td>Nombre Proyecto</td>";
					   echo "		<td>Fecha env�o</td>";
					   echo "		<td>Opciones</td>";
					   echo "	</tr>";
						echo "</thead>";
					   echo "<tbody>";

					   for ($i=1; $i <= $contar; $i++){
						 $registro = mysqli_fetch_row($resultado2);
						$codigos=array($registro[0],$registro4[0]);
						$codigos = serialize($codigos);
						$codigos = urlencode($codigos);

						 echo "	<tr>";
						 echo "		<td>",$registro[0],"</td>";
						 echo "		<td>",$registro[1],"</td>";
						 echo "		<td>",$registro[2],"</td>";
						 echo "		<td> <a href='evaluarproyectos.php?cod2=$codigos' class='d-none d-sm-inline-block btn btn-sm btn-primary shadow-sm'>Evaluar</a> </td> ";
						 echo "	</tr>";

					   }
					   echo "</tbody>";
					   echo "</table>";

					   }
					   echo"  <input name='decision' type='hidden' value='$registro4[0]' readonly> <br><br>";

						 ?>
						<a href='../CUS004/CUS004.php' class='d-none d-sm-inline-block btn btn-sm btn-primary shadow-sm'>Regresar a relacion de concursos</a> </td>
					  </form>
				  <?php
						}
			 else {
						$proyecto = $_POST['proyecto'];
						echo"<form action='CUS017.php?cod=$cod2' method='POST' enctype='multipart/form-data'>";
						if ($proyecto==''){
							echo"No ha seleccionado ningun proyecto";
						}
						else {
						$sentencia2= "SELECT Codigo_Proyecto,Nombre_Proyecto,FechaEnvio,Estado_Proyecto FROM proyectos a where Estado='A' and (Estado_Proyecto='Enviado' or Estado_Proyecto='En Revision')  and Nombre_Proyecto like '%$proyecto%' and Codigo_Concurso='$cod2' ORDER BY FechaEnvio;";
						$resultado2 = mysqli_query($enlace,$sentencia2);
						$contar= mysqli_num_rows($resultado2);
					   if ($contar==0){
					   echo  "No hay proyectos con ese nombre<br>";
					   }
					   else {

					   echo "<form action='' method= 'POST'>";
					   echo "<table class='table table-bordered' id='dataTable' width='100%' cellspacing='0'>";
					   echo "<thead>";
					   echo "	<tr>";
					   echo "		<td>Codigo Proyecto</td>";
					   echo "		<td>Nombre Proyecto</td>";
					   echo "		<td>FechaEnvio</td>";
					   echo "		<td>Opciones</td>";
					   echo "	</tr>";
					   echo "</thead>";
					   echo "<tbody>";

					   
					   for ($i=1; $i <= $contar; $i++){
						 $registro = mysqli_fetch_row($resultado2);
						$codigos=array($registro[0],$registro4[0]);
						$codigos = serialize($codigos);
						$codigos = urlencode($codigos);

						 echo "	<tr>";
						 echo "		<td>",$registro[0],"</td>";
						 echo "		<td>",$registro[1],"</td>";
						 echo "		<td>",$registro[2],"</td>";
						 echo "		<td>  <a href='evaluarproyectos.php?cod2=$codigos' class='d-none d-sm-inline-block btn btn-sm btn-primary shadow-sm'>Evaluar</a> </td> ";
						 echo "	</tr>";
					   }
					   echo "</tbody>";
					   echo "</table>";
                       echo"  <input class='form-control' name='decision' type='hidden' value='$registro4[0]' readonly> <br><br>";
					   }
						}

						echo" <br><br>";
						echo"<input type='submit' class='btn btn-primary' value='Regresar a relacion de proyectos'>";
						echo"</form>";

			  }
			} 
			 
			#<!-- Etapa 2 : Representante CTI  --> 
			elseif ($registro4[0]=='CTI'){
				if (!isset($_POST["buscar"])){
						$sentencia2= "SELECT Codigo_Proyecto,Nombre_Proyecto,FechaEnvio,Estado_Proyecto FROM proyectos where Estado='A' and  (Estado_Proyecto ='Aprobado por DIGE') and Codigo_Concurso='$cod2';";
						$resultado2 = mysqli_query($enlace,$sentencia2);
						$contar= mysqli_num_rows($resultado2);
						
					   if ($contar==0){
					   echo  "No hay proyectos <br>";
					   }
					   else {

					   echo "<form action='../CUS004/CUS004.php' method= 'POST'>";
					   echo "<table class='table table-bordered' id='dataTable' width='100%' cellspacing='0'>";
					   echo "<thead>";
					   echo "	<tr>";
					   echo "		<td>Codigo Proyecto</td>";
					   echo "		<td>Nombre Proyecto</td>";
					   echo "		<td>Fecha env�o</td>";
					   echo "		<td>Opciones</td>";
					   echo "	</tr>";
						echo "</thead>";
					   echo "<tbody>";
					   for ($i=1; $i <= $contar; $i++){
						 $registro = mysqli_fetch_row($resultado2);
						$codigos=array($registro[0],$registro4[0]);
						$codigos = serialize($codigos);
						$codigos = urlencode($codigos);

						 echo "	<tr>";
						 echo "		<td>",$registro[0],"</td>";
						 echo "		<td>",$registro[1],"</td>";
						 echo "		<td>",$registro[2],"</td>";
						 echo "		<td> <a href='evaluarproyectos.php?cod2=$codigos class='d-none d-sm-inline-block btn btn-sm btn-primary shadow-sm'>Evaluar</a> </td> ";
						 echo "	</tr>";

					   }
					   echo "</tbody>";
					   echo "</table>";
					    echo"  <input class='form-control' name='decision' type='hidden' value='$registro4[0]' readonly> <br><br>";

					   }

						 ?>
						<a href='../CUS004/CUS004.php' class='d-none d-sm-inline-block btn btn-sm btn-primary shadow-sm'>Regresar a relacion de concursos</a> </td>
				  <?php
						}
			 else {
						$proyecto = $_POST['proyecto'];
						echo"<form action='CUS017.php?cod=$cod2' enctype='multipart/form-data'>";
						if ($proyecto==''){
							echo"No ha seleccionado ningun proyecto";
						}
						else {
						$sentencia2= "SELECT Codigo_Proyecto,Nombre_Proyecto,FechaEnvio,Estado_Proyecto FROM proyectos a where Estado='A' and (Estado_Proyecto ='Aprobado por DIGE')  and Nombre_Proyecto like '%$proyecto%' and Codigo_Concurso='$cod2' ORDER BY FechaEnvio;";
						$resultado2 = mysqli_query($enlace,$sentencia2);
						$contar= mysqli_num_rows($resultado2);
					   if ($contar==0){
					   echo  "No hay proyectos con ese nombre<br>";
					   }
					   else {

					   echo "<form action='' method= 'POST'>";
					   echo "<table class='table table-bordered' id='dataTable' width='100%' cellspacing='0'>";
					   echo "<thead>";
					   echo "	<tr>";
					   echo "		<td>Codigo Proyecto</td>";
					   echo "		<td>Nombre Proyecto</td>";
					   echo "		<td>FechaEnvio</td>";
					   echo "		<td>Opciones</td>";
					   echo "	</tr>";
					   echo "</thead>";
					   echo "<tbody>";

					   for ($i=1; $i <= $contar; $i++){
						 $registro = mysqli_fetch_row($resultado2);
						$codigos=array($registro[0],$registro4[0]);
						$codigos = serialize($codigos);
						$codigos = urlencode($codigos);

						 echo "	<tr>";
						 echo "		<td>",$registro[0],"</td>";
						 echo "		<td>",$registro[1],"</td>";
						 echo "		<td>",$registro[2],"</td>";
						 echo "		<td>  <a href='evaluarproyectos.php?cod2=$codigos class='d-none d-sm-inline-block btn btn-sm btn-primary shadow-sm'>Evaluar</a> </td> ";
						 echo "	</tr>";
					   }
					   echo "</tbody>";
					   echo "</table>";
					    echo"  <input class='form-control' name='decision' type='hidden' value='$registro4[0]' readonly> <br><br>";

					   }
						}

						echo" <br><br>";
						echo"<input type='submit' class='btn btn-primary' value='Regresar a relacion de proyectos'>";
						echo"</form>";

			  }
			} 			 
			 
			#<!-- Etapa 3 : Representante CTE  --> 
			elseif ($registro4[0]=='CTE'){
				if (!isset($_POST["buscar"])){
						$sentencia2= "SELECT Codigo_Proyecto,Nombre_Proyecto,FechaEnvio,Estado_Proyecto FROM proyectos where Estado='A' and  (Estado_Proyecto ='Aprobado por CTI') and Codigo_Concurso='$cod2';";
						$resultado2 = mysqli_query($enlace,$sentencia2);
						$contar= mysqli_num_rows($resultado2);
						
					   if ($contar==0){
					   echo  "No hay proyectos <br>";
					   }
					   else {

					   echo "<form action='../CUS004/CUS004.php' method= 'POST'>";
					   echo "<table class='table table-bordered' id='dataTable' width='100%' cellspacing='0'>";
					   echo "<thead>";
					   echo "	<tr>";
					   echo "		<td>Codigo Proyecto</td>";
					   echo "		<td>Nombre Proyecto</td>";
					   echo "		<td>Fecha env�o</td>";
					   echo "		<td>Opciones</td>";
					   echo "	</tr>";
						echo "</thead>";
					   echo "<tbody>";
					   for ($i=1; $i <= $contar; $i++){
						 $registro = mysqli_fetch_row($resultado2);
						$codigos=array($registro[0],$registro4[0]);
						$codigos = serialize($codigos);
						$codigos = urlencode($codigos);

						 echo "	<tr>";
						 echo "		<td>",$registro[0],"</td>";
						 echo "		<td>",$registro[1],"</td>";
						 echo "		<td>",$registro[2],"</td>";
						 echo "		<td> <a href='evaluarproyectos.php?cod2=$codigos' class='d-none d-sm-inline-block btn btn-sm btn-primary shadow-sm'>Evaluar</a> </td> ";
						 echo "	</tr>";

					   }
					   echo "</tbody>";
					   echo "</table>";
					    echo"  <input class='form-control' name='decision' type='hidden' value='$registro4[0]' readonly> <br><br>";

					   }

						 ?>
						<a href='../CUS004/CUS004.php' class='d-none d-sm-inline-block btn btn-sm btn-primary shadow-sm'>Regresar a relacion de concursos</a> </td>
					  </form>
				  <?php
						}
			 else {
						$proyecto = $_POST['proyecto'];
						echo"<form action='CUS017.php?cod=$cod2' enctype='multipart/form-data'>";
						if ($proyecto==''){
							echo"No ha seleccionado ningun proyecto";
						}
						else {
						$sentencia2= "SELECT Codigo_Proyecto,Nombre_Proyecto,FechaEnvio,Estado_Proyecto FROM proyectos a where Estado='A' and (Estado_Proyecto ='Aprobado por CTI')  and Nombre_Proyecto like '%$proyecto%' and Codigo_Concurso='$cod2' ORDER BY FechaEnvio;";
						$resultado2 = mysqli_query($enlace,$sentencia2);
						$contar= mysqli_num_rows($resultado2);
					   if ($contar==0){
					   echo  "No hay proyectos con ese nombre<br>";
					   }
					   else {

					   echo "<form action='' method= 'POST'>";
					   echo "<table class='table table-bordered' id='dataTable' width='100%' cellspacing='0'>";
					   echo "<thead>";
					   echo "	<tr>";
					   echo "		<td>Codigo Proyecto</td>";
					   echo "		<td>Nombre Proyecto</td>";
					   echo "		<td>FechaEnvio</td>";
					   echo "		<td>Opciones</td>";
					   echo "	</tr>";
					   echo "</thead>";
					   echo "<tbody>";

					   for ($i=1; $i <= $contar; $i++){
						 $registro = mysqli_fetch_row($resultado2);
						$codigos=array($registro[0],$registro4[0]);
						$codigos = serialize($codigos);
						$codigos = urlencode($codigos);

						 echo "	<tr>";
						 echo "		<td>",$registro[0],"</td>";
						 echo "		<td>",$registro[1],"</td>";
						 echo "		<td>",$registro[2],"</td>";
						 echo "		<td>  <a href='evaluarproyectos.php?cod2=$codigos' class='d-none d-sm-inline-block btn btn-sm btn-primary shadow-sm'>Evaluar</a> </td> ";
						 echo "	</tr>";
					   }
					   echo "</tbody>";
					   echo "</table>";
					    echo"  <input class='form-control' name='decision' type='hidden' value='$registro4[0]' readonly> <br><br>";

					   }
						}

						echo" <br><br>";
						echo"<input type='submit' class='btn btn-primary' value='Regresar a relacion de proyectos'>";
						echo"</form>";

			  }
			} 


			#<!-- Etapa 4 : Director DE  --> 
			elseif ($registro4[0]=='DE'){
				if (!isset($_POST["buscar"])){
						$sentencia2= "SELECT Codigo_Proyecto,Nombre_Proyecto,FechaEnvio,Estado_Proyecto FROM proyectos where Estado='A' and  (Estado_Proyecto ='Aprobado por CTE') and Codigo_Concurso='$cod2';";
						$resultado2 = mysqli_query($enlace,$sentencia2);
						$contar= mysqli_num_rows($resultado2);
						
					   if ($contar==0){
					   echo  "No hay proyectos <br>";
					   }
					   else {

					   echo "<form action='../CUS004/CUS004.php' method= 'POST'>";
					   echo "<table class='table table-bordered' id='dataTable' width='100%' cellspacing='0'>";
					   echo "<thead>";
					   echo "	<tr>";
					   echo "		<td>Codigo Proyecto</td>";
					   echo "		<td>Nombre Proyecto</td>";
					   echo "		<td>Fecha env�o</td>";
					   echo "		<td>Opciones</td>";
					   echo "	</tr>";
						echo "</thead>";
					   echo "<tbody>";
					   for ($i=1; $i <= $contar; $i++){
						 $registro = mysqli_fetch_row($resultado2);
						$codigos=array($registro[0],$registro4[0]);
						$codigos = serialize($codigos);
						$codigos = urlencode($codigos);

						 echo "	<tr>";
						 echo "		<td>",$registro[0],"</td>";
						 echo "		<td>",$registro[1],"</td>";
						 echo "		<td>",$registro[2],"</td>";
						 echo "		<td> <a href='evaluarproyectos.php?cod2=$codigos' class='d-none d-sm-inline-block btn btn-sm btn-primary shadow-sm'>Evaluar</a> </td> ";
						 echo "	</tr>";

					   }
					   echo "</tbody>";
					   echo "</table>";
					    echo"  <input class='form-control' name='decision' type='hidden' value='$registro4[0]' readonly> <br><br>";

					   }

						 ?>
						<a href='../CUS004/CUS004.php' class='d-none d-sm-inline-block btn btn-sm btn-primary shadow-sm'>Regresar a relacion de concursos</a> </td>
					  </form>
				  <?php
						}
			 else {
						$proyecto = $_POST['proyecto'];
						echo"<form action='CUS017.php?cod=$cod2' enctype='multipart/form-data'>";
						if ($proyecto==''){
							echo"No ha seleccionado ningun proyecto";
						}
						else {
						$sentencia2= "SELECT Codigo_Proyecto,Nombre_Proyecto,FechaEnvio,Estado_Proyecto FROM proyectos a where Estado='A' and  (Estado_Proyecto ='Aprobado por CTE')  and Nombre_Proyecto like '%$proyecto%' and Codigo_Concurso='$cod2' ORDER BY FechaEnvio;";
						$resultado2 = mysqli_query($enlace,$sentencia2);
						$contar= mysqli_num_rows($resultado2);
					   if ($contar==0){
					   echo  "No hay proyectos con ese nombre<br>";
					   }
					   else {

					   echo "<form action='' method= 'POST'>";
					   echo "<table class='table table-bordered' id='dataTable' width='100%' cellspacing='0'>";
					   echo "<thead>";
					   echo "	<tr>";
					   echo "		<td>Codigo Proyecto</td>";
					   echo "		<td>Nombre Proyecto</td>";
					   echo "		<td>FechaEnvio</td>";
					   echo "		<td>Opciones</td>";
					   echo "	</tr>";
					   echo "</thead>";
					   echo "<tbody>";

					   for ($i=1; $i <= $contar; $i++){
						 $registro = mysqli_fetch_row($resultado2);
						$codigos=array($registro[0],$registro4[0]);
						$codigos = serialize($codigos);
						$codigos = urlencode($codigos);
						
						

						 echo "	<tr>";
						 echo "		<td>",$registro[0],"</td>";
						 echo "		<td>",$registro[1],"</td>";
						 echo "		<td>",$registro[2],"</td>";
						 echo "		<td>  <a href='evaluarproyectos.php?cod2=$codigos' class='d-none d-sm-inline-block btn btn-sm btn-primary shadow-sm'>Evaluar</a> </td> ";
						 echo "	</tr>";
					   }
					   echo "</tbody>";
					   echo "</table>";
					    echo"  <input class='form-control' name='decision' type='hidden' value='$registro4[0]' readonly> <br><br>";

					   }
						}

						echo" <br><br>";
						echo"<input type='submit' class='btn btn-primary' value='Regresar a relacion de proyectos'>";
						echo"</form>";

			  }
			} 			
			 
			#<!-- Etapa 5 : Donante  --> 
			elseif ($registro4[0]=='DONANTE'){
				if (!isset($_POST["buscar"])){
						$sentencia2= "SELECT Codigo_Proyecto,Nombre_Proyecto,FechaEnvio,Estado_Proyecto FROM proyectos where Estado='A' and (Estado_Proyecto ='Aprobado por DE') and Codigo_Concurso='$cod2';";
						$resultado2 = mysqli_query($enlace,$sentencia2);
						$contar= mysqli_num_rows($resultado2);
						
					   if ($contar==0){
					   echo  "No hay proyectos <br>";
					   }
					   else {

					   echo "<form action='../CUS004/CUS004.php' method= 'POST'>";
					   echo "<table class='table table-bordered' id='dataTable' width='100%' cellspacing='0'>";
					   echo "<thead>";
					   echo "	<tr>";
					   echo "		<td>Codigo Proyecto</td>";
					   echo "		<td>Nombre Proyecto</td>";
					   echo "		<td>Fecha env�o</td>";
					   echo "		<td>Opciones</td>";
					   echo "	</tr>";
						echo "</thead>";
					   echo "<tbody>";
					   for ($i=1; $i <= $contar; $i++){
						 $registro = mysqli_fetch_row($resultado2);
						$codigos=array($registro[0],$registro4[0]);
						$codigos = serialize($codigos);
						$codigos = urlencode($codigos);

						 echo "	<tr>";
						 echo "		<td>",$registro[0],"</td>";
						 echo "		<td>",$registro[1],"</td>";
						 echo "		<td>",$registro[2],"</td>";
						 echo "		<td> <a href='evaluarproyectos.php?cod2=$codigos' class='d-none d-sm-inline-block btn btn-sm btn-primary shadow-sm'>Evaluar</a> </td> ";
						 echo "	</tr>";

					   }
					   echo "</tbody>";
					   echo "</table>";
					    echo"  <input class='form-control' name='decision' type='hidden' value='$registro4[0]' readonly> <br><br>";

					   }

						 ?>
						<a href='../CUS004/CUS004.php' class='d-none d-sm-inline-block btn btn-sm btn-primary shadow-sm'>Regresar a relacion de concursos</a> </td>
					  </form>
				  <?php
						}
			 else {
						$proyecto = $_POST['proyecto'];
						echo"<form action='CUS017.php?cod=$cod2' enctype='multipart/form-data'>";
						if ($proyecto==''){
							echo"No ha seleccionado ningun proyecto";
						}
						else {
						$sentencia2= "SELECT Codigo_Proyecto,Nombre_Proyecto,FechaEnvio,Estado_Proyecto FROM proyectos a where Estado='A' and  (Estado_Proyecto ='Aprobado por DE')  and Nombre_Proyecto like '%$proyecto%' and Codigo_Concurso='$cod2' ORDER BY FechaEnvio;";
						$resultado2 = mysqli_query($enlace,$sentencia2);
						$contar= mysqli_num_rows($resultado2);
					   if ($contar==0){
					   echo  "No hay proyectos con ese nombre<br>";
					   }
					   else {

					   echo "<form action='' method= 'POST'>";
					   echo "<table class='table table-bordered' id='dataTable' width='100%' cellspacing='0'>";
					   echo "<thead>";
					   echo "	<tr>";
					   echo "		<td>Codigo Proyecto</td>";
					   echo "		<td>Nombre Proyecto</td>";
					   echo "		<td>FechaEnvio</td>";
					   echo "		<td>Opciones</td>";
					   echo "	</tr>";
					   echo "</thead>";
					   echo "<tbody>";

					   for ($i=1; $i <= $contar; $i++){
						 $registro = mysqli_fetch_row($resultado2);
						$codigos=array($registro[0],$registro4[0]);
						$codigos = serialize($codigos);
						$codigos = urlencode($codigos);

						 echo "	<tr>";
						 echo "		<td>",$registro[0],"</td>";
						 echo "		<td>",$registro[1],"</td>";
						 echo "		<td>",$registro[2],"</td>";
						 echo "		<td>  <a href='evaluarproyectos.php?cod2=$codigos' class='d-none d-sm-inline-block btn btn-sm btn-primary shadow-sm'>Evaluar</a> </td> ";
						 echo "	</tr>";
					   }
					   echo "</tbody>";
					   echo "</table>";
					    echo"  <input class='form-control' name='decision' type='hidden' value='$registro4[0]' readonly> <br><br>";

					   }
						}

						echo" <br><br>";
						echo"<input type='submit' class='btn btn-primary' value='Regresar a relacion de proyectos'>";
						echo"</form>";

			  }
			} 			 
			 
	#FINALLLLLLLLLLLLLLLLLL
	
			 
				echo"</div>";
			echo"</div>";
		echo"</div>";
			 include("../inc/menubajo.php");
			 }
	  ?>
</html>