<html>
	<?php
			session_start(); //inicio de sesión
			if (!isset($_SESSION["usuario"])){
				session_destroy();
				echo "<br><br> <font color='red'>Intento de acceso sin autorización!!!</font>";
				header("Location:../intranet.html");
				exit;
			}
			 else {
				 include("../inc/menuarriba.php");
			 /*$id_us= $_SESSION['id_us'];
			 $correo_us= $_SESSION['correo_us'];*/
				include("../inc/menu.php");
			$codigos = unserialize($_GET['cod2']);
			list($codi,$decision)=$codigos;
			   
	 ?>
			<h1 class="h3 mb-2 text-gray-800">Evaluar proyectos</h1>
			<p class="mb-4">En esta página se puede evaluar los proyectos asociados a un concurso.</p>
			<div class="card shadow mb-4">
				<div class="card-header py-3">
				  <h6 class="m-0 font-weight-bold text-primary">Datos del Proyecto</h6>
				</div>
				<div class="card-body">
					<div class="table-responsive">
			<?php

            $enlace = mysqli_connect("localhost","root","","base_va");

            $sentencia="SELECT * FROM proyectos where Codigo_Proyecto='$codi';";

            $resultado=mysqli_query($enlace,$sentencia);
            $fila=mysqli_fetch_row($resultado);
			$cod=array($codi,$decision);
			$cod = serialize($cod);
			$cod = urlencode($cod);
            echo"<form class='user' action='resultadoev.php?cod=$cod' method='POST' enctype='multipart/form-data'>";
            echo" Nombre Proyecto: <input class='form-control' name='proy' type='text' value='$fila[1]' readonly> <br><br>";
            echo" Tipo de proyecto: <input class='form-control' name='tipoproy' type='text' value='$fila[2]' readonly> <br><br>";
            echo" Expediente: ";
			if ($fila[3]<>NULL){
			echo"<a href='descargar_exp.php?cod=$codi' class='d-none d-sm-inline-block btn btn-sm btn-primary shadow-sm'>Expediente</a><br><br>";
			} else {
				echo "No hay expediente subido<br><br>";
			}
            echo" Consolidado de propuestas: ";
			if ($fila[5]<>NULL){
			echo"<a href='descargar_consoli.php?cod=$codi' class='d-none d-sm-inline-block btn btn-sm btn-primary shadow-sm'>Consolidado de propuestas</a><br><br>";
			} else {
				echo "No hay consolidado subido<br>";
			}
            echo" <br>";         
            ?>
					</div>
				</div>
			</div>
			<?php
			#<!-- Etapa 1 : Oficial DIGE  -->
			
			if($decision=='DIGE'){
					echo " <div class='card shadow mb-4'>";
					echo"	<div class='card-header py-3'>";
					echo" <h6 class='m-0 font-weight-bold text-primary'>Evaluación del Proyecto: Fase 1</h6>";
					echo"	</div>";
					echo"	<div class='card-body'>";
					echo" Estado del proyecto: <input class='form-control' name='proy' type='text' value='$fila[4]' readonly> <br><br>";
				   echo "<table class='table table-bordered' id='dataTable' width='100%' cellspacing='0'>";
				   echo "<thead>";
				   echo "	<tr>";
				   echo "		<td>Num</td>";
				   echo "		<td>Criterio</td>";
				   echo"  <td> Cumple</td>";
				   echo"  <td> No Cumple</td>";
				   echo "	</tr>";
				   echo "</thead>";
				   echo "<tbody>";
				   echo "	<tr>";
				   echo " <td> 1 </td>";
				   echo "		<td>Relacionado con el objetivo de la convocatoria</td>";
				   echo"  <td> <input type='radio'  name= 'C1' value='1' required></td>";
				   echo"  <td> <input type='radio'  name= 'C1' value='0' required></td>";
				   echo "	</tr>";
				   echo "	<tr>";
				   echo " <td> 2 </td>";
				   echo "		<td>Inscripción en el registro nacional de registros públicos</td>";
				   echo"  <td> <input type='radio'  name= 'C2' value='1' required></td>";
				   echo"  <td> <input type='radio'  name= 'C2' value='0' required></td>";
				   echo "	</tr>";
				   echo "	<tr>";
				   echo " <td> 3 </td>";
				   echo "		<td>Cuenta con representante legal inscrito</td>";
				   echo"  <td> <input type='radio'  name= 'C3' value='1' required></td>";
				   echo"  <td> <input type='radio'  name= 'C3' value='0' required></td>";
				   echo "	</tr>";
				   echo "	<tr>";
				   echo " <td> 4 </td>";
				   echo "		<td>¿Está aprobado por su representante legal?</td>";
				   echo"  <td> <input type='radio'  name= 'C4' value='1' required></td>";
				   echo"  <td> <input type='radio'  name= 'C4' value='0' required></td>";
				   echo "	</tr>";
				   echo " <td> 5 </td>";	   
				   echo "		<td>¿Cuenta con experiencia en gestión de proyectos?</td>";
				   echo"  <td> <input type='radio'  name= 'C5' value='1' required></td>";
				   echo"  <td> <input type='radio'  name= 'C5' value='0' required></td>";
				   echo "	</tr>";	
				   echo " <td> 6 </td>";		   
				   echo "		<td>¿Cuenta con los documentos de expediente requeridos? </td>";
				   echo"  <td> <input type='radio'  name= 'C6' value='1' required></td>";
				   echo"  <td> <input type='radio'  name= 'C6' value='0' required></td>";
				   echo "	</tr>";	
				   echo " <td> 7 </td>";
				   echo "		<td>¿Ha tenido buen desempeño en proyectos pasados?</td>";
				   echo"  <td> <input type='radio'  name= 'C7' value='1' required></td>";
				   echo"  <td> <input type='radio'  name= 'C7' value='0' required></td>";
				   echo "	</tr>";
				   echo " <td> 8 </td>";
				   echo "		<td>¿Está registrada como deudora por la SBS?</td>";
				   echo"  <td> <input type='radio'  name= 'C8' value='1' required></td>";
				   echo"  <td> <input type='radio'  name= 'C8' value='0' required></td>";
				   echo "	</tr>";	
				   echo " <td> 9 </td>";		   
				   echo "		<td>¿Cuenta con el apoyo necesario para ejecutar su proyecto?</td>";
				   echo"  <td> <input type='radio'  name= 'C9' value='1' required></td>";
				   echo"  <td> <input type='radio'  name= 'C9' value='0' required></td>";
				   echo "	</tr>";
				   
				   echo "</tbody>";
				   echo "</table>";
				   echo"<div class='d-sm-flex align-items-center justify-content-between mb-4'>";
				   echo "<input type='submit' value='Siguiente' name='Enviar' class='d-none d-sm-inline-block btn btn-sm btn-primary shadow-sm'>";
					echo"<a href='CUS017.php?cod=$fila[7]' class='d-none d-sm-inline-block btn btn-sm btn-primary shadow-sm'>Regresar a evaluar concurso</a>";
					echo"</div>";
					echo" </form>";
					echo"	 </div>";
					echo"</div>";
			}		
			#<!-- Etapa 2 : Representante CTI  -->
			if($decision=='CTI'){
					echo " <div class='card shadow mb-4'>";
					echo"	<div class='card-header py-3'>";
					echo" <h6 class='m-0 font-weight-bold text-primary'>Evaluación del Proyecto: Fase 2</h6>";
					echo"	</div>";
					echo"	<div class='card-body'>";			
						echo" Estado del proyecto: <input class='form-control' name='proy' type='text' value='$fila[4]' readonly> <br><br>";
					   echo "<table class='table table-bordered' id='dataTable' width='100%' cellspacing='0'>";
					   echo "<thead>";
					   echo "	<tr>";
					   echo "		<td>Num</td>";
					   echo "		<td>Criterio</td>";
					   echo"  <td> Puntaje</td>";
					   echo "	</tr>";
					   echo "</thead>";
					   echo "<tbody>";
					   echo "	<tr>";
					   echo " <td> 1 </td>";
					   echo "		<td>Calidad en el contenido de los expedientes</td>";
					   echo " <td> <input type='number' name='puntaje1' value='puntaje1' min='0' max='20' step='1' /> </td>";
					   echo "	</tr>";
					   echo "	<tr>";
					   echo " <td> 2 </td>";
					   echo "		<td>Calidad de las propuestas del proyecto</td>";
					   echo " <td> <input type='number' name='puntaje2' value='puntaje2' min='0' max='20' step='1' /> </td>";
					   echo "	</tr>";
					   echo "	<tr>";
					   echo " <td> 3 </td>";
					   echo "		<td>Nivel de cumplimiento de estándares del proponente</td>";
					   echo " <td> <input type='number' name='puntaje3' value='puntaje3' min='0' max='20' step='1' /> </td>";
					   echo "	</tr>";
					   echo "	<tr>";
					   echo " <td> 4 </td>";
					   echo "		<td>Nivel de cumplimiento de políticas ambientales</td>";
					   echo " <td> <input type='number' name='puntaje4' value='puntaje4' min='0' max='20' step='1' /> </td>";
					   echo "	</tr>";
					   echo "	<tr>";
					   echo " <td> 5 </td>";
					   echo "		<td>Nivel de cumplimiento de políticas sociales y de género </td>";
					   echo " <td> <input type='number' name='puntaje5' value='puntaje5' min='0' max='20' step='1' /> </td>";
					   echo "	</tr>";
					   
					   
					   echo "</tbody>";
					   echo "</table>";
					   echo"<div class='d-sm-flex align-items-center justify-content-between mb-4'>";
						echo "<input type='submit' value='Siguiente' name='Siguiente' class='d-none d-sm-inline-block btn btn-sm btn-primary shadow-sm'>";
						echo"<a href='CUS017.php?cod=$fila[7]' class='d-none d-sm-inline-block btn btn-sm btn-primary shadow-sm'>Regresar a evaluar concurso</a>";
					echo"</div>";
						echo" </form>";
					echo"	 </div>";
					echo"</div>";
					
			}		
			#<!-- Etapa 3 : Representante CTE  -->

			if($decision=='CTE'){
					echo " <div class='card shadow mb-4'>";
					echo"	<div class='card-header py-3'>";
					echo" <h6 class='m-0 font-weight-bold text-primary'>Evaluación del Proyecto: Fase 3</h6>";
					echo"	</div>";
					echo"	<div class='card-body'>";		

					echo" Estado del proyecto: <input class='form-control' name='proy' type='text' value='$fila[4]' readonly> <br><br>";
					echo "<table class='table table-bordered' id='dataTable' width='100%' cellspacing='0'>";
					echo "<thead>";
					echo "	<tr>";
					echo "		<td>Num</td>";
					echo "		<td>Criterio</td>";
					echo"  <td> Puntaje</td>";
					echo "	</tr>";
					echo "</thead>";
					echo "<tbody>";
					echo "	<tr>";
					echo " <td> 1 </td>";
					echo "		<td>Alineación de las propuestas a los fines del concurso</td>";
					echo " <td> <input type='number' name='puntaje1' value='puntaje1' min='0' max='20' step='1' /> </td>";
					echo "	</tr>";
					echo "	<tr>";
					echo " <td> 2 </td>";
					echo "		<td>Nivel de viabilidad de las propuestas</td>";
					echo " <td> <input type='number' name='puntaje2' value='puntaje2' min='0' max='20' step='1' /> </td>";
					echo "	</tr>";
					echo "	<tr>";
					echo " <td> 3 </td>";
					echo "		<td>Beneficios otorgados a la Amazonía a raíz de las propuestas del proyecto</td>";
					echo " <td> <input type='number' name='puntaje3' value='puntaje3' min='0' max='20' step='1' /> </td>";
					echo "	</tr>";
					echo "	<tr>";
					echo " <td> 4 </td>";
					echo "		<td>Nivel de innovación de las propuestas</td>";
					echo " <td> <input type='number' name='puntaje4' value='puntaje4' min='0' max='20' step='1' /> </td>";
					echo "	</tr>";
					echo "	<tr>";
					echo " <td> 5 </td>";
					echo "		<td>Nivel de sostenibilidad del proyecto </td>";
					echo " <td> <input type='number' name='puntaje5' value='puntaje5' min='0' max='20' step='1' /> </td>";
					echo "	</tr>";


					echo "</tbody>";
					echo "</table>";
					echo"<div class='d-sm-flex align-items-center justify-content-between mb-4'>";
					echo "<input type='submit' value='Siguiente' name='Enviar' class='d-none d-sm-inline-block btn btn-sm btn-primary shadow-sm'>";
					echo"<a href='CUS017.php?cod=$fila[7]' class='d-none d-sm-inline-block btn btn-sm btn-primary shadow-sm'>Regresar a evaluar concurso</a>";
					echo"</div>";
					echo" </form>";
					echo"	 </div>";
					echo"</div>";
			}			
					
		#<!-- Etapa 4 : Revisión del director DE -->
		
			if($decision=='DE'){
					echo " <div class='card shadow mb-4'>";
					echo"	<div class='card-header py-3'>";
					echo" <h6 class='m-0 font-weight-bold text-primary'>Evaluación del Proyecto: Fase 4</h6>";
					echo"	</div>";
					echo"	<div class='card-body'>";	
					
					echo" Estado del proyecto: <input class='form-control' name='proy' type='text' value='$fila[4]' readonly> <br><br>";
				   echo "<table class='table table-bordered' id='dataTable' width='100%' cellspacing='0'>";
				   echo "<thead>";
				   echo "	<tr>";
				   echo "		<td>Num</td>";
				   echo "		<td>Criterio</td>";
				   echo"  <td>Conforme</td>";
				   echo"  <td>No Conforme</td>";
				   echo "	</tr>";
				   echo "</thead>";
				   echo "<tbody>";
				   echo "	<tr>";
				   echo " <td> 1 </td>";
				   echo "		<td>¿Es conforme con las evaluaciones previas?</td>";
				   echo"  <td> <input type='radio'  name= 'C3' value='1' required></td>";
				   echo"  <td> <input type='radio'  name= 'C3' value='0' required></td>";
				   echo "	</tr>";
				   echo "</tbody>";
				   echo "</table>";
				   echo"<div class='d-sm-flex align-items-center justify-content-between mb-4'>";
				   echo "<input type='submit' value='Siguiente' name='Siguiente' class='d-none d-sm-inline-block btn btn-sm btn-primary shadow-sm'>";
					echo"<a href='CUS017.php?cod=$fila[7]' class='d-none d-sm-inline-block btn btn-sm btn-primary shadow-sm'>Regresar a evaluar concurso</a>";
					echo"</div>";
					echo" </form>";
					echo"	 </div>";
					echo"</div>";	

			}
			
		#<!-- Etapa 5 : Revisión del Donante-->

			if($decision=='DONANTE'){
					echo " <div class='card shadow mb-4'>";
					echo"	<div class='card-header py-3'>";
					echo" <h6 class='m-0 font-weight-bold text-primary'>Evaluación del Proyecto: Fase 5</h6>";
					echo"	</div>";
					echo"	<div class='card-body'>";		
		
					echo" Estado del proyecto: <input class='form-control' name='proy' type='text' value='$fila[4]' readonly> <br><br>";
					echo "<table class='table table-bordered' id='dataTable' width='100%' cellspacing='0'>";
					echo "<thead>";
					echo "	<tr>";
					echo "		<td>Num</td>";
					echo "		<td>Criterio</td>";
					echo"  <td>Conforme</td>";
					echo"  <td>No Conforme</td>";
					echo "	</tr>";
					echo "</thead>";
					echo "<tbody>";
					echo "	<tr>";
					echo " <td> 1 </td>";
					echo "		<td>¿Es conforme el aporte financiero al proyecto?</td>";
					echo"  <td> <input type='radio'  name= 'C3' value='1' required></td>";
					echo"  <td> <input type='radio'  name= 'C3' value='0' required></td>";
					echo "	</tr>";
					echo "</tbody>";
					echo "</table>";
					echo"<div class='d-sm-flex align-items-center justify-content-between mb-4'>";
					echo"<a href='CUS017.php?cod=$fila[7]' class='d-none d-sm-inline-block btn btn-sm btn-primary shadow-sm'>Regresar a evaluar concurso</a>";
					echo"</div>";
					echo "<input type='submit' value='Siguiente' name='Siguiente' class='d-none d-sm-inline-block btn btn-sm btn-primary shadow-sm'>";
					echo" </form>";
					echo"	 </div>";
					echo"</div>";	

			}
			
#FINNNNNNNNNNN			
			
			
			include("../inc/menubajo.php");
			 }
	  ?>
</html>
