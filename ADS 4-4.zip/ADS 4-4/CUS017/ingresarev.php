<html>
	<head>
	</head>

	<body>
		<?php
		session_start(); //inicio de sesión
					if (!isset($_SESSION["usuario"])){
						session_destroy();
						echo "<br><br> <font color='red'>Intento de acceso sin autorización!!!</font>";
						header("Location:../intranet.html");
						exit;
					}
					$enlace = mysqli_connect("localhost","root","","base_va");
					$cod=$_GET["cod"];
					$usuario= $_SESSION['usuario'];
					$sentencia2="select id_evaluador,Unidad from (select codigo_evaluador,b.Unidad from 
					(select id from usuarios where usuario='$usuario') a, evaluadores b where a.id=b.usuario) c, 
					(select b.id_evaluador from proyectos a, evaluadoresxconcurso b where a.Codigo_Proyecto='$cod' and a.Codigo_Concurso=b.id_concurso) d 
					where c.codigo_evaluador=d.id_evaluador;";
					$resultado2 = mysqli_query($enlace,$sentencia2);
					$registro = mysqli_fetch_row($resultado2);					
					
					
			$puntaje= $_POST["puntaje"];
			$nombre_proy = $_POST["nombre"];
			$evaluador = $registro[0];
			$decision = $_POST["decision"];
			if ($registro[1]=='DIGE'){
			$tipo_evaluacion='Fase 1';
			if ($decision=='Aceptado por DIGE'){
			$sentencia3="update proyectos set Estado_Proyecto='Aprobado por DIGE' where Codigo_Proyecto='$cod';";
			}
			else{
			$sentencia3="update proyectos set Estado_Proyecto='Desaprobado por DIGE' where Codigo_Proyecto='$cod';";
			}			
			$resultado3=mysqli_query($enlace,$sentencia3);
			}
			elseif ($registro[1]=='CTI') {
			$tipo_evaluacion='Fase 2';
			if ($decision=='Aceptado por CTI'){
			$sentencia3="update proyectos set Estado_Proyecto='Aprobado por CTI' where Codigo_Proyecto='$cod';";
			}
			else{
			$sentencia3="update proyectos set Estado_Proyecto='Desaprobado por CTI' where Codigo_Proyecto='$cod';";
			}			
			$resultado3=mysqli_query($enlace,$sentencia3);
			}
			elseif ($registro[1]=='CTE') {
			$tipo_evaluacion='Fase 3';
			if ($decision=='Aceptado por CTE'){
			$sentencia3="update proyectos set Estado_Proyecto='Aprobado por CTE' where Codigo_Proyecto='$cod';";
			}
			else{
			$sentencia3="update proyectos set Estado_Proyecto='Desaprobado por CTE' where Codigo_Proyecto='$cod';";
			}			
			$resultado3=mysqli_query($enlace,$sentencia3);
			}
			elseif ($registro[1]=='DE') {
			$tipo_evaluacion='Fase 4';
			if ($decision=='Aceptado por DE'){
			$sentencia3="update proyectos set Estado_Proyecto='Aprobado por DE' where Codigo_Proyecto='$cod';";
			}
			else{
			$sentencia3="update proyectos set Estado_Proyecto='Desaprobado por DE' where Codigo_Proyecto='$cod';";
			}			
			$resultado3=mysqli_query($enlace,$sentencia3);			
			}
			else{
			$tipo_evaluacion='Fase 5';
			if ($decision=='Ganador'){
			$sentencia3="update proyectos set Estado_Proyecto='Ganador' where Codigo_Proyecto='$cod';";
			}
			else{
			$sentencia3="update proyectos set Estado_Proyecto='Desaprobado por Donante' where Codigo_Proyecto='$cod';";
			}			
			$resultado3=mysqli_query($enlace,$sentencia3);			
			}
			$motivo = htmlspecialchars($_POST["motivo"],ENT_QUOTES);
			$observaciones = htmlspecialchars($_POST["observaciones"],ENT_QUOTES);
			$sentencia="insert into evaluaciones (codigo_proyecto,evaluador,tipo_evaluacion,puntaje,observaciones_ad,motivo_decision,estado)
						values('$cod','$evaluador','$tipo_evaluacion','$puntaje','$observaciones','$motivo','A');";
			
			$resultado = mysqli_query($enlace,$sentencia);
			$sentencia0="select Codigo_Concurso from proyectos where Codigo_Proyecto='$cod';";
			$resultado0 = mysqli_query($enlace,$sentencia0);
			$registro0 = mysqli_fetch_row($resultado0);	
			header("Location:CUS017.php?cod=$registro0[0]");
		?>
	</body>
</html>
