<html>

	<head>

	</head>

	<body>
		<?php
				  session_start(); //inicio de sesión
					if (!isset($_SESSION["usuario"])){
						session_destroy();
						echo "<br><br> <font color='red'>Intento de acceso sin autorización!!!</font>";
						header("Location:../intranet.html");
						exit;
					}
					$cod=$_GET["cod"];
				  $proy = $_POST["proy"];
					$tipo = $_POST["tipo"];
					$puntaje = $_POST["puntaje"];
					$obs = $_POST["obs"];
					$motivo = $_POST["motivo"];
				  $enlace = mysqli_connect("localhost","root","","base_va");
				 $sentencia="update evaluaciones set tipo_evaluacion= '$tipo',puntaje='$puntaje',observaciones_ad='$obs',motivo_decision='$motivo' where codigo_evaluacion='$cod';";
				$resultado = mysqli_query($enlace,$sentencia);
				header("Location:CUS0172.php");
		?>
	</body>
</html>
