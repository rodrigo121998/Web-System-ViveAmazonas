<html>
<head> </head>
<body>
<?php
			session_start(); //inicio de sesión
			if (!isset($_SESSION["usuario"])){
				session_destroy();
				echo "<br><br> <font color='red'>Intento de acceso sin autorización!!!</font>";
				header("Location:../intranet.html");
				exit;
			}
						
				$nombre_perfil = $_POST['nombre_perfil'];
				
				
				include("../inc/clases.php");
				$objPerfil=new Perfil();
				$objPerfil->CrearCUS018($nombre_perfil);
			
				header("Location:CUS018perfiles.php");
             ?>
</body>
</html>