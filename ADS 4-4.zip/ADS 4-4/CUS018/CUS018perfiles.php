<html lang="en">
		<?php
		
		 session_start(); //inicio de sesión
						if (!isset($_SESSION["usuario"])){
							session_destroy();
							echo "<br><br> <font color='red'>Intento de acceso sin autorización!!!</font>";
							header("Location:../intranet.html");
							exit;
						}
			 else {
			 include("../inc/menuarriba.php");
			 /*$id_us= $_SESSION['id_us'];
			 $correo_us= $_SESSION['correo_us'];*/
					include("../inc/menu.php");
		  ?>
			<h1 class="h3 mb-2 text-gray-800">Relación de Perfiles</h1>
			<p class="mb-4">En esta página se puede administrar los perfiles.</p>
			<script src="http://code.jquery.com/jquery-latest.min.js" type="text/javascript"></script>
			<link rel="stylesheet" href="../css/estilos.css"/>
			<script src="script.js"></script>
			<script>
				function alerta()
				{
					return confirm("¿Esta seguro que desea eliminar este perfil?");
				}
			</script>
			<div class="card shadow mb-4">
				<div class="card-header py-3">
				  <h6 class="m-0 font-weight-bold text-primary">Tabla de Perfiles</h6>
				</div>
				<div class="card-body">
					<div class="table-responsive">
			<form class="d-none d-sm-inline-block form-inline mr-auto ml-md-3 my-2 my-md-0 mw-100 navbar-search" action='CUS018perfiles.php' method='POST' enctype='multipart/form-data'>
				<div class="input-group">
			
						<input type='text' class="form-control bg-light border-0 small" name='perfil' placeholder='Buscando Perfil...'>  
						<input type='submit' class="btn btn-primary" name='buscar' value="Buscar">
				</div>
			</form>
			<br><br>
				
				<?php
				if (!isset($_POST["buscar"])){
				include ("../inc/clases.php");
				$objPerfil=new Perfil();
				list($resultado,$contar)=$objPerfil->MostrarPerfiles();												
			
			echo "<form action='crearperfil.php' method='POST'>";
						
           if ($contar==0){
           echo  "No hay perfiles <br>";
           }
           else {

           echo "<form action='' method= 'POST'>";
          echo "<table class='table table-bordered' id='dataTable' width='100%' cellspacing='0'>";
		   echo "<thead>";
           echo "	<tr>";
           echo "		<td>Codigo Perfil</td>";
           echo "		<td>Nombre Perfil</td>";
           echo "		<td>Opciones</td>";
           echo "	</tr>";

           for ($i=1; $i <= $contar; $i++){
             $registro = mysqli_fetch_row($resultado);

             echo "	<tr>";
             echo "		<td>",$registro[0],"</td>";
             echo "		<td>",$registro[1],"</td>";
             echo "		<td><a href='modificarperfil.php?codigo_perfil=$registro[0]'>Modificar</a>  
			 <a href='verperfil.php?codigo_perfil=$registro[0]'>Consultar</a>  
			 <a onclick='return alerta();' href='eliminarperfil.php?codigo_perfil=$registro[0]'>Eliminar</a></td> ";
             echo "	</tr>";

           }
			echo "</tbody>";
			echo "</table>";
           }

              ?>
			<input type='submit' class="btn btn-primary" value="Crear perfil" >
			</form>
	  <?php
			}
			else{
			$nombre_perfil = $_POST['perfil'];
			include ("../inc/clases.php");
			$objPerfil=new Perfil();
			list($contar,$resultado)=$objPerfil->BuscarPerfil($nombre_perfil);
			
			echo"<form action='CUS018perfiles.php' enctype='multipart/form-data'>";
			
			if ($nombre_perfil==''){
				echo "No ha seleccionado ningún perfil";
			}
			else {        
			
           if ($contar==0){
           echo  "No hay perfiles con ese nombre <br>";
           }
           else {

		   echo "<form action='' method= 'POST'>";
            echo "<table class='table table-bordered' id='dataTable' width='100%' cellspacing='0'>";
           echo "<thead>";
           echo "	<tr>";
           echo "		<td>Codigo Perfil</td>";
           echo "		<td>Nombre Perfil</td>";
           echo "		<td>Opciones</td>";
           echo "	</tr>";

           for ($i=1; $i <= $contar; $i++){
             $registro = mysqli_fetch_row($resultado);


            echo "	<tr>";
             echo "		<td>",$registro[0],"</td>";
             echo "		<td>",$registro[1],"</td>";
             echo "		<td><a href='modificarperfil.php?codigo_perfil=$registro[0]'>Modificar</a>  
			 <a href='verperfil.php?codigo_perfil=$registro[0]'>Consultar</a>  
			 <a onclick='return alerta();' href='eliminarperfil.php?codigo_perfil=$registro[0]'>Eliminar</a></td> ";
             echo "	</tr>";

           }
           echo "</tbody>";
           echo "</table>";

           }
			}
             echo" <br><br>";
			echo"<input type='submit' class='btn btn-primary' value='Regresar a relación de perfiles'>";
			echo"</form>";

			 }
				echo"</div>";
			echo"</div>";
		echo"</div>";
			 			include("../inc/menubajo.php");
			 }
	  ?>
</html>
