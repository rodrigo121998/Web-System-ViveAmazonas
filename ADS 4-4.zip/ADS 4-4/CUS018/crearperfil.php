<html lang="en">
	<?php
			session_start(); //inicio de sesión
			if (!isset($_SESSION["usuario"])){
				session_destroy();
				echo "<br><br> <font color='red'>Intento de acceso sin autorización!!!</font>";
				header("Location:../intranet.html");
				exit;
			}
			 else {
				 include("../inc/menuarriba.php");
			 /*$id_us= $_SESSION['id_us'];
			 $correo_us= $_SESSION['correo_us'];*/
				include("../inc/menu.php");
	 ?>
			<h1 class="h3 mb-2 text-gray-800">Creación de perfil</h1>
			<p class="mb-4">En esta página se puede crear los perfiles.</p>
			<script src="http://code.jquery.com/jquery-latest.min.js" type="text/javascript"></script>
			<link rel="stylesheet" href="../css/estilos.css"/>
			<script src="script.js"></script>
			<script>
				function alerta()
				{
					return confirm("¿Esta seguro que desea crear este perfil?");
				}
			</script>
			<div class="card shadow mb-4">
				<div class="card-header py-3">
				  <h6 class="m-0 font-weight-bold text-primary">Creación de perfiles</h6>
				</div>
				<div class="card-body">
					<div class="table-responsive">
			<form action='CUS018perfiles.php'>
			<input type='submit' value="Regresar a relación de concursos" class='d-none d-sm-inline-block btn btn-sm btn-primary shadow-sm'>
			</form><br>
            <form class="user" onSubmit='return alerta();' action='crearCUS018.php' method="POST">
			Nombre perfil: <input class="form-control" name="nombre_perfil" type="text"> <br><br>
             <input type='submit' value='Guardar' name='Guardar' class='d-none d-sm-inline-block btn btn-sm btn-primary shadow-sm'>

            </form>
		</div>
				</div>
			</div>
	  <?php
				include("../inc/menubajo.php");
			 }
	  ?>
</html>