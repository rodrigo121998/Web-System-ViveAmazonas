<html lang="en">
	<?php
			session_start(); //inicio de sesión
			if (!isset($_SESSION["usuario"])){
				session_destroy();
				echo "<br><br> <font color='red'>Intento de acceso sin autorización!!!</font>";
				header("Location:../intranet.html");
				exit;
			}
			 else {
				include("../inc/menuarriba.php"); 
			 /*$id_us= $_SESSION['id_us'];
			 $correo_us= $_SESSION['correo_us'];*/
				include("../inc/menu.php");
	 ?>
			<h1 class="h3 mb-2 text-gray-800">Ver datos de perfiles</h1>
			<p class="mb-4">En esta página se puede consultar los perfiles.</p>
			<div class="card shadow mb-4">
				<div class="card-header py-3">
				  <h6 class="m-0 font-weight-bold text-primary">Consulta de Perfiles</h6>
				</div>
				<div class="card-body">
					<div class="table-responsive">
			<?php

            $codigo_perfil=$_GET["codigo_perfil"];
            include("../inc/clases.php");
			$objPerfil=new Perfil();
			$fila=$objPerfil->VerPerfil($codigo_perfil);
			
            echo"<form class='user' action='CUS018perfiles.php' method='POST'>";
            echo" Codigo perfil: <input class='form-control' name='codigo_perfil' type='text' value='$fila[0]' readonly> <br><br>";
            echo" Nombre perfil: <input class='form-control' name='nombre_perfil'type='text' value='$fila[1]'readonly> <br><br>"; 

            echo "<input type='submit' value='Terminado' name='Terminado' class='d-none d-sm-inline-block btn btn-sm btn-primary shadow-sm'>";

            echo" </form>";
            ?>
			
					</div>
				</div>
			</div>
	  <?php
			include("../inc/menubajo.php");
			 }
	  ?>
</html>
