<html>
	<head>
	  <meta charset="utf-8">
	  <meta content="width=device-width, initial-scale=1.0" name="viewport">
	  <meta name="referrer" content="origin-when-crossorigin" id="meta_referrer">
	  <title> Intranet Vive Amazonas</title>
	  <meta content="" name="descriptison">
	  <meta content="" name="keywords">

	  <!-- Favicons -->
	  <link href="../assets/img/favicon.png" rel="icon">
	  <link href="../assets/img/apple-touch-icon.png" rel="apple-touch-icon">

	  <!-- Google Fonts -->
	  <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i|Raleway:300,300i,400,400i,500,500i,600,600i,700,700i|Poppins:300,300i,400,400i,500,500i,600,600i,700,700i" rel="stylesheet">

	  <!-- Vendor CSS Files -->
	  <link href="../assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
	  <link href="../assets/vendor/icofont/icofont.min.css" rel="stylesheet">
	  <link href="../assets/vendor/boxicons/css/boxicons.min.css" rel="stylesheet">
	  <link href="../assets/vendor/venobox/venobox.css" rel="stylesheet">
	  <link href="../assets/vendor/owl.carousel/assets/owl.carousel.min.css" rel="stylesheet">
	  <link href="../assets/vendor/aos/aos.css" rel="stylesheet">
	  <!-- Template Main CSS File -->
	  <link href="../css/style_10.css" rel="stylesheet">

	</head>
    <body>
	<main>
		<?php
		
						session_start(); //inicio de sesión
						if (!isset($_SESSION["usuario"])){
							session_destroy();
							echo "<br><br> <font color='red'>Intento de acceso sin autorización!!!</font>";
							header("Location:../intranet.html");
							exit;
						}
			 else {
			 /*$id_us= $_SESSION['id_us'];
			 $correo_us= $_SESSION['correo_us'];*/
					include("../inc/menu.php");
		 ?>
		 <div>
			<h1 color=green>Búsqueda de Perfil</h1>
			<script src="http://code.jquery.com/jquery-latest.min.js" type="text/javascript"></script>
			<link rel="stylesheet" href="../css/estilos.css"/>
			<script src="script.js"></script>
			<script>
				function alerta()
				{
					return confirm("¿Esta seguro que desea eliminar este perfil?");
				}
			</script>
			<br><br>
			<form action='CUS018perfiles.php' method='POST'>
			<?php
			$nombre_perfil = $_POST['perfil'];
			include ("../inc/clases.php");
			$objPerfil=new Perfil();
			list($contar,$resultado)=$objPerfil->BuscarPerfil($nombre_perfil);
			
			if ($nombre_perfil==''){
				echo "No ha seleccionado ningún perfil";
			}
			else {        
			
           if ($contar==0){
           echo  "No hay perfiles con ese nombre <br>";
           }
           else {

		   echo "<form action='' method= 'POST'>";
           echo "<table border=1>";
           echo "	<tr>";
           echo "		<td>Codigo Perfil</td>";
           echo "		<td>Nombre Perfil</td>";
           echo "		<td>Opciones</td>";
           echo "	</tr>";

           for ($i=1; $i <= $contar; $i++){
             $registro = mysqli_fetch_row($resultado);


            echo "	<tr>";
             echo "		<td>",$registro[0],"</td>";
             echo "		<td>",$registro[1],"</td>";
             echo "		<td><a href='modificarperfil.php?codigo_perfil=$registro[0]'>Modificar</a>  
			 <a href='verperfil.php?codigo_perfil=$registro[0]'>Consultar</a>  
			 <a onclick='return alerta();' href='eliminarperfil.php?codigo_perfil=$registro[0]'>Eliminar</a></td> ";
             echo "	</tr>";

           }
           echo "</table>";

           }
			}
             ?>
			 <br><br>
			<input type='submit' value="Regresar a relación de perfiles" >
		  </form>
		  </div>
	  <?php
			 }
	  ?>
		</main>
    </body>
</html>