<html lang="en">
		<?php
		
						session_start(); //inicio de sesión
						if (!isset($_SESSION["usuario"])){
							session_destroy();
							echo "<br><br> <font color='red'>Intento de acceso sin autorización!!!</font>";
							header("Location:../intranet.html");
							exit;
						}
			 else {
					include("../inc/menuarriba.php");
			 /*$id_us= $_SESSION['id_us'];
			 $correo_us= $_SESSION['correo_us'];*/
					include("../inc/menu.php");
					$cod=$_GET["cod"];
		 ?>
		 <div>
			<h1 class="h3 mb-2 text-gray-800">Subir Archivo Adjunto de la Consulta</h1>
			<script src="http://code.jquery.com/jquery-latest.min.js" type="text/javascript"></script>
			<link rel="stylesheet" href="../css/estilos.css"/>
			<script src="script.js"></script>
			<script>
				function alerta()
				{
					return confirm("¿Esta seguro que desea subir este archivo?");
				}
			</script>
			<p class="mb-4">En esta página se puede subir los archivos adjuntos de la consulta.</p>
			<div class="card shadow mb-4">
				<div class="card-header py-3">
				  <h6 class="m-0 font-weight-bold text-primary">Upload de Archivos Adjuntos de Consulta</h6>
				</div>
				<div class="card-body">
					<div class="table-responsive">
			<?php
			echo"<form action='modificarconsulta.php?cod=$cod' method='POST' enctype='multipart/form-data'>";
			?>
			<input type='submit' value="Regresar a la consulta" class='d-none d-sm-inline-block btn btn-sm btn-primary shadow-sm' >
			</form><br>
			<?php
			echo"<form onSubmit='return alerta();' action='upload_adj.php?cod=$cod' method='POST' enctype='multipart/form-data'>";
			?>
			Archivo Adjunto: <input name="adjunto" type="file" class="form-control-file" accept=".jpg,.png,application/msword,application/pdf"> <br><br>
			<input type='submit' value="Subir Adjunto" class='d-none d-sm-inline-block btn btn-sm btn-primary shadow-sm'>
		  </form>
					</div>
				</div>
			</div>
	  <?php
			include("../inc/menubajo.php");
			 }
	  ?>
</html>