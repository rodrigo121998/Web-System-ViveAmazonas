<?php
			session_start(); //inicio de sesión
					if (!isset($_SESSION["usuario"])){
						session_destroy();
						echo "<br><br> <font color='red'>Intento de acceso sin autorización!!!</font>";
						header("Location:../intranet.html");
						exit;
					}
			$cod=$_GET["cod"];
			$nombre_adjunto=$_FILES['adjunto']['name'];
			$tipo_adjunto=$_FILES['adjunto']['type'];
			$tamano_adjunto=$_FILES['adjunto']['size'];
			$carpeta_destino=$_SERVER['DOCUMENT_ROOT'].'/ADS 4/upload/';
			move_uploaded_file($_FILES['adjunto']['tmp_name'],$carpeta_destino.$nombre_adjunto);
			$adjunto_objetivo=fopen($carpeta_destino.$nombre_adjunto,'r');
			$contenido_adjunto=fread($adjunto_objetivo,$tamano_adjunto);
			$contenido_adjunto=addslashes($contenido_adjunto);
			fclose($adjunto_objetivo);
			$enlace = mysqli_connect("localhost","root","","base_va");
			$sentencia="update consultas set adjunto='$contenido_adjunto',
			tipo_adjunto='$tipo_adjunto' where codigo_consulta='$cod';";
			$resultado = mysqli_query($enlace,$sentencia);
			header("Location:modificarconsulta.php?cod=$cod");
?>