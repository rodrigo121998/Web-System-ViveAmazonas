
		<?php
				  session_start(); //inicio de sesión
					if (!isset($_SESSION["usuario"])){
						session_destroy();
						echo "<br><br> <font color='red'>Intento de acceso sin autorización!!!</font>";
						header("Location:../intranet.html");
						exit;
					}
					  $cod=$_GET["cod"];
					  $consulta = $_POST['consulta'];
					  $descripcion = $_POST['descripcion'];
					  $enlace = mysqli_connect("localhost","root","","base_va");
					 $sentencia="update consultas set titulo = '$consulta',
					 descripcion='$descripcion'
					 where codigo_consulta='$cod';";
					$resultado = mysqli_query($enlace,$sentencia);
					header("Location:CUS020foroprop.php");
		?>