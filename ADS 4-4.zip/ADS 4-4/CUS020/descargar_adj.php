<?php
$cod=$_GET["cod"];
$enlace = mysqli_connect("localhost","root","","base_va");
$sentencia="Select tipo_adjunto,adjunto from consultas where codigo_consulta=$cod;";
$resultado = mysqli_query($enlace,$sentencia);
$fila=mysqli_fetch_row($resultado);
header("Content-type: $fila[0]");
echo $fila[1];
?>