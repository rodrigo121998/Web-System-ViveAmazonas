<html lang="en">
	<?php
			session_start(); //inicio de sesión
			if (!isset($_SESSION["usuario"])){
				session_destroy();
				echo "<br><br> <font color='red'>Intento de acceso sin autorización!!!</font>";
				header("Location:../intranet.html");
				exit;
			}
			 else {
			include("../inc/menuarriba.php");
			 /*$id_us= $_SESSION['id_us'];
			 $correo_us= $_SESSION['correo_us'];*/
			include("../inc/menu.php");

	 ?>
			<h1 class="h3 mb-2 text-gray-800">Modificación de datos de consultas</h1>
			<p class="mb-4">En esta página se puede modificar las consultas.</p>
			<div class="card shadow mb-4">
				<div class="card-header py-3">
				  <h6 class="m-0 font-weight-bold text-primary">Modificación de Consultas</h6>
				</div>
				<div class="card-body">
					<div class="table-responsive">
			<form action='CUS020foroprop.php'>
			<input type='submit' value="Regresar a relación de consultas" class='d-none d-sm-inline-block btn btn-sm btn-primary shadow-sm' >
			</form><br>
			<?php

            $cod=$_GET["cod"];
            $sentencia2="SELECT titulo,descripcion,adjunto FROM consultas where codigo_consulta='$cod';";
            $resultado2=mysqli_query($enlace,$sentencia2);
            $fila=mysqli_fetch_row($resultado2);
			echo "<script src='http://code.jquery.com/jquery-latest.min.js' type='text/javascript'></script>";
			echo "<link rel='stylesheet' href='../css/estilos.css'/>";
			echo "<script src='script.js'></script>";
			echo "<script>";
			echo "function alerta(){";
			echo"return confirm('¿Está seguro que desea modificar esta consulta?');}";
			echo "</script>";
            echo"<form class='user' onSubmit='return alerta();' action='editarconsulta.php?cod=$cod' method='POST' enctype='multipart/form-data'>";
			echo"Título: <input class='form-control' name='consulta' type='text' value='$fila[0]'> <br><br>";
			echo"Descripción de la consulta:<br>";
			echo"<textarea class='form-control' name='descripcion' rows='5'  value='$fila[1]'>$fila[1]</textarea>";
			echo"<br><br>";
			echo"Archivo adjunto: ";
			if ($fila[2]<>NULL){
			echo"<a href='descargar_adj.php?cod=$cod' class='d-none d-sm-inline-block btn btn-sm btn-primary shadow-sm'>Archivo adjunto</a><br><br>";
			echo"<a href='subir_adj.php?cod=$cod' class='d-none d-sm-inline-block btn btn-sm btn-primary shadow-sm'>Cambiar Archivo Adjunto</a><br><br>";
			} else {
				echo "No hay archivo subido<br><br>";
				echo"<a href='subir_adj.php?cod=$cod' class='d-none d-sm-inline-block btn btn-sm btn-primary shadow-sm'>Agregar Archivo Adjunto</a><br><br>";
			}
            echo "<input type='submit' value='Guardar' name='Guardar' class='d-none d-sm-inline-block btn btn-sm btn-primary shadow-sm'>";
            echo" </form>";
            ?>
					</div>
				</div>
			</div>
	  <?php
			include("../inc/menubajo.php");
			 }
	  ?>
</html>
