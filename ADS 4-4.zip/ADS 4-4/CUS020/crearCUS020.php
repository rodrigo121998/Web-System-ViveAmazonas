<html>
<head> </head>
<body>
<?php
			session_start(); //inicio de sesión
			if (!isset($_SESSION["usuario"])){
				session_destroy();
				echo "<br><br> <font color='red'>Intento de acceso sin autorización!!!</font>";
				header("Location:../intranet.html");
				exit;
			}
						
			  $consulta = $_POST['consulta'];
			  $descripcion = $_POST['descripcion'];
			  $nombre_adjunto=$_FILES['adjunto']['name'];
			  $tipo_adjunto=$_FILES['adjunto']['type'];
			  $tamano_adjunto=$_FILES['adjunto']['size'];
			  $carpeta_destino=$_SERVER['DOCUMENT_ROOT'].'/ADS 4/upload/';
			  move_uploaded_file($_FILES['adjunto']['tmp_name'],$carpeta_destino.$nombre_adjunto);
			  $adjunto_objetivo=fopen($carpeta_destino.$nombre_adjunto,'r');
			  $contenido_adjunto=fread($adjunto_objetivo,$tamano_adjunto);
			  $contenido_adjunto=addslashes($contenido_adjunto);
			  fclose($adjunto_objetivo);
			  $usuario = $_SESSION['usuario'];
			  $enlace = mysqli_connect("localhost","root","","base_va");
			  $sentencia0="select a.Codigo_Empresa from empresas_proponentes a,(select id from usuarios where usuario='$usuario') b 
			  where b.id=a.ID_Representante;";
			  $resultado0 = mysqli_query($enlace,$sentencia0);
			  $registro = mysqli_fetch_row($resultado0);
			  $id=$registro[0];
			  $enlace = mysqli_connect("localhost","root","","base_va");
			$sentencia="INSERT INTO consultas(titulo,fecha_creacion,descripcion,adjunto,
						id_creador,tipo_adjunto)
						VALUES ('$consulta',NOW(),'$descripcion','$contenido_adjunto','$id','$tipo_adjunto');";
			$resultado = mysqli_query($enlace,$sentencia);
              header("Location:CUS020foroprop.php");

             ?>
</body>
</html>