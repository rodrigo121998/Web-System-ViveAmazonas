<html>
	<head>
	</head>

    <body>

	<?php
	session_start(); //inicio de sesión
			if (!isset($_SESSION["usuario"])){
				session_destroy();
				echo "<br><br> <font color='red'>Intento de acceso sin autorización!!!</font>";
				header("Location:../intranet.html");
				exit;
			}
			$cod=$_GET["cod"];
			$sentencia3="select id_usuario from usuariosxperfil where id='$cod';";
			$enlace = mysqli_connect("localhost","root","","base_va");
			$resultado3=mysqli_query($enlace,$sentencia3);
			$registrocero = mysqli_fetch_row($resultado3);
			$sentencia="DELETE FROM usuariosxperfil WHERE id = '$cod';";
            $resultado=mysqli_query($enlace,$sentencia);
			header("Location:verperfil.php?cod=$registrocero[0]");
?>
</html>