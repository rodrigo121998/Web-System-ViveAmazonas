<html lang="en">
	<?php
	 session_start(); //inicio de sesión
						if (!isset($_SESSION["usuario"])){
							session_destroy();
							echo "<br><br> <font color='red'>Intento de acceso sin autorización!!!</font>";
							header("Location:../intranet.html");
							exit;
						}
			 else {
				 include("../inc/menuarriba.php");
			 /*$id_us= $_SESSION['id_us'];
			 $correo_us= $_SESSION['correo_us'];*/
			include("../inc/menu.php");
	 ?>
	<div>
		<h1 class="h3 mb-2 text-gray-800">Perfiles de un usuario</h1>
			<p class="mb-4">En esta página se puede consultar los perfiles de un usuario.</p>
			<script src="http://code.jquery.com/jquery-latest.min.js" type="text/javascript"></script>
			<link rel="stylesheet" href="../css/estilos.css"/>
			<script src="script.js"></script>
			<script>
				function alerta()
				{
					return confirm("¿Esta seguro que desea eliminar este Perfil?");
				}
			</script>
			<div class="card shadow mb-4">
				<div class="card-header py-3">
				  <h6 class="m-0 font-weight-bold text-primary">Perfiles de usuarios</h6>
				</div>
				<div class="card-body">
					<div class="table-responsive">
			<form class='user' action='CUS019asignarperf.php' method='POST'>
			<?php
			$cod=$_GET["cod"];
            $sentencia2="select a.id, b.perfil from usuariosxperfil a LEFT join perfiles b on a.cod_perfil=b.cod_perfil where a.id_usuario='$cod';";
            $resultado2 = mysqli_query($enlace,$sentencia2);
            $contar= mysqli_num_rows($resultado2);
           echo "<form action='' method= 'POST'>";
           echo "<table class='table table-bordered' id='dataTable' width='100%' cellspacing='0'>";
           echo "<thead>";
           echo "	<tr>";
           echo "		<td>Codigo</td>";
           echo "		<td>Perfil</td>";
		   echo "		<td>Opciones</td>";
           echo "	</tr>";
		   echo "</thead>";
		   echo "<tbody>";

           for ($i=1; $i <= $contar; $i++){
             $registro = mysqli_fetch_row($resultado2);
             echo "	<tr>";
             echo "		<td>",$registro[0],"</td>";
             echo "		<td>",$registro[1],"</td>";
             echo "		<td><a href='modificarperfil.php?cod=$registro[0]' class='d-none d-sm-inline-block btn btn-sm btn-primary shadow-sm'>Modificar perfil</a>";
			 echo"		<a onclick='return alerta();' href='eliminarperfil.php?cod=$registro[0]' class='d-none d-sm-inline-block btn btn-sm btn-primary shadow-sm'>Eliminar perfil</a><td>";
             echo "	</tr>";

           }
           echo "</tbody>";
           echo "</table>";

           

             ?>
			 <input type='submit' value="Regresar a relación de usuarios" class='d-none d-sm-inline-block btn btn-sm btn-primary shadow-sm'>
		</form>
					</div>
				</div>
			</div>
	  <?php
			include("../inc/menubajo.php");
			 }
	  ?>
</html>