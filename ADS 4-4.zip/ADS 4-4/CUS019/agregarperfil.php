<html lang="en">
	<?php
	 session_start(); //inicio de sesión
			if (!isset($_SESSION["usuario"])){
				session_destroy();
				echo "<br><br> <font color='red'>Intento de acceso sin autorización!!!</font>";
				header("Location:../intranet.html");
				exit;
			}
			 else {
				 include("../inc/menuarriba.php");
			 /*$id_us= $_SESSION['id_us'];
			 $correo_us= $_SESSION['correo_us'];*/
				include("../inc/menu.php");
	 ?>
			<h1 class="h3 mb-2 text-gray-800">Agregar perfil</h1>
            <p class="mb-4">En esta página se puede agregar los perfiles a los usuarios.</p>
			<script src="http://code.jquery.com/jquery-latest.min.js" type="text/javascript"></script>
			<link rel="stylesheet" href="css/estilos.css"/>
			<script src="script.js"></script>
			<script>
				function alerta()
				{
					return confirm("¿Esta seguro que desea agregar este perfil a este usuario?");
				}
			</script>
			<div class="card shadow mb-4">
				<div class="card-header py-3">
				  <h6 class="m-0 font-weight-bold text-primary">Asignación de perfil</h6>
				</div>
				<div class="card-body">
					<div class="table-responsive">
			<form action='CUS019asignarperf.php'>
			<input type='submit' value='Regresar a relación de Usuarios' class='d-none d-sm-inline-block btn btn-sm btn-primary shadow-sm'>
			</form><br>
			<?php
			$cod=$_GET["cod"];
            $sentencia3="SELECT id,concat(nombres,' ',apellidos) FROM usuarios where id='$cod';";
			$resultado3 = mysqli_query($enlace,$sentencia3);
			$registro3 = mysqli_fetch_row($resultado3);
            echo"<form class='user' onSubmit='return alerta();' action='AgregarCUS019.php?cod=$registro3[0]' method='POST'>";
            echo"Usuario: <input class='form-control' name='idus' type='text' value='$registro3[1]' readonly><br><br>";
            echo"Perfil: <select class='form-control' name='idperfil'>";
			echo"<option value=''>Elige una opción</option>";
				$sentencia2="select cod_perfil,perfil from perfiles 
				where cod_perfil not in (select a.cod_perfil as codigo from usuariosxperfil a 
				LEFT join perfiles b on a.cod_perfil=b.cod_perfil where a.id_usuario='$cod');";
				$resultado2 = mysqli_query($enlace,$sentencia2);
				$contar= mysqli_num_rows($resultado2);
				for ($i=1; $i <= $contar; $i++){
				$registro = mysqli_fetch_row($resultado2);
				echo "<option value=$registro[0]>$registro[1]</option>";	
				}
				?>
			</select><br><br>
            <input type='submit' value='Guardar' name='Guardar' class='d-none d-sm-inline-block btn btn-sm btn-primary shadow-sm'>

            </form>
					</div>
				</div>
			</div>
	  <?php
			include("../inc/menubajo.php");
			 }
	  ?>
</html>