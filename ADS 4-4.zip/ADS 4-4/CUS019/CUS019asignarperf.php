<html>
	<?php
	 session_start(); //inicio de sesión
						if (!isset($_SESSION["usuario"])){
							session_destroy();
							echo "<br><br> <font color='red'>Intento de acceso sin autorización!!!</font>";
							header("Location:../intranet.html");
							exit;
						}
			 else {
				 include("../inc/menuarriba.php");
			 /*$id_us= $_SESSION['id_us'];
			 $correo_us= $_SESSION['correo_us'];*/
			include("../inc/menu.php");
	 ?>
	<div>
		<h1 class="h3 mb-2 text-gray-800">Asignación de Perfil a Usuario</h1>
		<p class="mb-4">En esta página se puede asignar los perfiles a usuarios.</p>
			<div class="card shadow mb-4">
				<div class="card-header py-3">
				  <h6 class="m-0 font-weight-bold text-primary">Tabla de Concursos</h6>
				</div>
				<div class="card-body">
					<div class="table-responsive">
			<form class="d-none d-sm-inline-block form-inline mr-auto ml-md-3 my-2 my-md-0 mw-100 navbar-search" action='CUS019asignarperf.php' method='POST' enctype='multipart/form-data'>
			<div class="input-group">
			<input type='text' class="form-control bg-light border-0 small" name="usuarioxperfil" placeholder='Buscar Usuario...'>
			<input type='submit' class="btn btn-primary" name='buscar' value="Buscar Usuario" ><br><br>
			</div>
			</form>
			<br><br>
			<?php
			if (!isset($_POST["buscar"])){
			
            $sentencia2="SELECT id,nombre_usuario, case when numero_perfiles>0 then 'Si tiene perfil' when numero_perfiles=0 then 'No tiene perfil' 
			end as condicion,numero_perfiles 
			FROM (select a.id, concat(a.nombres,' ',a.apellidos) as nombre_usuario,
			count(b.id_usuario) as numero_perfiles from usuarios a 
			left join usuariosxperfil b on a.id=b.id_usuario where a.estado='A' group by nombre_usuario) sub order by id;";
            $resultado2 = mysqli_query($enlace,$sentencia2);
            $contar= mysqli_num_rows($resultado2);
			echo"<form action='' method='POST'>";
           if ($contar==0){
           echo  "No hay usuarios <br>";
           }
           else {

           echo "<form action='' method= 'POST'>";
           echo "<table class='table table-bordered' id='dataTable' width='100%' cellspacing='0'>";
           echo "<thead>";
           echo "	<tr>";
           echo "		<td>Codigo Usuario</td>";
           echo "		<td>Nombre Usuario</td>";
           echo "		<td>¿Tiene perfil?</td>";
           echo "		<td>Número de perfiles</td>";
		   echo "		<td>Opciones</td>";
           echo "	</tr>";
		   echo "</thead>";
		   echo "<tbody>";

           for ($i=1; $i <= $contar; $i++){
             $registro = mysqli_fetch_row($resultado2);


             echo "	<tr>";
             echo "		<td>",$registro[0],"</td>";
             echo "		<td>",$registro[1],"</td>";
             echo "		<td>",$registro[2],"</td>";
			 echo "		<td>",$registro[3],"</td>";
             echo "		<td><a href='agregarperfil.php?cod=$registro[0]' class='d-none d-sm-inline-block btn btn-sm btn-primary shadow-sm'>Agregar perfil</a>";
			 if ($registro[3]>0) {
			 echo"  <a href='verperfil.php?cod=$registro[0]' class='d-none d-sm-inline-block btn btn-sm btn-primary shadow-sm'>Ver perfiles</a></td>";
			 }
			 else {
			echo"</td>";
			 }
             echo "	</tr>";

           }
           echo "</tbody>";
           echo "</table>";

           }

             ?>
		</form>
	  <?php
			}
			 else{
			 $usuarioxperfil = $_POST['usuarioxperfil'];
			 echo"<form action='CUS019asignarperf.php' enctype='multipart/form-data'>";
			if ($usuarioxperfil==''){
				echo"No ha seleccionado ningún usuario";
			}
			else {
           $sentencia2="SELECT id,nombre_usuario, case when numero_perfiles>0 then 'Si tiene perfil' when numero_perfiles=0 then 'No tiene perfil' 
			end as condicion,numero_perfiles 
			FROM (select a.id, concat(a.nombres,' ',a.apellidos) as nombre_usuario,
			count(b.id_usuario) as numero_perfiles from usuarios a 
			left join usuariosxperfil b on a.id=b.id_usuario where a.estado='A' group by nombre_usuario) sub where nombre_usuario like '%$usuarioxperfil%';";
            $resultado2 = mysqli_query($enlace,$sentencia2);
            $contar= mysqli_num_rows($resultado2);

           if ($contar==0){
           echo  "No hay usuarios";
           }
           else {

           echo "<form action='' method= 'POST'>";
           echo "<table class='table table-bordered' id='dataTable' width='100%' cellspacing='0'>";
           echo "<thead>";
           echo "	<tr>";
           echo "		<td>Codigo Usuario</td>";
           echo "		<td>Nombre Usuario</td>";
           echo "		<td>¿Tiene perfil?</td>";
           echo "		<td>Número de perfiles</td>";
		   echo "		<td>Opciones</td>";
           echo "	</tr>";
		   echo "</thead>";
		   echo "<tbody>";

           for ($i=1; $i <= $contar; $i++){
             $registro = mysqli_fetch_row($resultado2);


             echo "	<tr>";
             echo "		<td>",$registro[0],"</td>";
             echo "		<td>",$registro[1],"</td>";
             echo "		<td>",$registro[2],"</td>";
			 echo "		<td>",$registro[3],"</td>";
             echo "		<td><a href='agregarperfil.php?cod=$registro[0]' class='d-none d-sm-inline-block btn btn-sm btn-primary shadow-sm'>Agregar perfil</a>";
			 if ($registro[3]>0) {
			 echo"  <a href='verperfil.php?cod=$registro[0]' class='d-none d-sm-inline-block btn btn-sm btn-primary shadow-sm'>Ver perfiles</a></td>";
			 }
			 else {
			echo"</td>";
			 }
             echo "	</tr>";

           }
           echo "</tbody>";
           echo "</table>";
           }
			}
			echo" <br><br>";
			echo"<input type='submit' class='btn btn-primary' value='Regresar a relación de Usuarios'>";
			echo"</form>";
			 }
				echo"</div>";
			echo"</div>";
		echo"</div>";
			 
				include("../inc/menubajo.php");
			 }
	  ?>
</html>