<html>
<head> </head>
<body>
<?php
	session_start(); //inicio de sesión
	if (!isset($_SESSION["usuario"])){
		session_destroy();
		echo "<br><br> <font color='red'>Intento de acceso sin autorización!!!</font>";
		header("Location:../intranet.html");
		exit;
	}
	$cod=$_GET["cod"];
	$idperfil = $_POST["idperfil"];
	$enlace=mysqli_connect("localhost","root","","base_va");
	$sentencia="INSERT INTO usuariosxperfil(id_usuario,cod_perfil)
	VALUES ('$cod','$idperfil');";
	$resultado = mysqli_query($enlace,$sentencia);
	header("Location:CUS019asignarperf.php");

 ?>
</body>
</html>