<html lang="en">
	<?php
			session_start(); //inicio de sesión
			if (!isset($_SESSION["usuario"])){
				session_destroy();
				echo "<br><br> <font color='red'>Intento de acceso sin autorización!!!</font>";
				header("Location:../intranet.html");
				exit;
			}
			 else {
			include("../inc/menuarriba.php");
			 /*$id_us= $_SESSION['id_us'];
			 $correo_us= $_SESSION['correo_us'];*/
			include("../inc/menu.php");

	 ?>
			<h1 class="h3 mb-2 text-gray-800">Modificación de datos de concursos</h1>
			<p class="mb-4">En esta página se puede modificar los concursos.</p>
			<div class="card shadow mb-4">
				<div class="card-header py-3">
				  <h6 class="m-0 font-weight-bold text-primary">Modificación de Concursos</h6>
				</div>
				<div class="card-body">
					<div class="table-responsive">
			<form action='CUS001concursos.php'>
			<input type='submit' value="Regresar a relación de concursos" class='d-none d-sm-inline-block btn btn-sm btn-primary shadow-sm' >
			</form><br>
			<?php

            $cod=$_GET["cod"];
            $sentencia2="SELECT * FROM concurso where codigo_concurso='$cod';";
            $resultado2=mysqli_query($enlace,$sentencia2);
            $fila=mysqli_fetch_row($resultado2);
			echo "<script src='http://code.jquery.com/jquery-latest.min.js' type='text/javascript'></script>";
			echo "<link rel='stylesheet' href='../css/estilos.css'/>";
			echo "<script src='script.js'></script>";
			echo "<script>";
			echo "function alerta(){";
			echo"return confirm('¿Está seguro que desea modificar este concurso?');}";
			echo "</script>";
            echo"<form class='user' onSubmit='return alerta();' action='editarconcurso.php?cod=$cod' method='POST' enctype='multipart/form-data'>";
			echo"Nombre Concurso: <input class='form-control' name='concurso' type='text' value='$fila[1]'> <br><br>";
			echo"Fecha inicio del concurso: <input class='form-control' name='inicio' type='date' value='$fila[2]'> <br><br>";
			echo"Fecha fin del concurso: <input class='form-control' name='fin' type='date' value='$fila[3]'> <br><br>";
			echo"Descripción del concurso:<br>";
			echo"<textarea class='form-control' name='descripcion' rows='5'  value='$fila[5]'>$fila[5]</textarea>";
			echo"<br><br>";
			echo"Clasificación <input class='form-control' name='clasi' type='text' value='$fila[4]'> <br><br>";
			echo"Imagen: ";
			if ($fila[6]<>NULL){
			echo"<a href='descargar_imagen.php?cod=$cod' class='d-none d-sm-inline-block btn btn-sm btn-primary shadow-sm'>Imagen</a><br><br>";
			echo"<a href='subir_imagen.php?cod=$cod' class='d-none d-sm-inline-block btn btn-sm btn-primary shadow-sm'>Cambiar Imagen</a><br><br>";
			} else {
				echo "No hay archivo subido<br><br>";
				echo"<a href='subir_imagen.php?cod=$cod' class='d-none d-sm-inline-block btn btn-sm btn-primary shadow-sm'>Agregar Imagen</a><br><br>";
			}
			echo"Objetivos:<br>";
			echo"<textarea class='form-control' name='objetivos' rows='10' cols='40' value='$fila[7]'>$fila[7]</textarea>";
			echo"<br><br>";
			echo"Monto financiado: <input class='form-control' name='monto' type='number' value='$fila[8]'> <br><br>";
			echo"¿A quién se encuentra dirigido?: <input class='form-control' name='dirigido' type='text' value='$fila[9]'> <br><br>";
			echo"Donador: <select class='form-control' name='donador'>";
				$sentencia4="Select IDDonante,Nombre_donante from donantes where (estado='A') and (IDDonante='$fila[10]');";
				$resultado4 = mysqli_query($enlace,$sentencia4);
				$registro4 = mysqli_fetch_row($resultado4);
			echo"	<option value=$registro4[0]>$registro4[1]</option>";
				$sentencia2="Select IDDonante,Nombre_donante from donantes where (estado='A')and (IDDonante<>'$fila[10]');";
				$resultado2 = mysqli_query($enlace,$sentencia2);
				$contar= mysqli_num_rows($resultado2);
				if ($contar==0){
				   echo  "<option value=''>No hay otros donantes</option>";
				}
				else {
					for ($i=1; $i <= $contar; $i++){
					$registro = mysqli_fetch_row($resultado2);
					echo "<option value=$registro[0]>$registro[1]</option>";
					
				}
				}			
			echo"</select><br><br>";
            echo"Bases de concurso: "; 
			if ($fila[11]<>NULL){
			echo"<a href='descargar_bases.php?cod=$cod' class='d-none d-sm-inline-block btn btn-sm btn-primary shadow-sm'>Bases</a><br>";
			echo"<a href='subir_bases.php?cod=$cod' class='d-none d-sm-inline-block btn btn-sm btn-primary shadow-sm'>Cambiar Bases</a><br><br>";
			} else{
				echo "No hay archivo subido<br><br>";
				echo"<a href='subir_bases.php?cod=$cod' class='d-none d-sm-inline-block btn btn-sm btn-primary shadow-sm'>Agregar Bases</a><br><br>";
			}
            echo "<input type='submit' value='Guardar' name='Guardar' class='d-none d-sm-inline-block btn btn-sm btn-primary shadow-sm'>";
            echo" </form>";
            ?>
					</div>
				</div>
			</div>
	  <?php
			include("../inc/menubajo.php");
			 }
	  ?>
</html>
