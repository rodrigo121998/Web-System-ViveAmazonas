<html lang="en">
	<?php
			session_start(); //inicio de sesión
			
			if (!isset($_SESSION["usuario"])){
				session_destroy();
				echo "<br><br> <font color='red'>Intento de acceso sin autorización!!!</font>";
				header("Location:../intranet.html");
				exit;
			}
			 else {
			include("../inc/menuarriba.php");
			 /*$id_us= $_SESSION['id_us'];
			 $correo_us= $_SESSION['correo_us'];*/
			include("../inc/menu.php");
			$usuario=$_SESSION['usuario'];
			$nombres=$_POST['nombres'];
			$apellidos=$_POST['apellidos'];
			$correo=$_POST['correo'];

	 ?>
			<h1 class="h3 mb-2 text-gray-800">Búsqueda de personas</h1>
			<p class="mb-4">En esta página se puede consultar los usuarios de Vive Amazonas.</p>
			<div class="card shadow mb-4">
				<div class="card-header py-3">
				  <h6 class="m-0 font-weight-bold text-primary">Resultado de la búsqueda</h6>
				</div>
					<div class="card-body">
						<div class="table-responsive">
				<?php

						$sentencia2= "SELECT nombres,apellidos,correo FROM usuarios where estado='A' and nombres LIKE '%$nombres%' and apellidos LIKE '%$apellidos%' and correo LIKE '%$correo%';";
						$resultado2 = mysqli_query($enlace,$sentencia2);
						$contar= mysqli_num_rows($resultado2);
					   echo"<form action='CUS0122.php' method='POST'>";
					   if ($contar==0){
							echo  "No hay usuarios <br>";
					   }
					   else {
						   echo "<table class='table table-bordered' id='dataTable' width='100%' cellspacing='0'>";
						   echo "<thead>";
						   echo "	<tr>";
						   echo "		<td>Nombres</td>";
						   echo "		<td>Apellidos</td>";
						   echo "		<td>Correo</td>";
						   echo "	</tr>";
						   echo "</thead>";
						   echo "<tbody>";
							   for ($i=1; $i <= $contar; $i++){
								 $registro = mysqli_fetch_row($resultado2);
								 echo "	<tr>";
								 echo "		<td>",$registro[0],"</td>";
								 echo "		<td>",$registro[1],"</td>";
								  echo "    <td>",$registro[2],"</td>";
								 echo "	</tr>";

							   }
						   echo "</tbody>";
						   echo "</table>";
						}
						 ?>
						<input type='submit' class="btn btn-primary" value="Regresar" >
					  </form>
					  
					</div>
				</div>
			</div>
			
	  <?php
			include("../inc/menubajo.php");
			 }
	  ?>
</html>
