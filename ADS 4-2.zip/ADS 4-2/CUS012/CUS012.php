<html lang="en">
	<?php
			session_start(); //inicio de sesión
			
			if (!isset($_SESSION["usuario"])){
				session_destroy();
				echo "<br><br> <font color='red'>Intento de acceso sin autorización!!!</font>";
				header("Location:../intranet.html");
				exit;
			}
			 else {
			include("../inc/menuarriba.php");
			 /*$id_us= $_SESSION['id_us'];
			 $correo_us= $_SESSION['correo_us'];*/
			include("../inc/menu.php");
			$usuario=$_SESSION['usuario'];

	 ?>
			<h1 class="h3 mb-2 text-gray-800">Modificación de datos de usuarios</h1>
			<p class="mb-4">En esta página se puede modificar los datos de usuarios.</p>
			<div class="card shadow mb-4">
				<div class="card-header py-3">
				  <h6 class="m-0 font-weight-bold text-primary">Modificación de datos personales</h6>
				</div>
				<div class="card-body">
					<div class="table-responsive">
			<?php

            $sentencia2="SELECT * FROM usuarios where usuario='$usuario';";
            $resultado2=mysqli_query($enlace,$sentencia2);
            $fila=mysqli_fetch_row($resultado2);
			echo "<script src='http://code.jquery.com/jquery-latest.min.js' type='text/javascript'></script>";
			echo "<link rel='stylesheet' href='../css/estilos.css'/>";
			echo "<script src='script.js'></script>";
			echo "<script>";
			echo "function alerta(){";
			echo"return confirm('¿Está seguro que desea modificar tu información personal?');}";
			echo "</script>";
			echo "<script src='script.js'></script>";
			echo "<script>";
			echo "function alerta2(){";
			echo"return confirm('¿Está seguro que desea eliminar tu perfil del sistema Vive Amazonas?');}";
			echo "</script>";
            echo"<form class='user' onSubmit='return alerta();' action='modificarusuarios.php' method='POST' enctype='multipart/form-data'>";
			echo" Usuario: <input class='form-control' name='usuario' type='text' value='$fila[1]' readonly> <br><br>";
			echo"Contraseña: <input class='form-control' name='contraseña' type='text' value='$fila[2]' readonly> <br><br>";
			echo"Nombres: <input class='form-control' name='nombres' type='text' value='$fila[3]' readonly> <br><br>";
			echo"Apellidos <input class='form-control' name='apellidos' type='text' value='$fila[4]' readonly> <br><br>";
			echo"Fecha de nacimiento <input class='form-control' name='fecha' type='date' value='$fila[5]' readonly> <br><br>";
			echo"Sexo: <input class='form-control' name='fecha' type='text' value='$fila[7]' readonly> <br><br>";
			echo"Correo: <input class='form-control' name='correo' type='text' value='$fila[8]' readonly> <br><br>";
			echo"     </div>";
			echo"  </div>   ";
			echo"</div>";
            echo" <br>";
			echo"<div class='card shadow mb-4'>";
			echo"<div class='card-header py-3'>";
			echo"		<h6 class='m-0 font-weight-bold text-primary'>Foto de Perfil</h6>";
			echo"</div>";
			echo"<div class='card-body'>";
		    echo"<div class='table-responsive'>";
			$avatar= $fila[11];
			if ($fila[6]<>NULL){
			echo"<img src= '../upload/".$avatar. "' alt='' width='160' height='180' class='img-profile' ><br><br>";			
			}
			else {
				echo "No hay archivo subido<br><br>";
			    echo"<img src= '../upload/".$avatar. "' alt='' width='160' height='180' class='img-profile' ><br><br>";
				echo"<br>";
				echo"<a href='subir_imagen.php?cod=$$fila[6]' class='d-none d-sm-inline-block btn btn-sm btn-primary shadow-sm'>Agregar Foto</a><br><br>";		
				
				}
			 
			echo"     </div>";
			echo"  </div>   ";
			echo"</div>";			
            
			echo "<input type='submit' value='Modificar' name='Modificar' class='d-none d-sm-inline-block btn btn-sm btn-primary shadow-sm'><br><br>";
            echo" </form>";
			echo"<form class='user' onSubmit='return alerta2();' action='eliminarusuarios.php' method='POST' enctype='multipart/form-data'>";
			echo "<input type='submit' value='Eliminar mi usuario' name='Eliminar' class='d-none d-sm-inline-block btn btn-sm btn-primary shadow-sm'>";
			echo" </form>";
			

			
			
            ?>
					
			
						
	  <?php
			include("../inc/menubajo.php");
			 }
	  ?>
</html>
