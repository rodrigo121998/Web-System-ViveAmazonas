
		<?php
				  session_start(); //inicio de sesión
					if (!isset($_SESSION["usuario"])){
						session_destroy();
						echo "<br><br> <font color='red'>Intento de acceso sin autorización!!!</font>";
						header("Location:../intranet.html");
						exit;
					}
					  
					  $cod=$_SESSION["usuario"];
					  $contraseña = $_POST["contraseña"];
					  $nombres = $_POST["nombres"];
					  $apellidos = $_POST["apellidos"];
					  $fecha = $_POST["fecha"];
					  $sexo= $_POST["sexo"];
					  $correo= $_POST["correo"];
					  $enlace = mysqli_connect("localhost","root","","base_va");
					 $sentencia="UPDATE usuarios SET contraseña='$contraseña',				 
					 nombres = '$nombres',
					 apellidos='$apellidos',
					 fech_nac = '$fecha',
					sexo='$sexo',
					correo='$correo' 
					where usuario='$cod'";
					$resultado = mysqli_query($enlace,$sentencia);
					header("Location:CUS012.php");
		?>