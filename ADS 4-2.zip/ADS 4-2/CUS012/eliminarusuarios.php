<html>
<head> </head>
<body>
	<?php
			session_start(); //inicio de sesión
			if (!isset($_SESSION["usuario"])){
				session_destroy();
				echo "<br><br> <font color='red'>Intento de acceso sin autorización!!!</font>";
				header("Location:../intranet.html");
				exit;
			}
			$cod=$_SESSION["usuario"];
			$enlace = mysqli_connect("localhost","root","","base_va");
            $sentencia="UPDATE usuarios SET Estado='I' where usuario='$cod';";
            $resultado=mysqli_query($enlace,$sentencia);
			header("Location:../intranet.html");
?>

</body>
</html>