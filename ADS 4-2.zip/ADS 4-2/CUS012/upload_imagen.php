<?php
			session_start(); //inicio de sesión
					if (!isset($_SESSION["usuario"])){
						session_destroy();
						echo "<br><br> <font color='red'>Intento de acceso sin autorización!!!</font>";
						header("Location:../intranet.html");
						exit;
					}
			$usuario=$_SESSION["usuario"];		
			$cod=$_GET["cod"];
			$nombre_imagen=$_FILES['avatar']['name'];
			$tipo_imagen=$_FILES['avatar']['type'];
			$tamano_imagen=$_FILES['avatar']['size'];
			$carpeta_destino=$_SERVER['DOCUMENT_ROOT'].'/ADS 4/upload/';
			move_uploaded_file($_FILES['avatar']['tmp_name'],$carpeta_destino.$nombre_imagen);
			$imagen_objetivo=fopen($carpeta_destino.$nombre_imagen,'r');
			$contenido_imagen=fread($imagen_objetivo,$tamano_imagen);
			$contenido_imagen=addslashes($contenido_imagen);
			fclose($imagen_objetivo);
			$enlace = mysqli_connect("localhost","root","","base_va");
			$sentencia="update usuarios set avatar='$contenido_imagen',
			tipo_avatar='$tipo_imagen',nombre_avatar ='$nombre_imagen' where usuario='$usuario';";
			$resultado = mysqli_query($enlace,$sentencia);
			header("Location:modificarusuarios.php");
?>