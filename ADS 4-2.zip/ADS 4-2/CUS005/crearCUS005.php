<html>
<head> </head>
<body>
<?php
			session_start(); //inicio de sesión
			if (!isset($_SESSION["usuario"])){
				session_destroy();
				echo "<br><br> <font color='red'>Intento de acceso sin autorización!!!</font>";
				header("Location:../intranet.html");
				exit;
			}
			$carpeta_destino=$_SERVER['DOCUMENT_ROOT'].'/ADS 4/upload/';			
			  $proy = $_POST['proy'];
			  $tipoproy = $_POST['tipoproy'];
			  $nombre_exp=$_FILES['exp']['name'];
			  $tipo_exp=$_FILES['exp']['type'];
			  $tamano_exp=$_FILES['exp']['size'];
			  move_uploaded_file($_FILES['exp']['tmp_name'],$carpeta_destino.$nombre_exp);
			  $exp_objetivo=fopen($carpeta_destino.$nombre_exp,'r');
			  $contenido_exp=fread($exp_objetivo,$tamano_exp);
			  $contenido_exp=addslashes($contenido_exp);
			  fclose($exp_objetivo);
			  
			  $nombre_consoli=$_FILES['consoli']['name'];
			  $tipo_consoli=$_FILES['consoli']['type'];
			  $tamano_consoli=$_FILES['consoli']['size'];
			  move_uploaded_file($_FILES['consoli']['tmp_name'],$carpeta_destino.$nombre_consoli);
			  $consoli_objetivo=fopen($carpeta_destino.$nombre_consoli,'r');
			  $contenido_consoli=fread($consoli_objetivo,$tamano_consoli);
			  $contenido_consoli=addslashes($contenido_consoli);
			  fclose($consoli_objetivo);
			  
			$usuario = $_SESSION['usuario'];
			$enlace = mysqli_connect("localhost","root","","base_va");
			$sentencia0="select a.Codigo_Empresa from empresas_proponentes a, usuarios b where a.ID_Representante=b.id and b.usuario='$usuario';";
			$resultado0 = mysqli_query($enlace,$sentencia0);
			$registro = mysqli_fetch_row($resultado0);
			$id_usuario=$registro[0];
			$sentencia="INSERT INTO proyectos(Nombre_Proyecto,Tipo_Proyecto,Expediente,Consolidado_propuestas,Codigo_Proponente,Estado,tipo_expediente,
						tipo_consolidado)
						VALUES ('$proy','$tipoproy','$contenido_exp','$contenido_consoli','$id_usuario','A','$tipo_exp','$tipo_consoli');";
			$resultado = mysqli_query($enlace,$sentencia);
              header("Location:CUS005proyectos.php");

             ?>
</body>
</html>