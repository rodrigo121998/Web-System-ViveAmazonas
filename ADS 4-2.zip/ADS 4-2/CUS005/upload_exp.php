<?php
			session_start(); //inicio de sesión
					if (!isset($_SESSION["usuario"])){
						session_destroy();
						echo "<br><br> <font color='red'>Intento de acceso sin autorización!!!</font>";
						header("Location:../intranet.html");
						exit;
					}
			$cod=$_GET["cod"];
			$carpeta_destino=$_SERVER['DOCUMENT_ROOT'].'/ADS 4/upload/';
			$nombre_exp=$_FILES['exp']['name'];
			  $tipo_exp=$_FILES['exp']['type'];
			  $tamano_exp=$_FILES['exp']['size'];
			  move_uploaded_file($_FILES['exp']['tmp_name'],$carpeta_destino.$nombre_exp);
			  $exp_objetivo=fopen($carpeta_destino.$nombre_exp,'r');
			  $contenido_exp=fread($exp_objetivo,$tamano_exp);
			  $contenido_exp=addslashes($contenido_exp);
			  fclose($exp_objetivo);
			$enlace = mysqli_connect("localhost","root","","base_va");
			$sentencia="update proyectos set Expediente='$contenido_exp',
			tipo_expediente='$tipo_exp' where Codigo_Proyecto='$cod';";
			$resultado = mysqli_query($enlace,$sentencia);
			header("Location:modificarproyectos.php?cod=$cod");
?>