<html lang="en">
	<?php
			session_start(); //inicio de sesión
			if (!isset($_SESSION["usuario"])){
				session_destroy();
				echo "<br><br> <font color='red'>Intento de acceso sin autorización!!!</font>";
				header("Location:../intranet.html");
				exit;
			}
			 else {
				 include("../inc/menuarriba.php");
			 /*$id_us= $_SESSION['id_us'];
			 $correo_us= $_SESSION['correo_us'];*/
				include("../inc/menu.php");
	 ?>
			<h1 class="h3 mb-2 text-gray-800">Creación de proyecto</h1>
			<p class="mb-4">En esta página se puede crear los proyectos.</p>
			<script src="http://code.jquery.com/jquery-latest.min.js" type="text/javascript"></script>
			<link rel="stylesheet" href="../css/estilos.css"/>
			<script src="script.js"></script>
			<script>
				function alerta()
				{
					return confirm("¿Esta seguro que desea crear este proyecto?");
				}
			</script>
            <div class="card shadow mb-4">
				<div class="card-header py-3">
				  <h6 class="m-0 font-weight-bold text-primary">Creación de Proyectos</h6>
				</div>
				<div class="card-body">
					<div class="table-responsive">
			<form action='CUS005proyectos.php'>
			<input type='submit' value="Regresar a relación de proyectos" class='d-none d-sm-inline-block btn btn-sm btn-primary shadow-sm' >
			</form><br>
            <form class="user" onSubmit='return alerta();' action='crearCUS005.php' method="POST" enctype='multipart/form-data'>
            Nombre Proyecto: <input class="form-control" placeholder='Nombre del proyecto' name="proy" type="text"> <br><br>
            Tipo de proyecto: <select class="form-control" name="tipoproy">
				<option value="">Elige una opción</option>
				<option value="A">A</option> 
				<option value="B">B</option>
			</select><br><br>
            Expediente: <input class="form-control-file" name="exp" type="file" accept="application/x-rar-compressed,application/zip,application/msword,application/pdf"> <br><br>
            Consolidado de propuestas: <input class="form-control-file" name="consoli" type="file" accept="application/x-rar-compressed,application/zip,application/msword,application/pdf"> <br><br>
            <br>
            <input type='submit' value='Guardar' name='Guardar' class='d-none d-sm-inline-block btn btn-sm btn-primary shadow-sm'>

            </form>
					</div>
				</div>
			</div>
	  <?php
				include("../inc/menubajo.php");
			 }
	  ?>	
</html>