<html>

	<head>

	</head>

	<body>
		<?php
				  session_start(); //inicio de sesión
					if (!isset($_SESSION["usuario"])){
						session_destroy();
						echo "<br><br> <font color='red'>Intento de acceso sin autorización!!!</font>";
						header("Location:../intranet.html");
						exit;
					}
					$cod=$_GET["cod"];
				  $proy = $_POST["proy"];
  			      $tipoproy = $_POST["tipoproy"];
				  $enlace = mysqli_connect("localhost","root","","base_va");
				 $sentencia="update proyectos set Nombre_Proyecto = '$proy',Tipo_Proyecto= '$tipoproy' where Codigo_Proyecto='$cod';";
				$resultado = mysqli_query($enlace,$sentencia);
				header("Location:CUS005proyectos.php");
		?>
	</body>
</html>
