<?php
			session_start(); //inicio de sesión
					if (!isset($_SESSION["usuario"])){
						session_destroy();
						echo "<br><br> <font color='red'>Intento de acceso sin autorización!!!</font>";
						header("Location:../intranet.html");
						exit;
					}
			$cod=$_GET["cod"];
			$carpeta_destino=$_SERVER['DOCUMENT_ROOT'].'/ADS 4/upload/';
			$nombre_consoli=$_FILES['consoli']['name'];
			  $tipo_consoli=$_FILES['consoli']['type'];
			  $tamano_consoli=$_FILES['consoli']['size'];
			  move_uploaded_file($_FILES['consoli']['tmp_name'],$carpeta_destino.$nombre_consoli);
			  $consoli_objetivo=fopen($carpeta_destino.$nombre_consoli,'r');
			  $contenido_consoli=fread($consoli_objetivo,$tamano_consoli);
			  $contenido_consoli=addslashes($contenido_consoli);
			  fclose($consoli_objetivo);
			$enlace = mysqli_connect("localhost","root","","base_va");
			$sentencia="update proyectos set Consolidado_propuestas='$contenido_consoli',
			tipo_consolidado='$tipo_consoli' where Codigo_Proyecto='$cod';";
			$resultado = mysqli_query($enlace,$sentencia);
			header("Location:modificarproyectos.php?cod=$cod");
?>