<html>
	<?php
			session_start(); //inicio de sesión
			if (!isset($_SESSION["usuario"])){
				session_destroy();
				echo "<br><br> <font color='red'>Intento de acceso sin autorización!!!</font>";
				header("Location:../intranet.html");
				exit;
			}
			 else {
			include("../inc/menuarriba.php");
			 /*$id_us= $_SESSION['id_us'];
			 $correo_us= $_SESSION['correo_us'];*/
			include("../inc/menu.php");

	 ?>
			<div>
			<h1 class="h3 mb-2 text-gray-800">Modificación de datos de proyectos</h1>
			<p class="mb-4">En esta página se puede modificar los proyectos.</p>
			<div class="card shadow mb-4">
				<div class="card-header py-3">
				  <h6 class="m-0 font-weight-bold text-primary">Modificación de Proyectos</h6>
				</div>
				<div class="card-body">
					<div class="table-responsive">
			<form action='CUS005proyectos.php'>
			<input type='submit' value="Regresar a relación de proyectos" class='d-none d-sm-inline-block btn btn-sm btn-primary shadow-sm'>
			</form><br>
			<?php

            $cod=$_GET["cod"];
            $sentencia2="SELECT * FROM proyectos where Codigo_Proyecto='$cod';";
            $resultado2=mysqli_query($enlace,$sentencia2);
            $fila=mysqli_fetch_row($resultado2);
			echo "<script src='http://code.jquery.com/jquery-latest.min.js' type='text/javascript'></script>";
			echo "<link rel='stylesheet' href='../css/estilos.css'/>";
			echo "<script src='script.js'></script>";
			echo "<script>";
			echo "function alerta(){";
			
			echo"return confirm('¿Está seguro que desea modificar este proyecto?');}";
			echo "</script>";
            echo"<form class='user' onSubmit='return alerta();' action='editarproy.php?cod=$cod' method='POST' enctype='multipart/form-data'>";
            echo" Nombre Proyecto: <input class='form-control' name='proy' type='text' value='$fila[1]'> <br><br>";
            echo" Tipo de proyecto: <select class='form-control' name='tipoproy'> <br><br>"; 
			echo"<option value='$fila[2]'>$fila[2]</option> <br><br>"; 
			 if ($fila[2]=="A"){		 
				echo "<option value='B'>B</option> <br><br>";
				}
			 else{
				echo "<option value='A'>A</option> <br><br>";
			 }
			echo "</select><br><br>";
            echo" Expediente: ";
			if ($fila[3]<>NULL){
			echo"<a href='descargar_exp.php?cod=$cod' class='d-none d-sm-inline-block btn btn-sm btn-primary shadow-sm'>Expediente</a><br><br>";
			echo"<a href='subir_exp.php?cod=$cod' class='d-none d-sm-inline-block btn btn-sm btn-primary shadow-sm'>Cambiar Expediente</a><br><br>";
			} else {
				echo "No hay archivo subido<br><br>";
				echo"<a href='subir_exp.php?cod=$cod' class='d-none d-sm-inline-block btn btn-sm btn-primary shadow-sm'>Agregar Expediente</a><br><br>";
			}
			 echo" Estado de proyecto: <input class='form-control' name='estproy' type='text' value='$fila[4]' readonly> <br><br>";
            echo" Consolidado de propuestas: ";
			if ($fila[5]<>NULL){
			echo"<a href='descargar_consoli.php?cod=$cod' class='d-none d-sm-inline-block btn btn-sm btn-primary shadow-sm'>Consolidado de propuestas</a><br><br>";
			echo"<a href='subir_consoli.php?cod=$cod' class='d-none d-sm-inline-block btn btn-sm btn-primary shadow-sm'>Cambiar Consolidado de Propuestas</a><br><br>";			
			} else {
				echo "No hay consolidado subido<br>";
				echo"<a href='subir_consoli.php?cod=$cod' class='d-none d-sm-inline-block btn btn-sm btn-primary shadow-sm'>Agregar Consolidado de Propuestas</a><br><br>";	
			}
            echo "<input type='submit' value='Guardar' name='Guardar' class='d-none d-sm-inline-block btn btn-sm btn-primary shadow-sm'>";

            echo" </form>";
            ?>
					</div>
				</div>
			</div>
	  <?php
			include("../inc/menubajo.php");
			 }
	  ?>
</html>
