<html>

	<head>
	  <meta charset="utf-8">
	  <meta content="width=device-width, initial-scale=1.0" name="viewport">
	  <meta name="referrer" content="origin-when-crossorigin" id="meta_referrer">
	  <title> Intranet Vive Amazonas</title>
	  <meta content="" name="descriptison">
	  <meta content="" name="keywords">

	  <!-- Favicons -->
	  <link href="assets/img/favicon.png" rel="icon">
	  <link href="assets/img/apple-touch-icon.png" rel="apple-touch-icon">

	  <!-- Google Fonts -->
	  <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i|Raleway:300,300i,400,400i,500,500i,600,600i,700,700i|Poppins:300,300i,400,400i,500,500i,600,600i,700,700i" rel="stylesheet">

	  <!-- Vendor CSS Files -->
	  <link href="assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
	  <link href="assets/vendor/icofont/icofont.min.css" rel="stylesheet">
	  <link href="assets/vendor/boxicons/css/boxicons.min.css" rel="stylesheet">
	  <link href="assets/vendor/venobox/venobox.css" rel="stylesheet">
	  <link href="assets/vendor/owl.carousel/assets/owl.carousel.min.css" rel="stylesheet">
	  <link href="assets/vendor/aos/aos.css" rel="stylesheet">
	  <!-- Template Main CSS File -->
	  <link href="css/styles_2.css" rel="stylesheet">
	</head>
	 
    <body> 
	<header class="masthead">
				<div class="container h-100">
					<div class="row h-100 align-items-center justify-content-center text-center">
						<div class="col-lg-10">
						 <h2 class="text-uppercase text-white font-weight-bold">
							 <?php
							session_start();
							$usuario = $_POST["usuario"];
							$contraseña= $_POST["contraseña"];
								
							#validar usuario y contraseña existan en la BD, sino mandar un mensaje de error	
											   if ($usuario=="" || $contraseña==""){
												 echo "Ingrese el usuario o contraseña<br><br>";
												 echo '<a class="btn btn-primary btn-xl js-scroll-trigger" href="intranet.html"> Regresar </a>';
											   }
											   else{						   
													   $CONserver = "localhost";
													   $CONuser= "root";
													   $CONpass= "";
													   $CONdb= "base_va";
													   
													   $conexion= new mysqli($CONserver,$CONuser,$CONpass,$CONdb); 
													   if($conexion->connect_errno) {
														   
														 die("La conexión ha fallado");  
													   } 
													   
													  $consulta=$conexion->query( "SELECT * FROM usuarios WHERE usuario = '$usuario' AND contraseña= '$contraseña' AND estado='A';");
													  $contar= $consulta->num_rows;
													  $consulta2=$conexion->query( "SELECT * FROM usuarios WHERE usuario = '$usuario' AND contraseña= '$contraseña';");
													  $contar2= $consulta2->num_rows;
													  if ($contar==1) {
														  echo "Se ha logueado correctamente";
														  $_SESSION['usuario']=$usuario;
														  header ("Location: perfil/perfil.php");
													  }
													  elseif ($contar2==1 AND $contar==0){
														  echo "Usted no cuenta actualmente con acceso a la intranet. Comuníquese con ViveAmazonas a través de la información de contacto presentada en la página principal<br><br>";
														  echo '<a class="btn btn-primary btn-xl js-scroll-trigger" href="index 2.html"> Regresar </a>';
														  session_destroy();
													  }
													  else {
														  
														 echo " Contraseña  o usuario incorrectos <br><br> ";
														 echo '<a class="btn btn-primary btn-xl js-scroll-trigger" href="intranet.html"> Regresar </a>';
														session_destroy();
														  }
											  }
							?>
                 </h2>							
				 </div>
            </div>
       </div>
   </header>	 
		
    </body>
</html>