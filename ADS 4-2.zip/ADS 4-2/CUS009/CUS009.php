<html lang="en">
	<?php
	 session_start(); //inicio de sesión
						if (!isset($_SESSION["usuario"])){
							session_destroy();
							echo "<br><br> <font color='red'>Intento de acceso sin autorización!!!</font>";
							header("Location:../intranet.html");
							exit;
						}
			 else {
			include("../inc/menuarriba.php");	 
			 /*$id_us= $_SESSION['id_us'];
			 $correo_us= $_SESSION['correo_us'];*/
			include("../inc/menu.php");
	 ?>
			<h1 class="h3 mb-2 text-gray-800">Relación de plantillas</h1>
			<p class="mb-4">En esta página se puede administrar los plantillas.</p>
			<script src="http://code.jquery.com/jquery-latest.min.js" type="text/javascript"></script>
			<link rel="stylesheet" href="../css/estilos.css"/>
			<script src="script.js"></script>
			<script>
				function alerta()
				{
					return confirm("¿Esta seguro que desea eliminar esta Plantilla?");
				}
			</script>
			<div class="card shadow mb-4">
				<div class="card-header py-3">
				  <h6 class="m-0 font-weight-bold text-primary">Tabla de Plantillas</h6>
				</div>
				<div class="card-body">
					<div class="table-responsive">
			<form class="d-none d-sm-inline-block form-inline mr-auto ml-md-3 my-2 my-md-0 mw-100 navbar-search" action='CUS009.php' method='POST' enctype='multipart/form-data'>
				<div class="input-group">
			
						<input type='text' class="form-control bg-light border-0 small" name='filtro' placeholder='Buscando Plantilla...'>  
						<input type='submit' class="btn btn-primary" name='buscar' value="Buscar">
				</div>
			</form>
			<br><br>
  				<?php
				if (!isset($_POST["buscar"])){
    				$sentencia5="Select * from plantilla where estado='A';";
    				$resultado5 = mysqli_query($enlace,$sentencia5);
    				$contar5= mysqli_num_rows($resultado5);			
 			
					echo "<form action='crearplantilla.php' method='POST'>";
		
					$sentencia2="SELECT * from plantilla where estado='A';";
					$resultado2 = mysqli_query($enlace,$sentencia2);
					$contar= mysqli_num_rows($resultado2);

           if ($contar==0){
           echo  "No hay plantillas<br>";
           }
           else {

           echo "<form action='' method= 'POST'>";
           echo "<table class='table table-bordered' id='dataTable' width='100%' cellspacing='0'>";
		   echo "<thead>";
           echo "	<tr>";
           echo "		<td>Codigo de Plantilla</td>";
           echo "		<td> Nombre de Plantilla</td>";
           echo "		<td> Tipo de Plantilla</td>";
           echo "		<td>Fecha de creación</td>";
           echo "		<td>Opciones</td>";
           echo "	</tr>";

           for ($i=1; $i <= $contar; $i++){
             $registro = mysqli_fetch_row($resultado2);


             echo "	<tr>";
             echo "		<td>",$registro[0],"</td>";
             echo "		<td>",$registro[1],"</td>";
             echo "		<td>",$registro[2],"</td>";
             echo "		<td>",$registro[3],"</td>";
             echo "		<td><a href='modificarplantilla.php?cod=$registro[0]'>Modificar</a>
			 <a href='verplantilla.php?cod=$registro[0]'>Consultar</a>
			 <a onclick='return alerta();' href='eliminarplantilla.php?cod=$registro[0]'>Eliminar</a></td> ";
             echo "	</tr>";

           }
          echo "</tbody>";
           echo "</table>";

           }

             ?>
			 <input type='submit' class="btn btn-primary" value="Crear plantilla" >
		  </form>
	  <?php
			 }
			 else {
			$filtro = $_POST['filtro'];
			echo"<form action='CUS009.php' enctype='multipart/form-data'>";
  			if ($filtro==''){
  				echo"No ha seleccionado ninguna Plantilla";
					}
  			else {
              $sentencia2="Select * from plantilla where estado='A' and nombre_plantilla LIKE '$filtro%';";
  			$resultado2 = mysqli_query($enlace,$sentencia2);
             if(!empty($resultado2) AND mysqli_num_rows($resultado2) > 0){ 
				$contar= mysqli_num_rows($resultado2);
				if ($contar==0){
				echo  "No hay plantilla <br>";
					}
				else {

				echo "<form action='' method= 'POST'>";
				echo "<table class='table table-bordered' id='dataTable' width='100%' cellspacing='0'>";
				echo "<thead>";
				echo "	<tr>";
				echo "		<td>Codigo de Plantilla</td>";
				echo "		<td> Nombre de Plantilla</td>";
				echo "		<td> Tipo de Plantilla</td>";
				echo "		<td>Fecha de creación</td>";
				echo "		<td>Documento de plantilla</td>";
				echo "		<td>Opciones</td>";
				echo "	</tr>";
				echo "</thead>";
				echo "<tbody>";

				for ($i=1; $i <= $contar; $i++){
				$registro = mysqli_fetch_row($resultado2);


				   echo "	<tr>";
				   echo "		<td>",$registro[0],"</td>";
				   echo "		<td>",$registro[1],"</td>";
				   echo "		<td>",$registro[2],"</td>";
				   echo "		<td>",$registro[3],"</td>";
				   echo "		<td>Plantilla</td>";
				   echo "		<td><a href='modificarevaluadores.php?cod=$registro[0]'>Modificar</a>
				 <a href='verevaluadores.php?cod=$registro[0]'>Consultar</a>
				 <a onclick='return alerta();' href='eliminarevaluadores.php?cod=$registro[0]'>Eliminar</a></td> ";
				   echo "	</tr>";

             }
            echo "</tbody>";
			echo "</table>";

             }
  			}
			echo" <br><br>";
			echo"<input type='submit' class='btn btn-primary' value='Regresar a relación de plantillas'>";
			echo"</form>";

			 }
			 }
				echo"</div>";
			echo"</div>";
		echo"</div>";
			 			include("../inc/menubajo.php");
			 }
	  ?>
</html>
