<html lang="en">
	<?php
	 session_start(); //inicio de sesión
			if (!isset($_SESSION["usuario"])){
				session_destroy();
				echo "<br><br> <font color='red'>Intento de acceso sin autorización!!!</font>";
				header("Location:../intranet.html");
				exit;
			}
			 else {
			 include("../inc/menuarriba.php");
			 /*$id_us= $_SESSION['id_us'];
			 $correo_us= $_SESSION['correo_us'];*/
				include("../inc/menu.php");
	 ?>
			<h1 class="h3 mb-2 text-gray-800">Modificación de datos de la plantilla</h1>
			<p class="mb-4">En esta página se puede modificar las plantillas.</p>
			<div class="card shadow mb-4">
				<div class="card-header py-3">
				  <h6 class="m-0 font-weight-bold text-primary">Modificación de la plantilla</h6>
				</div>
				<div class="card-body">
					<div class="table-responsive">
			<form action='CUS009.php'>
			<input type='submit' value="Regresar a relación de plantillas" class='d-none d-sm-inline-block btn btn-sm btn-primary shadow-sm' >
			</form><br>
			<?php

            $cod=$_GET["cod"];
            $sentencia3="SELECT * FROM plantilla where codigo_plantilla='$cod';";

            $resultado3=mysqli_query($enlace,$sentencia3);
            $fila=mysqli_fetch_row($resultado3);
			echo "<script src='http://code.jquery.com/jquery-latest.min.js' type='text/javascript'></script>";
			echo "<link rel='stylesheet' href='css/estilos.css'/>";
			echo "<script src='script.js'></script>";
			echo "<script>";
			echo "function alerta(){";
			echo	"return confirm('¿Está seguro que desea modificar esta Plantilla?');}";
			echo "</script>";
            echo"<form  class='user onSubmit='return alerta();' action='editarplantilla.php?cod=$cod' method='POST'>";
            echo" Tipo de Plantilla: <select class='form-control' name='tipo'>";
            if ($fila[2]=='Documento de desaprobación'){
              echo"<option value='$fila[2]'>$fila[2]</option>";
              echo"<option value='Documento de Aprobación' >Documento de Aprobación</option>";
              echo"<option value='Convenio de Financiamiento'>Convenio de Financiamiento</option>";
			  echo"<option value='Informe Técnico'>Informe Técnico</option>";
			  echo"<option value='Publicación'>Publicación</option>";
			  echo"<option value='Declaración jurada' >Declaración jurada</option>";
              echo "</select><br><br>";
            }
            elseif ($fila[2]=='Documento de aprobación'){
              echo"<option value='$fila[2]'>$fila[2]</option>";
              echo"<option value='Documento de desaprobación'>'Documento de desaprobación</option>";
              echo"<option value='Convenio de Financiamiento'>Convenio de Financiamiento</option>";
			  echo"<option value='Informe Técnico'>Informe Técnico</option>";
			  echo"<option value='Publicación'>Publicación</option>";
			  echo"<option value='Declaración jurada' >Declaración jurada</option>";
              echo"</select><br><br>";
            }
            elseif ($fila[2]=='Informe técnico'){
              echo"<option value='$fila[2]'>$fila[2]</option>";
              echo"<option value='Documento de aprobación' >Documento de aprobación</option>";
              echo"<option value='Documento de desaprobación' >Documento de desaprobación</option>";
			  echo"<option value='Convenio de Financiamiento'>Convenio de Financiamiento</option>";
			  echo"<option value='Publicación'>Publicación</option>";
			  echo"<option value='Declaración jurada' >Declaración jurada</option>";
              echo"</select><br><br>";
            }
			elseif($fila[2]=='Convenio de Financiamiento'){
			  echo"<option value='$fila[2]'>$fila[2]</option>";
              echo"<option value='Documento de aprobación' >Documento de aprobación</option>";
              echo"<option value='Documento de desaprobación' >Documento de desaprobación</option>";
			  echo"<option value='Informe Técnico'>Informe Técnico</option>";
			  echo"<option value='Publicación'>Publicación</option>";
			  echo"<option value='Declaración jurada' >Declaración jurada</option>";
			  echo"</select><br><br>";
			}
			elseif($fila[2]=='Declaración jurada'){
			  echo"<option value='$fila[2]'>$fila[2]</option>";
			  echo"<option value='Documento de aprobación' >Documento de aprobación</option>";
              echo"<option value='Documento de desaprobación' >Documento de desaprobación</option>";
			  echo"<option value='Informe Técnico'>Informe Técnico</option>";
			  echo"<option value='Publicación'>Publicación</option>";
			  echo"<option value='Convenio de Financiamiento'>Convenio de Financiamiento</option>";
				echo"</select><br><br>";
			}
            else {
              echo"<option value='$fila[2]'>$fila[2]</option>";
              echo"<option value='Documento de aprobación' >Documento de aprobación</option>";
              echo"<option value='Documento de desaprobación' >Documento de desaprobación</option>";
              echo"<option value='Informe técnico' >Informe técnico</option>";
			  echo"<option value='Convenio de Financiamiento'>Convenio de Financiamiento</option>";
			  echo"<option value='Declaración jurada' >Declaración jurada</option>";
              echo"</select><br><br>";
            }
            echo" Nombre de plantilla: <input class='form-control' name='nombre' type='text' value='$fila[1]'> <br><br>";
            echo" Fecha de creación: <input class='form-control' name='fecha' type='text' value='$fila[3]'> <br><br>";
            echo" Texto: <select class='form-control' id='etiqueta' name='etiqueta' onchange='InsertHTML()'>
                <option value=''>Seleccionar</option>
                <option value='(NOMEMPRESA)'>Nombre empresa</option>
				<option value='(NOMPERSONA)'>Nombre Persona</option>
				<option value='(NOMCON)'>Nombre Concurso</option>
				<option value='(NOMPROY)'>Nombre Proyecto</option>
                <option value='(DNIPERSONA)'>DNI persona</option>
				<option value='(ESTADOPROY)'>Estado Proyecto</option>
                <option value='(FIRMA)'>Firma</option>
				<option value='(FECHAACTUAL)'>Fecha actual</option>
				<option value='(FECHANEGOCIACION)'>Fecha negociacion</option>
				<option value='(FECHAINICIO)'>Fecha inicio</option>
				<option value='(FECHAFIN)'>Fecha fin</option>
				<option value='(MONTOFINANCIADO)'>Monto financiado</option>
				<option value='(UNIDAD)'>Unidad</option>
            </select><br>
			<textarea id='editor1' class='form-control' name='texto' rows='9' cols='40' value= '$fila[4]'>$fila[4]</textarea>
			<br><br>";

            echo "<input type='submit' value='Guardar' name='Guardar' class='d-none d-sm-inline-block btn btn-sm btn-primary shadow-sm'>";
            echo" </form>";
   ?>
					</div>
				</div>
			</div>
	  <?php
			include("../inc/menubajo.php");
			 }
	  ?>
</html>
