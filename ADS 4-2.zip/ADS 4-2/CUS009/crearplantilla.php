<html lang="en">
	<?php
	 session_start(); //inicio de sesión
			if (!isset($_SESSION["usuario"])){
				session_destroy();
				echo "<br><br> <font color='red'>Intento de acceso sin autorización!!!</font>";
				header("Location:../intranet.html");
				exit;
			}
			 else {
				 include("../inc/menuarriba.php");
			 /*$id_us= $_SESSION['id_us'];
			 $correo_us= $_SESSION['correo_us'];*/
				include("../inc/menu.php");
	 ?>
			<h1 class="h3 mb-2 text-gray-800">Creación de plantilla</h1>
			<p class="mb-4">En esta página se puede crear los plantillas.</p>
			<script src="http://code.jquery.com/jquery-latest.min.js" type="text/javascript"></script>
			<link rel="stylesheet" href="../css/estilos.css"/>
			<script src="script.js"></script>
			<script>
				function alerta()
				{
					return confirm("¿Esta seguro que desea crear esta Plantilla?");
				}
			</script>
			<div class="card shadow mb-4">
				<div class="card-header py-3">
				  <h6 class="m-0 font-weight-bold text-primary">Creación de plantillas</h6>
				</div>
				<div class="card-body">
					<div class="table-responsive">
			<form action='CUS009.php'>
			<input type='submit' value="Regresar a relación de plantillas" class='d-none d-sm-inline-block btn btn-sm btn-primary shadow-sm'>
			</form><br>
            <form class="user" onSubmit='return alerta();' action='CrearCUS009.php' method="POST" enctype= 'multipart/form-data'>
            Tipo de Plantilla: <select class="form-control" name="tipo"><br><br>
              	<option value="" >Elige una opción...</option>
                <option value="Documento de aprobación" >Documento de aprobación</option>
                <option value="Documento de desaprobación" >Documento de desaprobación</option>
                <option value="Convenio de Financiamiento" >Convenio de Financiamiento</option>
				<option value="Informe Técnico" >Informe Técnico</option>
                <option value="Publicación" >Publicación</option>
				<option value='Declaración jurada' >Declaración jurada</option>
        			</select><br><br>
            Nombre de Plantilla: <input class="form-control" name="nombre" type="text"> <br><br>
            Fecha de Creación <input class="form-control" name="fecha" type="date"> <br><br>
            Descripción: <select class="form-control" id="etiqueta" name="etiqueta" onchange="InsertHTML()">
                <option value="">Seleccionar</option>
                <option value="(NOMEMPRESA)">Nombre empresa</option>
				<option value="(NOMPERSONA)">Nombre Persona</option>
				<option value="(NOMCON)">Nombre Concurso</option>
				<option value="(NOMPROY)">Nombre Proyecto</option>
                <option value="(DNIPERSONA)">DNI persona</option>
				<option value="(ESTADOPROY)">Estado Proyecto</option>
                <option value="(FIRMA)">Firma</option>
				<option value='(FECHAACTUAL)'>Fecha actual</option>
				<option value='(FECHANEGOCIACION)'>Fecha negociacion</option>
				<option value='(FECHAINICIO)'>Fecha inicio</option>
				<option value='(FECHAFIN)'>Fecha fin</option>
				<option value='(MONTOFINANCIADO)'>Monto financiado</option>
				<option value='(UNIDAD)'>Unidad</option>
            </select><br>
			<textarea id="editor1" class="form-control" name="texto" rows="9" cols="40" placeholder='Escribe aquí la descripción'></textarea>
			<br><br>
            <input type='submit' value='Guardar' name='Guardar' class='d-none d-sm-inline-block btn btn-sm btn-primary shadow-sm'>

            </form>
			</div>
				</div>
			</div>
	  <?php
				include("../inc/menubajo.php");
			 }
	  ?>
</html>