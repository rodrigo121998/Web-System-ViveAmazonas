<html>
<head> </head>
<body>
<?php
	session_start(); //inicio de sesión
	if (!isset($_SESSION["usuario"])){
		session_destroy();
		echo "<br><br> <font color='red'>Intento de acceso sin autorización!!!</font>";
		header("Location:../intranet.html");
		exit;
	}
	$tipo = $_POST["tipo"];
	$nombre = $_POST["nombre"];
	$fecha = $_POST["fecha"];
	$texto = htmlspecialchars($_POST["texto"], ENT_QUOTES);
$nombre_plantilla=$_FILES['plantilla']['name'];
$tipo_plantilla=$_FILES['plantilla']['type'];
$tamano_plantilla=$_FILES['plantilla']['size'];
$carpeta_destino=$_SERVER['DOCUMENT_ROOT'].'/ADS 4/upload/';
move_uploaded_file($_FILES['plantilla']['tmp_name'],$carpeta_destino.$nombre_plantilla);
$imagen_objetivo=fopen($carpeta_destino.$nombre_plantilla,'r');
$contenido_imagen=fread($imagen_objetivo,$tamano_plantilla);
$contenido_imagen=addslashes($contenido_imagen);
fclose($imagen_objetivo);

    $enlace = mysqli_connect("localhost","root","","base_va");
	$sentencia="INSERT INTO plantilla(nombre_plantilla ,tipo_Plantilla,fecha_creacion,texto,estado)
	VALUES ('$nombre','$tipo','$fecha','$texto','A');";
	$resultado = mysqli_query($enlace,$sentencia);
	header("Location:CUS009.php");
	
 ?>
</body>
</html>
