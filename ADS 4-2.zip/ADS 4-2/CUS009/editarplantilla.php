<html>
	<head>
	</head>

	<body>
		<?php
		session_start(); //inicio de sesión
					if (!isset($_SESSION["usuario"])){
						session_destroy();
						echo "<br><br> <font color='red'>Intento de acceso sin autorización!!!</font>";
						header("Location:../intranet.html");
						exit;
					}
			$cod=$_GET["cod"];
			$tipo= $_POST["tipo"];
			$nombre = $_POST["nombre"];
			$fecha = $_POST["fecha"];
			$texto = htmlspecialchars($_POST["texto"], ENT_QUOTES);
			$enlace = mysqli_connect("localhost","root","","base_va");
			$sentencia="update plantilla set nombre_plantilla= '$nombre',
			tipo_Plantilla= '$tipo',fecha_creacion = '$fecha',texto = '$texto'
			where codigo_plantilla='$cod';";
			$resultado = mysqli_query($enlace,$sentencia);
			header("Location:CUS009.php");
		?>
	</body>
</html>
